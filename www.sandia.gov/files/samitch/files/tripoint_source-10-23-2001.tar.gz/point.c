// point.c -- utility functions for intersection, etc
//
// Scott Mitchell, Xerox PARC, 1991

#include "point.h"
#include <fstream.h>
#include <iostream.h>
#include <string.h>
#include "defines.h"

point points::minpt, points::MAXpt;  //storage for static class members

inline double mind( double v1, double v2 ) { return ((v1<v2) ? v1 : v2); };
inline double maxd( double v1, double v2 ) { return ((v1>v2) ? v1 : v2); };

//-------------------- REP -----
// we know we aren't in the box
#define region(x) (this->x < lit->x) ? lit->x : ((this->x > big->x ) ? big->x : this->x);
double point::box_dist_loc( geo* , point* big, point* lit ) 
{
    point closept;
    closept.x = region(x); closept.y = region(y);
    return dist(&closept, this);
}

#define d(f,p) f->r->f_to_pt_dist( f, p )
#define boxd(f) f->r->box_dist_loc( f, big, lit )
double edge::box_dist_loc( geo* f, point* big, point* lit )
{
    //distance is either dist from edge to a corner pt,
    // or endpt to box!
    point p1 ( big->x, lit->y ), p2 (lit->x, big->y);
    return 
    	mind(
            mind( 
	    	mind( d(f,big), d(f,lit) ) , 
	    	mind( d(f,&p1), d(f,&p2) ) 
            ),
	    mind( boxd( f->subfaces->first() ),
		  boxd( f->subfaces->rest()->first() )
	    )
	);
}
#undef d
#undef boxd

//---
void add_f( geo * f, points** containsp, points** containse ) {
    f->r->add_f_loc( f, containsp, containse );
}

void point::add_f_loc( geo * f, points** containsp, 
	points**  ) {
    *containsp = new points( f, *containsp );
}
void edge::add_f_loc( geo * f, points** , 
	points** containse ) {
    *containse = new points( f, *containse );
}

//----

static inline double linedist( point c1, point c2, point e1 ) {
    // dist is + if e1 is right of vector from c1 to c2
  point  v = perp( c1, c2 );        //perp vector to edge c1-c2
  point w(e1.x - c1.x, e1.y - c1.y);
  return (v * w) / norm(v);
}

//closest point to c on p1-p2  <-> vector proj of p1-c onto p1-p2
point closestpt( point p1, point p2, point c, int & which )
{
  point v = p2 - p1;
  c = c - p1;
  double t = (( v * c ) / (v*v));
  if (t<=0) {which = 1; return p1;}
  if (t>=1) {which = 2; return p2;}
  which = 0;
  return p1 + v * t;
}

// sgn of Right Hand Rule for points c1, c2, c3
// colinearity returns zero
int cw( point& c1, point& c2, point& e1 ) {
  point  v = perp( c1, c2 );        //perp vector to edge c1-c2
  point w(e1.x - c1.x, e1.y - c1.y);
  double k = v*w;
    // or just k=linedist( c1, c2, e1 ); but norm too slow cause of sqrt
    return k > 0 ? 1 : (k == 0 ? 0 : -1); // sgn(k)
}

int left(point * c1, point * c2, point * p1, point * p2)
//all these points lie on a line, return 1 if c1 is closer to p1 than 
//c2 is to p1
// we ASSUME p1 and p2 are the extreme points of the line
{
    point v1 = *c1-*p1;
    point v2 = *c2-*p1;
    point v3 = *p2-*p1;
    return (fabs(v3.x) > fabs(v3.y)) ?
	(fabs(v1.x) < fabs(v2.x))
	:
	(fabs(v1.y) < fabs(v2.y));
}


//------------------- POINT ---------
int point::ecap( geo * thatg, geo * thisg )
{
    // this is a point, that is an edge
    //redundant
    return thatg->r->pcap( thisg, thatg);
}

int point::pcap( geo * thatg, geo * thisg ) {
    // both points
    return ( *(point*)thatg->r == *(point*)thisg->r );
}

int point::cap( geo * thisg, geo * thatg )  
{
    // we know that this is a point by point::
    // now must branch on what thatg is
    return thatg->r->pcap( thisg, thatg );
}


// boolean, does this contain g, if g is known NOT to instersect
// assumes not warped
point * point::inbox_testpoint(geo * )
{
    return this;
}

double dist( point * pt1, point * pt2 ) {
    return norm(*pt2 - *pt1);
}

double point::f_to_pt_dist( geo* , point* pt )
{
    return dist( this, pt );
}


int closest_pt_between( point e1, point e2, point c )
// is the closest point on line e1, e2 also on the segment e1, e2
// <==> is abs angle e2 e1 c1 < 90 and same for e1 e2 c1 
{
    return (   ( (e1-e2) * (c-e2) >= 0 ) && 
	       ( (e2-e1) * (c-e1) >= 0 )   );
}

double edge::f_to_pt_dist( geo* thisg, point * c )
//return distance from pt to the closest point of this
// closest point could be either endpoint or in middle
{
    point e1 = * thisg->endpt1();
    point e2 = * thisg->endpt2();
    return ( 
	( closest_pt_between( e1, e2, *c ) ) ? 
	  fabs( linedist( e1, e2, *c ) )
	  :
          mind( dist( &e1, c ), dist( &e2, c ) ) 
	);
}



// ------------------ EDGE ----------

inline int ecap_contain_loc( coor& x1, coor& x2, coor& x3, coor& x4) {
    return  between_noorder(x1,x2,x3) || between_noorder(x1,x2,x4) || 
		between_noorder(x3,x4,x1);
}


int ecap_contain( point & c1, point & c2, point & e1, point & e2 ) {
    return (fabs(c1.y-c2.y)<fabs(c1.x-c2.x)) ? 
	ecap_contain_loc( c1.x, c2.x, e1.x, e2.x )
	:
	ecap_contain_loc( c1.y, c2.y, e1.y, e2.y );
}

int ecap( point & c1, point & c2, point & e1, point & e2 ) 
// do two edges intersect, including just touching at a vertex?
// first edge is c1 to c2, second edge is e1 to e2
{
    int cw1 = cw( c1, c2, e1 ), cw2 = cw( c1, c2, e2 ),
	cw3 = cw( e1, e2, c1 ), cw4 = cw( e1, e2, c2 );

    if ((cw1==0) && (cw2==0))  { // ? containment/overlay
	return ecap_contain( c1, c2, e1, e2 );
    }
    else if ((cw3==0) && (cw4==0)) { // ? containment/overlay
	return ecap_contain( e1, e2, c1, c2 );
    }
    else {
	return ((cw1 != cw2) && (cw3 != cw4));
    }
}

int edge::ecap( geo * thatg, geo * thisg )
{
    // we know thatg points to an edge by name ecap
    // we know thisg points to an edge by edge::

    return ::ecap (
      *(point*) thatg->subfaces->first()->r,
      *(point*) thatg->subfaces->rest()->first()->r,
      *(point*) thisg->subfaces->first()->r,
      *(point*) thisg->subfaces->rest()->first()->r
    );
 
}

int edge::pcap( geo * thatg, geo * thisg )
{
    //thatg is a point, thisg is an edge
    point& e1=*(point*) thisg->subfaces->first()->r;
    point& e2=*(point*) thisg->subfaces->rest()->first()->r;
    point& p1=*(point*) thatg->r; 

    return ( (cw(e1,e2,p1) == 0)
		&&
      ( (fabs(e1.x-e2.x) > fabs(e1.y-e2.y)) ? 
 	 between_noorder(e1.x,e2.x,p1.x) :
	 between_noorder(e1.y,e2.y,p1.y) )
	   );
}
 
int edge::cap( geo * thisg, geo * thatg )  
{
    // we know that this is an edge by edge::
    // now must branch on what thatg is
    return thatg->r->ecap( thisg, thatg );
}


// boolean, does this contain g, if g is known NOT to instersect
point * edge::inbox_testpoint( geo * thisg)
{
    // return an endoint's testpoint
    return thisg->subfaces->first()->r->inbox_testpoint 
 	( thisg->subfaces->first() );
}


int point_inside( point * big, point * lit, point p ) {
    return (between(lit->x,big->x,p.x) && 
	between(lit->y,big->y,p.y));
}

int edge::apex_points( geo* thisg, point* big, point* lit, point * p1, point * p2 ) 
//return the extemes of this edge inside this box.
// p1 is close to endpoint 1, p2 is close to endpoint 
{
    // find where this intersects a box side, return it, or an endpt
    // if contained
    point pt1, pt2;
    point ep1 = * (point*) thisg->endpt1();
    point ep2 = * (point*) thisg->endpt2();


    point op1, op2;
    edge oerep;  
    geo oe(&oerep); geo g1(&op1); geo g2(&op2);
    oe.contains(&g1); oe.contains(&g2);
    point cor[4];
    //simulate corners
    cor[0].x = big->x; cor[0].y = big->y;
    cor[1].x = big->x; cor[1].y = lit->y;
    cor[2].x = lit->x; cor[2].y = lit->y;
    cor[3].x = lit->x; cor[3].y = big->y;
    int c1, c2;

    //me->snap( crossingpt( &oe, crosse ) );
    // cap( thisg, &oe );

    //gaurds against degen edge, ep1 == ep2
    if (ep1.y == ep2.y && ep1.x == ep2.x) {
	*p1 = ep1; *p2 = ep2; 
    }
    //see if inside box
    else if ( point_inside(big, lit, ep1) ) {
	*p1 = ep1;
	for (c1=3, c2=0; c2<4; c1=c2, c2++) {
	    op1 = cor[c1]; op2 = cor[c2];
	    if (cap(thisg, &oe)) {
		*p2 = crossingpt( &oe, thisg );
		return 1;
	    }
	}
	return 0;
    }
    else if ( point_inside(big, lit, ep2) ) {
    	*p2 = ep2;
	for (c1=3, c2=0; c2<4; c1=c2, c2++) {
	    op1 = cor[c1]; op2 = cor[c2];
 	    if (cap(thisg, &oe)) {
		*p1 = crossingpt( &oe, thisg );
		return 1;
	    }
	}
	return 0;
    }
    else {
	int p1ok = 0; int p2ok = 0;
	for (c1=3, c2=0; c2<4; c1=c2, c2++) {
	    op1 = cor[c1]; op2 = cor[c2];
	    if (cap(thisg, &oe)) {
		point p = crossingpt( &oe, thisg );
		if (!p1ok) { p1ok=1; *p1=p; }
		else if (!p2ok) { p2ok=1; *p2=p; }
		else { //contention
		    if (normsqr(p-*p1) > normsqr(*p1-*p2))
			*p2 = p;
		}
	    }
	}
	if (!p2ok) return 0;
	if (left( p2, p1, &ep1, &ep2 )) //need to swap
	    { point temp = *p2; *p2 = *p1; *p1 = temp; }
	return 1;
    }
    return 0;
}

//  -------------------- ANY REP ------------------


//----------------------------------
// points.c  -- data points
// 

// ----------- for seeking elements of a list
class needle {
 private:
    int id;
    points * p;
    points * top;

    // must be called before seek, seeks for different lists may not
    //   be interleaved
    void initseek() {
        id=1;
        p=top;
    }
  
 public:
    //CONSTRUCTOR
    needle(points * topin) { id=1; p=topin; top=topin; }

   // return i^th elem in list
   points * operator()( int i ); 
};

// return i^th elem in list
points * needle::operator()( int i ) {
    // go back to start of list, if past i
    if (id>i) { initseek(); }
    // search from here forward
    while (id<i) {
        p=p->rest();
        id++;
    }
    return p;
};

//--------------------------------------------------

inline int mini( int v1, int v2 ) { return ((v1 < v2) ? v1 : v2); };
inline int maxi( int v1, int v2 ) { return ((v1 > v2) ? v1 : v2); };

void readdata(char * fname, points ** p, points ** e)  {
	// minpt, MAXpt BOUND WITH BUFFER the min/max data values, 
	// 	for defining a bounding box
        coor x, y;
	points * top = 0;
	char * fnamebuf;
	fnamebuf = new char[strlen(fname)+6];
	filebuf fb;  /* ok to be local, all input done in readdata */

	// ---- POINTS ----
	// note, first point read is point #1
	// last point read is point #n, for use with edges

	// start xy input data point stream
	strcpy( fnamebuf, fname );
	strcat( fnamebuf, ".in.p" );
	fb.open( fnamebuf, ios::in ); // input
	istream fin(&fb);

	// read first point in list, default min/MAXcoor
	if (fin >> x >> y) {
		top = new points(new geo(new point(x,y)), top);
		points::MAXpt.x = points::minpt.x = x;
		points::MAXpt.y = points::minpt.y = y;
        }
	else {
		// no data, use a default box, actually program will crass
		cout << "Error, no vertices specified! "; cout.flush();
		points::MAXpt.x = points::minpt.x = 0.0;
		points::MAXpt.y = points::minpt.y = 0.0;
	}
	points * bottom = top;
	// read remaining points
	while (fin >> x >> y) {
		/* add new data point to bottom of linked list */
		bottom = bottom->addafter(new geo(new point(x,y)));
		points::MAXpt.x = maxd( points::MAXpt.x, x );
		points::MAXpt.y = maxd( points::MAXpt.y, y );
		points::minpt.x = mind( points::minpt.x, x );
		points::minpt.y = mind( points::minpt.y, y );
        }

	*p = top; // return points

	// create buffer of width datarange/4 on all sides of square box
	coor diff = maxd( points::MAXpt.x - points::minpt.x, 
			  points::MAXpt.y - points::minpt.y );
	coor buff = diff/4;
 	if (buff==0) buff = 1; 
	points::MAXpt.x = points::minpt.x + diff + buff;
	points::MAXpt.y = points::minpt.y + diff + buff;
	points::minpt.x -= buff;
	points::minpt.y -= buff;

	//  ---- EDGES ----
	// edges have P on the LEFT = ccw side internally,
	// on the cw=right side in the input file.

	// start edge input data point stream
	strcpy( fnamebuf, fname );
	strcat( fnamebuf, ".in.e" );
	filebuf fbe;
	fbe.open( fnamebuf, ios::in ); //input
	istream fine(&fbe);


	// read edges
	int i, j;
	double ifloat, jfloat;
	needle pts( *p ); // record needle in point list
	top=0; //seperate list
	while (fine >> ifloat >> jfloat) {
		i= (int) ifloat; j= (int) jfloat; 
		//matlab saves in float format
		/* add new data point to top of linked list */
		top = new points( 
			new geo(new edge(), pts( i )->g, pts( j )->g ), top);
        }
        *e = top;
}


int geo::is_sub( geo * sup )  //is this a non-strict subface of sup?
{
    if ( this == 0 || sup == 0 ) return 0;
    if ( this == sup ) return 1;
    for (points * flist = superfaces; flist !=0; flist=flist->rest()) {
	if ( flist->first()->is_sub( sup )  )
	    return 1;
    }
    return 0;
}

// take a link out of the list from the middle
void splice( points ** head, points * prev, points ** current )
{
    if ( *current == 0 ) return;
    if (*head == *current) *head = (*head)->rest();
    points * newcurrent;
    if ( prev != 0 ) { 
	prev->next = (*current)->rest(); //fix list
	newcurrent = prev->rest();
    }
    else 
	newcurrent = 0;
    (*current)->next = 0; //for delete safety
    delete(*current);
    *current = newcurrent;  // iterates
}

#define pass target_box_big, target_box_small
#define see_either(p1,p2) (cw( p1, p2, t1 ) <= 0 || t2valid && cw( p1, p2, t2)<=0)
#define thissee( p1 ) (cw( *looker->endpt1(), *looker->endpt2(), p1 ) <= 0)
#define edgesee( e, p ) (cw( *(e).endpt1(), *(e).endpt2(), p ) <= 0)
#define edgeseep( e, p ) (cw( *(e)->endpt1(), *(e)->endpt2(), p ) <= 0)
#define see( p1, p2, t) (cw( p1, p2, t) <= 0)
#define edgesee_either(e) (cw( *(e).endpt1(), *(e).endpt2(), t1) || t2valid && cw( *(e).endpt1(), *(e).endpt2(), t2 ))

//bare bones visiblity tests
int edge::conesee(point * p, geo * thisg ) {
  return edgesee(*thisg,*p);
}

int point::conesee(point * p, geo * thisg ) {

  if (thisg->reflex())
    return edgesee(*thisg->superfaces->g,*p) ||  	
	   edgesee(*thisg->superfaces->rest()->g,*p);
  else
    return edgesee(*thisg->superfaces->g,*p) &&  	
	   edgesee(*thisg->superfaces->rest()->g,*p);
}

#define com << ","
void edump(int deb, geo* tar, geo* loo, int retval, int ctr)
{
  if (retval && deb) {
     cout << "\n" << ctr << " looker " << loo->endpt1()->x com <<  loo->endpt1()->y <<
	"  to  " << loo->endpt2()->x com <<  loo->endpt2()->y;
     cout << " sees "; 
     if (tar->subfaces)
       cout << "edge " << tar->endpt1()->x com <<  tar->endpt1()->y <<
        "  to  " << tar->endpt2()->x com <<  tar->endpt2()->y;
     else {
	point * p = (point*) tar->r;
	cout << "point " << p->x com << p->y;
     }
  }
}

int edge::conevisible_block_loc( geo* looker, geo* target,
	point* target_box_big, point* target_box_small ) 
//not good if target is a box edge
{
#define z1 looker->endpt1()
#define z2 looker->endpt2()
    int deb = ( z1->x >130 && z1->x < 135 && z1->y < 827 && z1->y>820 &&
		z2->x > 430 );
deb = 0;
#undef z1
#undef z2

    point p1, p2;
    if (!apex_points( looker, pass, &p1, &p2 ))
	p2 = p1;
	//looker may barely touches box, especially after warping
  
    point t1, t2;
    int t2valid = target->r->apex_points( target, pass, &t1, &t2 );

    geo * ch1 = looker->chum( looker->endpt1() ); //edge
    point * c1 = ch1->endpt1();  
    int c1_extends = !inbox( ch1->subfaces->first(), pass );

    geo * ch2 = looker->chum( looker->endpt2() ); //edge
    point * c2 = ch2->endpt2(); 
    int c2_extends = !inbox( ch2->subfaces->rest()->first(), pass );

    int consider_c2; point c2clip, junk;
    if (inbox(ch2, pass)) {
        consider_c2 = thissee( *c2 ); //more reliable that c2clip
	if (consider_c2)
	  {if (!apex_points( ch2, pass, &junk, &c2clip )) c2clip=junk;}
	else
	  c2clip = *c2; //c2clip is junk
    }
    else {
	consider_c2 = 0; c2clip = *c2; } //c2clip is junk 

    int consider_c1; point c1clip;
    if (inbox( ch1, pass )) {
        consider_c1 = thissee( *c1 );
	if (consider_c1)
	  apex_points( ch1, pass, &c1clip, &junk );
	else c1clip = *c1; //c1clip is junk
    }
    else {
	consider_c1 = 0;  c1clip = *c1; } //c1clip is junk 

    if (target->is_sub(ch1)) {edump(deb,target,looker,consider_c1,1);
	return(consider_c1);}
    if (target->is_sub(ch2)) {edump(deb,target,looker,consider_c2,2);
	return(consider_c2);}

  //nothing to get in the way
  if (!consider_c1 && !consider_c2)
	return (see_either( *looker->endpt1(), *looker->endpt2() ) );

  if (!see_either( *looker->endpt1(), *looker->endpt2() ) ) return 0; 

  //set up clipped target geo
  edge trep; geo t( &trep ); geo gt1(&t1); geo gt2(&t2);
  t.contains( &gt2 ); t.contains( &gt1 );

#define sqr(a) ((a)*(a))
  coor scale =  2 * sqr(*target_box_big - *target_box_small);
#undef sqr

  //set up outside edge from p1 to c2, if not consider just extend p
  edge prep; geo p1c2( &prep ); geo gp1( &p1 );
  point c2scale; geo gc2( &c2scale );
  p1c2.contains( &gc2 ); p1c2.contains( &gp1 );
  if (consider_c2)
    c2scale = c2clip;
  else
    c2scale = p2;
  c2scale = p1 + (c2scale-p1)*( scale / norm(c2scale-p1) );


  //set up outside edge from c1 to p2
  edge p2rep; geo c1p2( &p2rep ); geo gp2( &p2 ); 
  point c1scale; 
  geo gc1( &c1scale );
  c1p2.contains( &gp2 ); c1p2.contains( &gc1 );
  if (consider_c1) 
    c1scale = c1clip; 
  else
    c1scale = p1;
  c1scale = p2 + (c1scale-p2) * ( scale / norm(c1scale-p2) );

  if ( consider_c2 && !consider_c1 ) {
    if (c2_extends) //use fact that edges don't cross
	return ( thissee( t1 ) && edgeseep( ch2, t1) );

    else {
	if (cap(&p1c2,&t) || edgesee_either(p1c2)) return 1;
	//use non-crossing of edges
	return (thissee(t1) && edgeseep( ch2, t1));
    }
  }
  else if ( consider_c2 && !edgesee(p1c2, c1clip) ) {
      //replace p1 by c1 -- WATCH OUT
      p1 = c1clip; 
      //make c2scale colinear with c1 and c2
      c2scale = c1clip  + (c2clip - c1clip)*(scale / norm(c2clip - c1clip));

      if (cap(&p1c2, &t) || cap(&c1p2, &t) ) return 1;
      if ( edgesee( p1c2, t1 ) && edgesee( c1p2, t1 ) ) return 1;
					  // ^^ really c1c2
      return (
  	   edgeseep( ch2, t1 ) && thissee( t1 ) &&
            (edgeseep( ch1, t1) || edgesee( p1c2, t1 )) );
	  				  // ^^ really c1c2
  }
  else if ( consider_c1 && !consider_c2 ) {
    if (c1_extends) //use fact that edges don't cross
	return ( thissee( t1 ) && edgeseep( ch1, t1) );

    else {
	if (cap(&c1p2,&t) || edgesee_either(c1p2)) return 1;
	//use non-crossing of edges
	return (thissee(t1) && edgeseep( ch1, t1));
    }
  }


  else if ( consider_c1 && (!edgesee(c1p2, c2clip) || !consider_c2)) {
    //replace p2 by c2 -- WATCH OUT
    p2 = c2clip;
    //make c1scale colinear with c2 and c1
    c1scale = c2clip  + (c1clip - c2clip)*(scale / norm(c1clip - c2clip));

    if (cap(&p1c2, &t) || cap(&c1p2, &t) ) return 1;
    if ( edgesee( p1c2, t1 ) && edgesee( c1p2, t1 ) ) return 1;
					// ^^ really c1c2
    return (
	 edgeseep( ch1, t1 ) && thissee( t1 ) &&
          (edgeseep( ch2, t1) || edgesee( c1p2, t1 )) );
					// ^^ really c1c2
  }

  else { //both considered, both c1clip, c2clip seen by other
    if (c1_extends && c2_extends)
	return (edgeseep(ch1,t1) && edgeseep(ch2,t1));
    if (t2valid) {
        if (cap(&p1c2, &t) || cap(&c1p2, &t) ) return 1;
	if ( edgesee( p1c2, t1 ) && edgesee( c1p2, t1 ) ) return 1;
	//use the fact that edges don't cross 
	return ( thissee(t1) && (!consider_c1 || edgeseep( ch1, t1 ))
			&& (!consider_c2 || edgeseep( ch2, t1))
	  ||     thissee(t2) && (!consider_c1 || edgeseep( ch1, t2 ))
			&& (!consider_c2 || edgeseep( ch2, t2)) );
    }
    //else is just an optimization
    else { 
	if ( edgesee( p1c2, t1 ) && 
	     edgesee( c1p2, t1 ) ) return 1;
 	return ( 
	      edgeseep( ch1, t1 )  &&
	      edgeseep( ch2, t1 )   );
    }
  }

}

 /*
int edge::buddy( geo * e1, geo * target )
//true if target is an edge sharing the same vertex,
// and the vertex is not a reflex vertex
{
    if (looker != target) {
	geo * a = apex_common( looker, target );
	if (a != 0 && a != target) { //a is a common point vertex
	    return (!a->reflex());
	}
    }
    return 0;
}
*/

//noblock
int edge::conevisible_loc( geo * looker, geo*target, point* target_box_big, point * target_box_small ) 
// need to get a point from target inside the box
// then use ccw to determine if that point is visible to the edge
// { as specified in readdata(), P is to left=ccw of edge }
// assumes looker is a cone, and so extends outside of the box
{
    //assume there is some point of target in the box!
    //check if target is an edge sharing the same vertex
    if (looker != target) {
	geo * a = apex_common( looker, target );
	if (a != 0 && a != target) { //a is a common point vertex
	    return (!a->reflex());
	}
    }

    //normal case
    point p1, p2;
    int p2valid = target->r->apex_points( target, target_box_big,
        target_box_small, &p1, &p2 );
    return  
  	    (   cw( *looker->endpt1(), *looker->endpt2(), p1 ) <= 0 
	     || p2valid && 
		cw( *looker->endpt1(), *looker->endpt2(), p2 ) <= 0 
	    );
}


/*
// SEDGWICK, pg 315
double theta(point p1, point p2 ) {
    p2 -= p1;
    point pabs ( fabs(p2.x), fabs(p2.y) );
    if ( (p2.x==0) && (p2.y==0) ) return 0.0;
    double t = p2.y / ( pabs.x + pabs.y );
    if (p2.x<0) t = 2.0 - t;
    else if (p2.y<0) t += 4;
    return t;
}
#define maxtheta 4.0
*/

int geo::reflex( point** pt1, point** pt2)
//returns true if this is a strict reflex vertex
//sets pt1, pt2, so that polygon bdy is oriented
//pt1, this->r, pt2, with P on left of the two edges
{
    //find endpoints of edges meeting at this
    // pt1 is clockwisemost = has P on left of this_pt1
    geo * e = superfaces->first();
    if ( e->endpt1() == r ) {
	*pt1 = e->endpt2();
	*pt2 = superfaces->rest()->first()->endpt1();
    }
    else {
	*pt2 = e->endpt1();
	*pt1 = superfaces->rest()->first()->endpt2();
    }
    return (! (cw( **pt2, *(point*)r, **pt1 ) <= 0));
}


void dump( geo* target, int seen, point lookpt, int ctr )
{
//9 return;
if (!seen) return;
 
 	cout << "\n" << ctr << " lookpt = " << lookpt.x << "," << lookpt.y;

        if (seen) cout << " seen"; else cout << " NOT seen";
        if (target->subfaces==0) {
                point* p = (point*) target->r;
                cout << "point " << p->x << "," << p->y;
        }
        else {
                cout << "edge " << target->endpt1()->x << "," <<  target->endpt1
()->y << " to " << target->endpt2()->x << "," << target->endpt2()->y;
        }
}


int point::conevisible_loc( geo* looker, geo* target,
	point* target_box_big, point* target_box_small ) {

int deb = ( x<464 && x>463 && y <449 && y>448 );
deb = 0;

    //degenerate point, can see everydirection
    if (looker->superfaces == 0) {
	cout << " no superface ";
	cout << x << "," << y << "\n";
	return 1; 
    }

    if (target->is_sub( looker->superfaces->first() ) ||
	target->is_sub( looker->superfaces->rest()->first() ))
    {
	if (deb) dump(target,1,*this,0);
	return 1;
    }

    point t1, t2;
    int t2valid = target->r->apex_points( target, target_box_big, 
	target_box_small, &t1, &t2 );

if (t2valid && (t2.x == -99)) cout << " valid error ";
else if (deb) cout << "\n apex pts " << t1.x << "," << t1.y << " & "
	<< t2.x << "," << t2.y;

    //case reflex vertex
    point* pt1;
    point* pt2;
    if (looker->reflex(&pt1, &pt2)) {
	//see_either is a macro, relying on t1 and t2 
	if (deb) dump(target, 
	  see_either( *pt2, *this ) || see_either( *this, *pt1 ) ,*this,1);
	return see_either( *pt2, *this ) || see_either( *this, *pt1 );
    }
    //case non-reflex vertex
    else {
 	if (t2valid) {
	    int pt2t1 = (cw( *pt2, *this, t1 ) <= 0);
	    int pt2t2 = (cw( *pt2, *this, t2 ) <= 0);
	    int pt1t1 = (cw( *this, *pt1, t1 ) <= 0);
	    int pt1t2 = (cw( *this, *pt1, t2 ) <= 0);

if (deb) cout << pt2t1 sp << pt2t2 sp << pt1t1 sp << pt1t2;

	    //neither of the target apex points are seen by one or both
	    // of the hyperplanes --> vertex cone apex cant see.
	    if (!(pt2t1 || pt2t2) || !(pt1t1 || pt1t2)) return 0;

	    //both ts are on same side of some cone hyperplane
	    if (pt2t1 && pt2t2){ 
		if (deb) dump(target, pt1t1 || pt1t2,*this,2);
		return (pt1t1 || pt1t2); }
	    if (pt1t1 && pt1t2){ 
		if (deb) dump(target, pt2t1 || pt2t2,*this,3);
		return (pt2t1 || pt2t2); }

	    //some t is seen by both hyperplanes
	    if (pt1t1 && pt2t1 || pt1t2 && pt2t2) {  
		if (deb) dump(target,
			 (pt1t1 && pt2t1 || pt1t2 && pt2t2),*this,4); 
		return 1;}

	    //else, one t is seen by one hyp, the other t by the other hyp
	    //so t1_t2 either cuts cone, or passes behind it. note >=
//9
	    if (deb) dump(target, (pt1t1) ?  (cw(t1, t2, *this) >= 0) :
                              (cw(t2, t1, *this) >= 0),*this,5);
	    return (pt1t1) ?  (cw(t1, t2, *this) >= 0) :
			      (cw(t2, t1, *this) >= 0);

	}
	else { // target a single point t1
	    if (deb) dump(target, 
		see( *pt2, *this, t1 ) && see( *this, *pt1, t1 ),*this,6);
	    return (see( *pt2, *this, t1 ) && see( *this, *pt1, t1 ));
	}
    }


/* old, doesn't work in all cases
    // compute theta, see if data between endpoints
    double theta0 = theta( *this, *pt1 );
    double theta1 = theta( *this, *pt2 );
    double theta_target = theta( *this, target->r->apex_point( target, 
	target_box_big, target_box_small ) );

    // wrap around zero
    if (theta1<theta0) theta1 += maxtheta;
    if (theta_target<theta0) theta_target += maxtheta;

    return (theta_target<=theta1);
*/
}

int point::conevisible_block_loc( geo* looker, geo* target,
	point* target_box_big, point* target_box_small ) {
    return conevisible_loc( looker, target, target_box_big,
	target_box_small );
	//no difference for points
}

// can cone with apex this=looker see {cone with} apex target
int conevisible_noblock( geo* looker, geo* target,
		point* target_box_big, point* target_box_small  ) 
{
    // need to check if one face is a subset of the other
    // this is different than checking if they intersect,
    // as the two edges of a reflex vertex should not be 
    // visible to one another for proper results elsewhere.
    if (target == 0 || looker == 0) return 0;
    if (looker->is_sub(target) || target->is_sub(looker)) return 1;
    return looker->r->conevisible_loc( looker, target,
	 target_box_big, target_box_small );
}

// can cone with apex this=looker see {cone with} apex target
//block means, chum edges can block visibility
int conevisible_block( geo* looker, geo* target,
		point* target_box_big, point* target_box_small  ) 
{
    if (target == 0 || looker == 0) return 0;
    if (looker->is_sub(target) || target->is_sub(looker)) return 1;
    return looker->r->conevisible_block_loc( looker, target,
	 target_box_big, target_box_small );
}


// used by apex_common, mark.c all non-strict subfaces using depth first search
void geo::mark_sub_c(int i) {
    markcit(i);
    for ( points * sub = subfaces; sub != 0; sub=sub->rest() ) {
	sub->first()->mark_sub_c(i);
    }
}

// search, breadth first, for a subface that's marked=belongs to other geo
// a little heavy duty for 2d or 3d, but hey
geo * geo::find_sub_c() {
    points * head = new points( this ); 
    points * last;  last = head;
    while ( head != 0 ) 
    {
	geo * g=head->first();
	head = head->pop();
	if (g->markc()) { delete head; return g; }
        for ( points * sub = g->subfaces; sub != 0; sub=sub->rest() ) {
	    if (head == 0) {
		last = new points(sub->first());
		head = last;
	    }
	    else { last=last->addafter(sub->first()); }
	}
    }
    return 0;
}


// find the "meet" of g1 and g2
geo * apex_common ( geo * g1, geo * g2 )
{
    if ( g1==0 || g2==0 ) return 0;
    g1->mark_sub_c(1);
    geo * result = g2->find_sub_c();
    g1->mark_sub_c(0);
    return result;
}

#define max(a,b) (a>b ? a : b)
//return coor of where they intersect
point crossingpt(geo * e1, geo * e2)
{
  return crossingpt(*e1->endpt1(), *e1->endpt2(), *e2->endpt1(), *e2->endpt2());
}

point crossingpt( point p1, point p12, point p2, point p22 )
//two lines, p1 to p12, and p2 to p22.
//calculate the point at which they cross, (assumes that they do, see )
{
    // z = p1 + t1*v1 = p2 + t2*v2
    // v1 * t1 = ( p2 - p1 + t2*v2 ) 
    
    point v1 = p12 - p1;
    point v2 = p22 - p2;

    // the solution is ill conditioned if lines are perp or parallel
    // fortunately, in perp case there is an easy approx solution ON e1
    // and in paralell case, this procedure is not entered
    coor det = v1.x * v2.y - v1.y * v2.x;
    coor m = max( max(fabs(v1.x), fabs(v2.x)), max(fabs(v1.y),fabs(v2.y)) );

    if (fabs(det) / (m*m) < 1.0e-7) {

//9
/*
cout << "-------- ILL CONDITIONED: don't worry, projecting instead ------" nl;
cout << " p2 = " << p2.x << "," << p2.y;
cout << " v2 = " << v2.x << "," << v2.y;
cout << " p1 = " << p1.x << "," << p1.y;
cout << " v1 = " << v1.x << "," << v1.y;
point ret = p2 + v2 *( (p1-p2) * v2 / norm(v2));
cout << " ret = " << ret.x << "," << ret.y << "\n";
*/
	// closest point of line to one endpoint!
	return p2 + v2 *( (p1-p2) * v2 / norm(v2));
	//          ^v^    ^ scalar ^
    }

    coor t = (v1.y*(p2.x-p1.x) - v1.x*(p2.y-p1.y))/det;
    return p2 + v2*t;
}


int inbox( geo * g, point* big,  point* lit )
//pass geo,
//test if geo is in the truly square box
{
 
    //build relevant part of lattice for box edges
    edge e; point p1, p2;
    geo boxedge(&e), g1(&p1), g2(&p2);
    boxedge.contains( &g1 );
    boxedge.contains( &g2 );


    p1 = *big;
    p2.x = big->x; p2.y = lit->y;
    if ( g->r->cap( g, &boxedge ) == 1) return 1;

    p2.x = lit->x; p2.y = big->y;
    if ( g->r->cap( g, &boxedge ) == 1) return 1;

    p1 = *lit;
    p2.x = big->x; p2.y = lit->y;
    if ( g->r->cap( g, &boxedge ) == 1) return 1;

    p2.x = lit->x; p2.y = big->y;
    if ( g->r->cap( g, &boxedge ) == 1) return 1;

    // ---- test if wholly contained ----
    point * pt = g->inbox_testpoint();
    // according to compass.h,  +x = East,  +y = South
    return (
	(pt->x >= lit->x) && 
	(pt->x <= big->x) &&
	(pt->y >= lit->y) && 
	(pt->y <= big->y)
    );



}


inline int strict_ecap_contain_loc( coor& x1, coor& x2, coor& x3, coor& x4) {
    return between_noorder(x1,x2,x3) && between_noorder(x1,x2,x4);  //ok not strict_between
}


inline int strict_ecap_contain(point& c1, point& c2, point& e1, point& e2 ) {
    return (fabs(c1.y-c2.y)<fabs(c1.x-c2.x)) ? 
	strict_ecap_contain_loc( c1.x, c2.x, e1.x, e2.x )
	:
	strict_ecap_contain_loc( c2.y, c1.y, e1.y, e2.y );
}

int strict_cap(point * c1, point *c2, point* e1, point * e2)
{
  
    int cw1 = cw( *c1, *c2, *e1 ), cw2 = cw( *c1, *c2, *e2 ),
	cw3 = cw( *e1, *e2, *c1 ), cw4 = cw( *e1, *e2, *c2 );

    if ((cw1==0) && (cw2==0))  { // Pedge contains Oedge?
	return strict_ecap_contain( *c1, *c2, *e1, *e2 );
    }
    if ((cw3 == 0) || (cw4 == 0))
	return 0;  //other checks 
    else {
	return ((cw1 != cw2) && (cw3 != cw4));
    }

}

int put_edge_inbox( geo * g, point* big,  point* lit, points * touch_verts )
//pass geo,
//test if edge belongs  in this square box
// put in the square if
//   strictly intersects a box side
//   contains a box side
//   contains a vertex in this box
//   has a point strictly inside the box
{


    point * c1 = (point*) g->subfaces->g->r; 
    point * c2 = (point*) g->subfaces->rest()->g->r;


    //build relevant part of lattice for box edges
    edge e; point p1, p2;
    geo boxedge(&e), g1(&p1), g2(&p2);
    boxedge.contains( &g1 );
    boxedge.contains( &g2 );


    p1 = *big;
    p2.x = big->x; p2.y = lit->y;
    if ( strict_cap( c1,c2, &p1, &p2 ) == 1) return 1;

    p2.x = lit->x; p2.y = big->y;
    if ( strict_cap( c1,c2, &p1, &p2 ) == 1) return 1;

    p1 = *lit;
    p2.x = big->x; p2.y = lit->y;
    if ( strict_cap( c1,c2, &p1, &p2 ) == 1) return 1;

    p2.x = lit->x; p2.y = big->y;
    if ( strict_cap( c1,c2, &p1, &p2 ) == 1) return 1;

    for (points * tv = touch_verts; tv; tv=tv->rest())
	if ((c1 == tv->g->r) || (c2 == tv->g->r)) return 1;

    // ---- test if wholly contained ----
    point pt = midpoint(*c1,*c2);
    return (
	(pt.x > lit->x) && 
	(pt.x < big->x) &&
	(pt.y > lit->y) && 
	(pt.y < big->y)
    );



}
