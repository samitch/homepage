// tripoint -- triangulate a set of input points
// Scott Mitchell, Xerox PARC, 1991
// David Eppstein, Xerox PARC, 28 Feb 1990

#include <iostream.h>
#include "ptquad.h"
#include "point.h"
#include "segdraw.h"
#include "defines.h"


char * fname; /*filename without extension for input and output*/

char * decide_io( int argc, char * argv[] ) {
    switch (argc) {
    case 1:
	cout << "*** Tripoint 2.05 for g++ ***" nl
	     << "      usage: tripoint FILENAME" nl
	     << "      Inputs FILENAME.in.p and FILENAME.in.e:" nl
	     << "        polygon vertex coordinates and edge incidence." nl
	     << "      Outputs FILENAME.p, FILENAME.e, and quadsquares.mdat:" nl
	     << "        mesh vertex coordinates, edge incidence, and quadtree squares used." nl
	     << "      See also users.guide.doc, inside.tripoint.doc, status.doc" nl;
	//exit(1);
	return 0;
    default:
	cout << "+++ Triangulating with tripoint 2.03, please wait . . . ";
	cout.flush();
	return( argv[1] );
    }
}

main(int argc, char * argv[]) {

  fname = decide_io(argc, argv);
  if (fname!=0) {
    points * ptlist;
    points * elist;
    readdata(fname, &ptlist, &elist);

    ptquad pq(ptlist,elist);

    //9 pq.testboxes();
    translate_segdrawer sd( point(0,0), fname );
    //				 ^^^^ translate output by this amount
    pq.draw(&sd);
    cout << "done! +++\n";
  }
}
