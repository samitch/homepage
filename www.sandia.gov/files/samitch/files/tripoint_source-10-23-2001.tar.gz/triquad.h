// triquad - triangulated quadtree
// Scott Mitchell, Xerox PARC, 1991
// David Eppstein, Xerox PARC, 27 Feb 1990
//
// the triangulation may do some local merging of squares...

#ifndef TRIQUAD_H
#define TRIQUAD_H

#include "evenquad.h"
#include "point.h"

class crosspt {
  public:
    snap_point * me;  // where this crosses
    geo * crosse;    // the edge crossing the box
    snap_point * p1, * p2;  // endpoints box edge the edge crosses
    snap_point * vbox; //endpoint that isn't shared, for reflex vertex box
    int vboxsub; //vbox subs for p1 or p2
    crosspt * next;

    //CONSTRUCTORS
    crosspt() { me = 0; crosse = 0; p1=0; p2=0; vbox=0; next = 0; vboxsub=0; }
    crosspt(snap_point * inme, geo * incrosse, snap_point *inp1, snap_point 
	* inp2, crosspt * first, snap_point* vboxin = 0, int vboxsubin = 0 )
    { me=inme; crosse=incrosse; p1=inp1; p2=inp2; next=first; vbox=vboxin; 
      vboxsub = vboxsubin; }

    //this is first in the list of crosspts
    crosspt * findcrosspt( geo * e, snap_point *c1, snap_point *c2 );
    void sharedata( crosspt * source )
	{ me->changeallptrs( &source->me ); }
    void calc_cross();

};

class triquad : public evenquad {
public:
    enum { tq_split, tq_unsplit, tq_gone } state;
    crosspt * crosses;
//sides should be protected in some way
    snap_point * sides[4];
private:
    corner_direction father_corner;
    snap_point * center;
public:
    snap_point * centroid;
    int centroid_side;  //1 if snap to a side, 0 else
    int centroid_index; //neighbor_direction or corner_direction

    triquad * dup;   /* duplicate box list 		*/
			// note:  this box has copies of whats in the
			// duplicated boxes, but the child boxes don't
    triquad * next;		// queue of merges to try

private:
    // internal subroutines to draw()

    int drawit_hide; //mark, do we draw this or not
public:
    int drawit() { return drawit_hide; }
    void set_draw() { drawit_hide=1; }
    void recur_fix_sharecorners();
    int leaf_box_point_vis( snap_point * p );
    int leaf_box_geo_point_vis( geo* looker, snap_point * p );
    //this is a leaf box, p is a corner or side of the box
    //true is leaf can see p
    void get_corner_vis( triquad*nb,
	snap_point* p1, snap_point* p2, 
	int* cor1, int* cor2, int* ncor1, int* ncor2) 
    {
	*cor1 = leaf_box_point_vis( p1 );
	*cor2 = leaf_box_point_vis( p2 );
	*ncor1 = nb->leaf_box_point_vis( p1 );
	*ncor2 = nb->leaf_box_point_vis( p2 );
    }


private:
    void do_draw(segdrawer * s);
    void draw_box(segdrawer *s);
    void do_cross(); //warp and calculate crossingpoints
    void decide_draw_neighbor_child( neighbor_direction n );
    void decide_draw_dups();
    void decide_draw_this();
    triquad * find_full_leaf();
    void decide_draw_neighbors();
    void decide_draw();
    //non_empty instance never called, always ptquad::non_empty
    virtual int non_empty() { return 0; }

    void enqueue(triquad *&);
    triquad * dequeue(triquad *&);

    void set_sides(int, ostream & f);
    void set_sides_loc(triquad * orig, ostream & f);
    void copy_corners();
    void make_unsplit();

    double merged_aspect(neighbor_direction);
    double side_aspect(neighbor_direction);
    double diag_aspect(corner_direction);
    double corner_aspect(corner_direction);
    corner_direction good_diag();

    int some_side_split();
    int can_merge(corner_direction,corner_direction);
    int merge_ok(neighbor_direction);

    int children_mergable(neighbor_direction);
    int child_sides_removable(corner_direction);
    int side_removable(neighbor_direction);
    void remove_side(neighbor_direction);

    int bad_quad(int,int);
    int find_stuck_point(snap_point *);
    int move_corner(corner_direction);
    void move_center(neighbor_direction);

    void unmark_all(int);
    void unmark_neighbors();
    void merge();

    int merged(neighbor_direction);
    int draw_split() { return (state == tq_split); }

    void draw_side( snap_point* p1, snap_point* p2, segdrawer* s );
    virtual void draw_crosses(segdrawer *) = 0;
    virtual void draw_diags(segdrawer *) = 0;
    virtual int no_volume() {return 0;}


 public:
    virtual void draw_sub(segdrawer *);

    // CONSTRUCTORS
    triquad() { drawit_hide=0; centroid=0; next=0; sides[0]=0; sides[1]=0; sides[2]=0; sides[3]=0; }
    triquad(points * ptlist) : evenquad(ptlist) { 
	drawit_hide=0; centroid = 0; next = 0; sides[0]=0; sides[1]=0; sides[2]=0; sides[3]=0; }

    triquad * father() { return (triquad *) quadtree::father(); }
    triquad * child(corner_direction c) {
	return (triquad *) quadtree::child(c);
    }
    triquad * neighbor(neighbor_direction n) {
	return (triquad *) quadtree::neighbor(n);
    }

    // send borders and diagonals to segment drawer
    void draw(segdrawer * s);
 
   friend int adjacent( neighbor_direction d, quadtree * qt1, quadtree * qt2 );
   friend int true_adjacent(corner_direction c, neighbor_direction n,
 quadtree* qt1in, quadtree* qt2in, int qt2small);

 //returns correct adjacency after boxes have been duplicated

    friend int balance_adjacent( neighbor_direction d, quadtree* qt1in, quadtree* qt2in); //for balance

   virtual void swap(quadtree * dp) { evenquad::swap(dp); }

   triquad * getlast();
   void add_dup(triquad * dp);

   //virtual evenquad
   void dup_children ( triquad * dp );
   void dupbalance(evenquad * fneven,neighbor_direction d);

   // split boxes with vertex and a nearby box smaller
   // see triquad.c for details
   void do_special_balance_recur();
private:
   int special_balance_recur();
   int special_balance(triquad* orig);

public:

   void warp();

   //virtual ptquad stuff
   virtual int has_Pvertex() = 0;
   virtual void warpbox() = 0;
   virtual void get_all_crosses(crosspt** , crosspt** , 
				snap_point * , snap_point * ) = 0;
   virtual geo * lf_apex() {return 0;}
   virtual void share_edge_crosses(snap_point* , snap_point* , 
	snap_point* , int , triquad * ) = 0;
   virtual void set_edge_crosses() = 0;

   virtual void testup() = 0;
   virtual void testme() = 0;

   virtual void settest() = 0;
   friend void dumptest(int ctrl);
   virtual void cond_dump(int ctrl) = 0;

   snap_point * side(neighbor_direction n) {return sides[n];}

 };


#endif
