// quad.h  -- base data structure for quadtrees
// Scott Mitchell, Xerox PARC, 1991
// David Eppstein, Xerox PARC, 27 Feb 1990
//
// Each square has four corners (northeast, northwest, southeast, southwest).
// Each square has up to four neighbors (north, south, east, west).
// Each split square has four children, and must have all four neighbors
// unless some such neighbors are outside the whole quadtree.

#ifndef QUADTREE_H
#define QUADTREE_H


#include "snap.h"
#include "segdraw.h"

//SAM Note: corners are pointers, and the same snap_point (coordinates,state...)
//          is pointed to by several quadtree boxes.  Hence, roundoff, etc
//          is not a problem.


class quadtree {
    quadtree * parent;
    quadtree * neighbors[4];
    quadtree * children[4];
    corner_direction father_corner;
public: 
    int is_leaf;
    snap_point * corners[4];
    int drops;

public:  
    quadtree();			// called by split, which will fill out stuff
                                // EPP had this constructor private
    quadtree( points * ptlist );
    virtual quadtree * new_quad() = 0;

    //make neighbors of condemmed point to this
    void redirect_neighbors( quadtree* condemmed );
    void setnb( neighbor_direction n, quadtree * nb ) 
	{ neighbors[n] = nb; }

    virtual void balance() { ; } // subroutine to enforce balance
    //make duplicates of this:
    virtual void recurse(int ) = 0;
    virtual int has_Pvertex() {return 0;} //ptquad.h

    virtual void split_sub(int ) = 0; // subroutine to distribute contains
    virtual void join_sub() { ; } // subroutine to join subclass data

    virtual ~quadtree();

    void split(int unmarked_only=0);	// subdivide this square
    void join();		// undo effects of split

    void fixcorners(); //for leaf boxes all having own copy of corners
    void changecorner( corner_direction c, snap_point * changeto )
    { changeto->changeallptrs( &corners[c] ); }

    // drop_child not used at present
    int isdrop_neighbor( neighbor_direction n ) { return (drops >> n) & 01;}
    void drop_neighbor( neighbor_direction n ) { 
	drops |= 01 << n; }
    int somedrop() { return ( (drops & 0xf) > 0); }
    void drop_all() { drops |= 0xf; }
    void zerodrops() { drops=0; }
    void copydrops(quadtree * source) { drops = source->drops; }
    //set qt1->neighbors[d]=qt2 and reverse, or drop neighbors

    virtual int non_empty(){ return 1; } //never called 

    int is_top() { return parent == 0; }
    int is_split() { return (children[0] != 0); }
    snap_point * corner(corner_direction i) { return corners[i]; }
    snap_point * smallcorner() { return corners[northwest]; }
    snap_point * bigcorner() { return corners[southeast]; }
    quadtree * child(corner_direction i) { return children[i]; }
    quadtree * neighbor(neighbor_direction i) { return neighbors[i]; }
    quadtree * father() { return parent; }
    void samefather(quadtree * orig) { parent = orig->parent; 
	father_corner = orig->father_corner; }
    corner_direction which_child() {return father_corner; }
    double h() {  //char length of box == diagonal
         return dist( (point*) bigcorner(), (point*) smallcorner() ); }

    friend int adjacent( neighbor_direction d, quadtree * qt1, quadtree * qt2 );

    virtual void swap(quadtree * o);

    void sharecorners(neighbor_direction n, quadtree * nb);
    void samecorners(quadtree * orig);
    void sameneighbors(quadtree * orig);

    friend int conevisible_block_q( geo* looker, geo* target, quadtree* lbox, quadtree* tbox );
    friend int conevisible_noblock_q( geo* looker, geo* target, quadtree* lbox, quadtree* tbox );
    friend void get_extreme_corners(quadtree* lbox, quadtree* tbox, point* big, point* lit );

friend void set_nb_nodrop(neighbor_direction d, quadtree * qt1, quadtree * qt2);
friend void set_neighbor(neighbor_direction d, quadtree * qt1, quadtree * qt2);


  //--------- debugging --------
  virtual int testintegrity() {return 0;} //virtual ptquad.h

};

#endif
