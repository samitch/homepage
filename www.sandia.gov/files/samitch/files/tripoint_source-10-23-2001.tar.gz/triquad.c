// triquad - triangulated quadtree
// Scott Mitchell, Xerox PARC, 1991
// David Eppstein, Xerox PARC, 27 Feb 1990

#include <iostream.h>
#include <fstream.h>
#include "triquad.h"
#include "aspect.h"
#include "snap.h"
#include "segdraw.h"


//#define DOHEURISTIC
#include "defines.h"

//------ CROSSPT ------ crosspt ----------
crosspt * crosspt::findcrosspt( geo * e, snap_point *c1, snap_point *c2 )
{
    if (this==0) return 0;
    int found1 = (c1==p1 || c1==p2 || vbox!=0 && c1==vbox);
    int found2 = (c2==p1 || c2==p2 || vbox!=0 && c2==vbox);
    return (e==crosse && found1 && found2)  ?
	this : next->findcrosspt( e, c1, c2 );
}

void convert (snap_point* dest, snap_point** source, geo * /*crosse*/)
{
    if ((*source)->who->superfaces) {
    //9if (dest->who == 0 || dest->who != (*source)->who) {
	dest->snap( **source );
	dest->who = (*source)->who;
    }
    dest->changeallptrs( source );
}

void crosspt::calc_cross()
{
    if (!crosse) cout << "triquad.c calc_cross error ";
//9

    // snap it to endpoints
    //check if either endpoint is snapped to it, or an endpt of it
    //change vbox to me, etc, so that we never remove a point thats been
    //used to draw already.
    if ( me->who && me->who->is_sub(crosse) ) return;

    if (vbox) if ( vbox->who->is_sub(crosse) ) {
/*
	  if (me->snapped()) {   //maybe already written id
	    if (me->who == vbox->who) {
	       me->snap( *vbox );
	       me->who = vbox->who; //vbox->who may be a vertex, me->who an edge
	       me->changeallptrs( &vbox );
	    }
	  }
	  else 
 	     vbox->changeallptrs( &me ); 
*/
	//p1 may have been drawn already, but not vbox, don't draw two points with
	// the same coordinates
	if (vboxsub==1)
		if ((*p1 == *vbox) || (p1->who == 0) /*|| (vbox->who==0) */) convert(p1,&vbox,crosse); 
		else { vbox->changeallptrs( &me ); return; }
        else if (vboxsub==2) 
		if ((*p2 == *vbox) || (p2->who == 0) /* || (vbox->who==0) */ ) convert(p2,&vbox,crosse);
		else { vbox->changeallptrs( &me ); return; }
    }

    if ( p1->who->is_sub(crosse) ) {
        p1->changeallptrs( &me ); return; }
    if ( p2->who->is_sub(crosse) ) {
        p2->changeallptrs( &me ); return; }

    // calculate where it goes, only done once
    if (!me->snapped()) {
	//calculate where it goes, and snap to it
	edge oerep;  geo oe(&oerep), g1(p1), g2(p2);
	oe.contains(&g1); oe.contains(&g2);
	me->snap( crossingpt( &oe, crosse ) );
	me->who = crosse;
    }
}


//------- TRIQUAD -------- triquad ----------

static const double good_aspect = 3.0;
static int phase; // whether we are on first or second pass
static triquad * do_list;
static int nlevels;

void triquad::draw(segdrawer * s) {
    //split boxes with a Pvertex to same size as neighbors
    do_special_balance_recur(); 
    copy_corners(); //give leaves there own copy of corners
    do_list = 0;

    //report unwarped quadtree boxes
    filebuf unwarpedboxes;
    unwarpedboxes.open("quadsquares",ios::out);
    ostream * f = new ostream(&unwarpedboxes);
    set_sides(0,*f);  //also sets shared corners

    //9 testup();

    // apply heuristics
#ifdef DOHEURISTIC
    for (phase = 0; phase < 2; phase++) {
	unmark_all(0);
	while (do_list != 0) do_list->dequeue(do_list)->merge();
    }
#endif
    draw_sub(s);

}


void triquad::copy_corners()
{
    if (is_split())
	for ( corner_direction c=0; c<4; c++ )
	    child(c)->copy_corners();
    else
	fixcorners();
    for (triquad * dp = dup; dp != 0; dp=dp->dup )
	if (!dp->is_split())
	    dp->fixcorners();
    // we don't care about old copies, or wasted space for keeping old copies
    // around.
}

// maintain queue of merges to try
//
// represented as a singly linked list terminated by a self-loop
// call by	triquad->enqueue(list)
//		list->dequeue(list)->...  (yes this is ugly...)

void triquad::enqueue(triquad *&)
{
    if (next == 0) {
	next = (do_list != 0? do_list : this);
	do_list = this;
    }
}

triquad * triquad::dequeue(triquad *&)
{
    do_list = (next == this? 0 : next);
    next = 0;
    return this;
}


// remove the center of a quad

void triquad::make_unsplit()
{
    if (state == tq_split) {
	state = tq_unsplit;
	if (is_split()) for (corner_direction c = 0; c < 4; c++) {
	    child(c)->make_unsplit();
	    child(c)->state = tq_gone;
	}
    }
}


//set the sides and true neighbors of this
//this is either orig or a duplicate of orig
//must be called for duplicates *before* for orig
void triquad::set_sides_loc(triquad * orig, ostream & f)
{
    next = 0;
    if (is_split()) {
	state = tq_split;
	center = child(northeast)->corner(southwest);
	return;
    } else {
	state = tq_unsplit;
	center = 0;
    }

    //report unwarped box:
    coor b = 0; //(bigcorner()->x - smallcorner()->x) / 12;
    f    << corners[northeast]->x -b sp << corners[northeast]->y +b nl
         << corners[southeast]->x -b sp << corners[southeast]->y -b nl
         << corners[southwest]->x +b sp << corners[southwest]->y -b nl
         << corners[northwest]->x +b sp << corners[northwest]->y +b nl
    ;

    int cor1, cor2, ncor1, ncor2; //whether this, nb can see corner1, corner2
    
    //don't look up a level, but need to look down perhaps
    for (neighbor_direction n=0; n<4; n++) {

	//9 int debloc = deb && n==south;

	sides[n] = 0; //maybe changed below
	if (orig->neighbor(n)==0) continue; 

	//We may share with a box AND its duplicates.  This is necessary, 
	// as in the case of a near 360 
        // reflex vertex box and the two neighboring duplicate boxes 
	// containing the edges.
	//Note that valuable neighbor information could be overwritten
	//therefore, it is necessary to consider duplicates seperately
	//when marching through triquad::decide_draw.

	for( triquad * nb = orig->neighbor(n); nb != 0; nb=nb->dup )  {
	  //9 if (debloc) cout << " nb "; 

	  // neighbor is smaller
	  if (nb->is_split()) {
	    //k=kid of neighbor, with whom this should share a corner
	    triquad * k;  
	    int i; //counter, to count both k's
 	    //c=which corner of orig to share
	    //ck=which corner of k to share with this->corner(c)
	    //ckmid=whick corner of k to share with this->side[n]
	    corner_direction c, ck, ckmid;
	    //check both children of neighbor that could be adjacent
	    for ( ck = cl_corner(opp_neighbor(n)),
		  ckmid = ccl_corner(opp_neighbor(n)),
		  c = ccl_corner(n),
		  i=0;
		  i<2;
		  ck = ccl_corner(opp_neighbor(n)),
		  ckmid = cl_corner(opp_neighbor(n)),
		  c = cl_corner(n), 
		  i++
		) 
	    {
		//9 if (debloc) cout << "is small "; 
		k = nb->child(ck);
		for (; k != 0; k=k->dup )
		    if( !k->is_split() && // not two levels
	(  ( (k->has_Pvertex()==1) && (true_adjacent(c,n,this,k,1)==1) ) ||
           ( (k->has_Pvertex()==0) && (true_adjacent(c,n,this,k,2)==1) )  ) ) {
		    /* 2 is a special flag, saying treat these boxes
			as adjacent if they share a common edge, or the
			usual tests hold 
		    */
		      if (k->has_Pvertex() || has_Pvertex()) {
			//by special balance, k->has_Pvertex never 1
			//9
		        if (has_Pvertex()) {
			  cout << "triquad.c: special balance violated \n";
			  cout << "this box: "
			  << bigcorner()->x << "," << bigcorner()->y << " : " 
			  << smallcorner()->x << "," << smallcorner()->y << 
			  "\n";
			  testme();
			  cout << "small vertex box " << 
			  k->bigcorner()->x << "," << k->bigcorner()->y
			  << " : " << k->smallcorner()->x << "," << 
			  k->smallcorner()->y << "\n";
			  k->testme();
			}
			snap_point* vbox = 0; snap_point* ebox = 0;

			get_corner_vis(k,k->corner(ckmid), k->corner(ck),
				&cor1,&cor2,&ncor1,&ncor2);
			int none_seen = (!cor1 || !ncor1) && (!cor2 || !ncor2);
			int diffpt = 0;

			// side
			if ((cor1==1 && ncor1==1) || none_seen )  
			    k->corner(ckmid)->changeallptrs( &sides[n]); 
			else { 
			   diffpt = 1;
                           if (sides[n] == 0) {
                                sides[n] = new snap_point( k->corner(ckmid)->x,
					k->corner(ckmid)->y); //leave as is
				side(n)->addbackptr( &sides[n] );
			   }
			   if (has_Pvertex()) { //never by special_balance
				cout << "err0 in triquad.c set_sides";
				vbox = sides[n];
				ebox = k->corner(ckmid);
			   }
			   else { //actually, we both shouldn't be able to see 
                                ebox = sides[n];
                                vbox = k->corner(ckmid);
			   }
			}


			// corners
			if ( (cor2==1 && ncor2==1) || none_seen ) 
			    changecorner( c, k->corner(ck) ); 
                        else {
			   diffpt=2;
                           if (has_Pvertex()) { //never by special balance
				cout << "err1 in triquad.c set_sides";
                                vbox = corner(c);
                                ebox = k->corner(ck);
                           }
                           else {
                                ebox = corner(c);
                                vbox = k->corner(ck);
                           }
                        }

			// P edges that cross common box edge
			//do AFTER sharing side/corner
			if (cor1!=ncor1 && cor2!=ncor2) { ;
			  //this can happen if no P_vertex below, but not here
			}
			else if (diffpt==1)  
			  share_edge_crosses(ebox, corner(c), vbox, diffpt, k); 
			else if (diffpt==2) 
			  share_edge_crosses( side(n), ebox, vbox, diffpt, k );
			else 
			  share_edge_crosses(side(n), corner(c),vbox,diffpt,k); 
			  /* vbox and diffpt should both be 0 */
		      }
		      else /*simpler case, no Pvertex*/ {
			    k->corner(ckmid)->changeallptrs( &sides[n]); 
			    changecorner( c, k->corner(ck) ); 
			    share_edge_crosses( side(n), corner(c), 0, 0, k); 
		      }

		    } //true adjacent
	    } //for ck, etc
	  }

	  //neighbor is same size
	  else {
	    //9 if (debloc) cout << "is big"; //9
	    if (true_adjacent(cl_corner(n),n,this,nb,0)) {
		//9 if (debloc) cout << "&adja ";
	     if (nb->has_Pvertex() || has_Pvertex()) {
        	snap_point* vbox = 0; snap_point* ebox = 0;
		get_corner_vis(nb,corner(cl_corner(n)), corner(ccl_corner(n)),
			&cor1,&cor2,&ncor1,&ncor2);
		int none_seen = (!cor1 || !ncor1) && (!cor2 || !ncor2);
		int diffpt=0;

		if ( (cor1==1 && ncor1==1) || none_seen)  //usual case
		  changecorner( cl_corner(n), 
			nb->corner( ccl_corner(opp_neighbor(n)))  );
		else {
		  diffpt=1;
		  if (has_Pvertex()) {
			vbox = corner(cl_corner(n));
			ebox = nb->corner(ccl_corner(opp_neighbor(n))); 
		  }
		  else { //nb->has_Pvertex()
			vbox = nb->corner(ccl_corner(opp_neighbor(n)));
			ebox = corner(cl_corner(n));
		  } 
		}

		if ((cor2==1 && ncor2==1) || none_seen)  //usual case
		  changecorner( ccl_corner(n),
                        nb->corner( cl_corner(opp_neighbor(n)))  );
		else {
		  diffpt=2;
		  if (has_Pvertex()) {  //formerly if (cor2), made no sense
			vbox = corner(ccl_corner(n));
			ebox = nb->corner( cl_corner(opp_neighbor(n)));
		  }
		  else {
                        ebox = corner(ccl_corner(n));
                        vbox = nb->corner( cl_corner(opp_neighbor(n)));
                  }
		}

		//do AFTER sharing corners
		if (diffpt==2) 
		  share_edge_crosses( corner(cl_corner(n)),
			ebox, vbox, diffpt, nb ); 
		else if (diffpt==1) 
		  share_edge_crosses( ebox, corner(ccl_corner(n)),
			vbox, diffpt, nb ); 
		else  
		  share_edge_crosses(corner(cl_corner(n)), 
		      corner(ccl_corner(n)), 0, 0, nb); 
	      }
	      else /*simpler case, no Pvertex*/ {
		  changecorner( cl_corner(n), 
			nb->corner( ccl_corner(opp_neighbor(n)))  );
		  changecorner( ccl_corner(n),
                        nb->corner( cl_corner(opp_neighbor(n)))  );
		  share_edge_crosses(corner(cl_corner(n)), 
		      corner(ccl_corner(n)), 0,0, nb); 
	      }
	    } //if adj
	  } // if same size
	} //for all dups of original= for nb
    } //for all n
    //if no neighbor in direction n, let the bigger box in that direction
    // allocate for this at a later call of this function
}


void triquad::set_sides(int level, ostream & f)
//INPUT: This has all the neighbor pointers, dropped or not,
// and duplicates just have null pointers 
//OUTPUT: This and duplicates have only connected component neighbors,
// and sides and corners correctly point to the same snap_points
{

    if (level > nlevels) nlevels = level;
    for (triquad * dp = dup; dp!=0; dp = dp->dup ) 
	dp->set_sides_loc(this,f);
    this->set_sides_loc(this,f);

    for (corner_direction c = 0; c < 4; c++)
	if (is_split()) {
	    child(c)->set_sides(level+1,f);
	    child(c)->father_corner = c;
	} 
	/*EPP? else while (corner(c)->pushed()) corner(c)->pop(); */
}


// make initial list of all quads to be merged
//
// we order this largest to smallest
// therefore when we process a small quad we need not add
// its parent to the queue, because it will already by there.

void triquad::unmark_all(int level)
{
    static triquad ** lev_list;
    if (level == 0) {
	lev_list = new triquad *[nlevels+1];
	for (int i = 0; i <= nlevels; i++) lev_list[i] = 0;
    }

    if (draw_split())
	for (corner_direction c = 0; c < 4; c++)
	    child(c)->unmark_all(level+1);

    enqueue(lev_list[level]);

    if (level == 0) {
	for (int i = 0; i <= nlevels; i++)
	    while (lev_list[i] != 0)
		lev_list[i]->dequeue(lev_list[i])->enqueue(do_list);
	delete lev_list;
    }
}


// test how good it is to merge two subquad triangles across a side

double triquad::merged_aspect(neighbor_direction n)
{
    if (!draw_split()) return maxaspect;
    return aspect(*center, *corner(cl_corner(n)), *corner(ccl_corner(n)));
}

// test how good it is to cut across diagonal containing corner c

double triquad::diag_aspect(corner_direction c)
{
    double a1 = aspect(*(corner(c)), *(corner(opp_corner(c))),
		       *(corner(cl_corner(cl_neighbor(c)))));
    double a2 = aspect(*(corner(c)), *(corner(opp_corner(c))),
		       *(corner(ccl_corner(ccl_neighbor(c)))));
    return (a1 > a2 ? a1 : a2);
}


// test which of two diagonals to draw with

corner_direction triquad::good_diag()
{
    return ((diag_aspect(northwest) > diag_aspect(northeast)) ?
	    northeast : northwest);
}


// test cut into three triangles with sides[n] and opposite corners

double triquad::side_aspect(neighbor_direction n)
{
    if (sides[n] == 0) return maxaspect; // no side means bad aspect

    point * c1 = corner(cl_corner(opp_neighbor(n)));
    point * c2 = corner(ccl_corner(opp_neighbor(n)));

    double retval = aspect(*c1, *c2, *sides[n]);

    double a1 = aspect(*c1, *corner(ccl_corner(n)), *sides[n]);
    if (retval < a1) retval = a1;

    double a2 = aspect(*c2, *corner(cl_corner(n)), *sides[n]);
    if (retval < a2) retval = a2;

    return retval;
}


// test cut into four triangles with sides on either side of c

double triquad::corner_aspect(corner_direction c)
{
    // inner triangle
    double a1 = aspect(*corner(opp_corner(c)),
		       *sides[cl_neighbor(c)],
		       *sides[ccl_neighbor(c)]);

    // corner triangle unless it would be drawn anyway
    corner_direction d;
    if (!is_split() || (d = child(c)->good_diag()) == c || d == opp_corner(c))
    {
	double a2 = aspect(*corner(c),
			   *sides[cl_neighbor(c)],
			   *sides[ccl_neighbor(c)]);

	if (a1 < a2) a1 = a2;
    }

    // two side triangles
    double a3 = aspect(*corner(opp_corner(c)),
		       *sides[cl_neighbor(c)],
		       *corner(cl_corner(cl_neighbor(c))));
    if (a1 < a3) a1 = a3;

    double a4 = aspect(*corner(opp_corner(c)),
		       *sides[ccl_neighbor(c)],
		       *corner(ccl_corner(ccl_neighbor(c))));
    if (a1 < a4) a1 = a4;
    return a1;
}


// check if any side of a quad is split
// the quad itself may not be split in this case
//
// this should never change things out from under the caller

int triquad::some_side_split()
{
    if (draw_split()) return 1;
    for (neighbor_direction n = 0; n < 4; n++)
	if (sides[n] != 0) return 1;

    return 0;
}

// check if ok to merge a square with its neighbor
// c1 is the squares position in its father
// c2 is the corner that would go away
//
// caller is also responsible for checking either
// some_side_split() or child_sides_removable().
//
// this should never change things out from under the caller

int triquad::can_merge(corner_direction c1, corner_direction c2)
{
    if (merged(cl_neighbor(c1)) || merged(ccl_neighbor(c1)))
	return 1;		// already merged, must have been ok

    return (aspect(*corner(c1), *corner(opp_corner(c1)),
		   *corner(opp_corner(c2))) <= good_aspect);
}


// test if children will accept being merged
// if they in turn have split sides, the only acceptable possibility is
// that the sides are on edges which would be removed

int triquad::children_mergable(neighbor_direction n)
{
    if (!draw_split()) return 1;

    triquad * clc = child(cl_corner(n));
    triquad * cclc = child(ccl_corner(n));

    return (child(cl_corner(n))->child_sides_removable(ccl_corner(n)) &&
	    child(ccl_corner(n))->child_sides_removable(cl_corner(n)));

}


// test if removal of a side would leave acceptable triangles
//
// this should never change things out from under the caller

int triquad::merge_ok(neighbor_direction n)
{
    if (sides[n] == 0) return 0; // already merged, dont get confused
    if (!children_mergable(n)) return 0;

    // maybe we could remove our center if we got rid of this point
    int nsides = 0;
    neighbor_direction other_side;
    for (neighbor_direction nn = 0; nn < 4; nn++)
	if (sides[nn] != 0) {
	    nsides++;
	    if (nn != n) other_side = nn;
	}

    if ((nsides == 1 && diag_aspect(good_diag()) <= good_aspect) ||
	(nsides == 2 && side_aspect(other_side) <= good_aspect))
    {
	if (!draw_split()) return 1; // ctr already gone, we like it
	if (!center->snapped()) return 1; // ctr can safely go away
    }
    if (!draw_split()) return (nsides > 2); // fewer than 2 means bad aspect

    if (!child(cl_corner(n))->can_merge(cl_corner(n), ccl_corner(n))) return 0;
    if (!child(ccl_corner(n))->can_merge(ccl_corner(n), cl_corner(n)))
	return 0;

    return (merged_aspect(n) <= good_aspect);
}




// try neighbors over again after we flush a side

void triquad::unmark_neighbors()
{
    neighbor_direction n;
    triquad * tq;

    // remove_side also removes smaller childrens sides,
    // possibly eventually propagating changes past the parents neighbors.
    // therefore we make sure that parent and neighbors are on do_list.
    //
    // for some reason it works better if we only do this the
    // second time around...

    if (phase > 0 && father() != 0) {
	for (n = 0; n < 4; n++) {
	    tq = father()->neighbor(n);
	    if (tq != 0) tq->enqueue(do_list);
	}
	father()->enqueue(do_list);
    }

    for (n = 0; n < 4; n++) {
	tq = neighbor(n);
	if (tq != 0) tq->enqueue(do_list);
    }
    enqueue(do_list);
}


// try to remove shared side in child of quad that wants to merge sides
// argument is corner near the two acceptable sides

int triquad::child_sides_removable(corner_direction c)
{
    // if we are drawn split, we must be able to unsplit.
    // all children must be unsplit themselves, and the center must not
    // be stuck.  all children except c will be tested by the requirement
    // that sides opposite c be unsplit.  therefore we need only test c.
    if (draw_split()) {
	if (child(c)->some_side_split()) return 0;
	if (center->snapped()) return 0;
    }

    // make sure only acceptable sides are there, and none are stuck
    for (neighbor_direction n = 0; n < 4; n++)
	if (n == cl_neighbor(c) || n == ccl_neighbor(c)) {
	    if (sides[n] != 0 && sides[n]->snapped()) return 0;
	} else if (sides[n] != 0) return 0;

    return 1;
}


// check if a side would be removable if we could fix our own quad

int triquad::side_removable(neighbor_direction n)
{
    if (merged(n)) return 1;
    if (sides[n] == 0) return 1;
    if (sides[n]->snapped()) return 0;
    if (!children_mergable(n)) return 0;

    triquad * nb = neighbor(n);
    if (nb != 0 && !nb->merge_ok(opp_neighbor(n))) return 0;
    return 1;
}


// flush a useless side

void triquad::remove_side(neighbor_direction n)
{
    if (sides[n] == 0) return;
    unmark_neighbors();

    sides[n] = 0;
    triquad * nb = neighbor(n);
    if (nb != 0) nb->remove_side(opp_neighbor(n));

    // remove removable child sides
    // do this last so do_list ends up in right order

    if (draw_split()) for (neighbor_direction nn = 0; nn < 4; nn++) {
	child(cl_corner(n))->remove_side(nn);
	child(ccl_corner(n))->remove_side(nn);
    }
}



// remove inessential sides (and center if possible)

void triquad::merge()
{
    if (state == tq_gone) return;

    corner_direction c;
    int nbad = 0;		// how many sides are truly unremovable
    int nsides = 0;		// how many sides are left at all
    neighbor_direction bad_side; // if one, which one

    // remove inessential sides

    neighbor_direction n;
    for ( n = 0; n < 4; n++) {
	if (sides[n] == 0) continue;
	nsides++;
	if (!side_removable(n)) {
	    nbad++;
	    bad_side = n;
	    continue;
	}
	if (!merge_ok(n)) continue;

	remove_side(n);
	return;
    }

    // maybe we can move an interior point to a corner
    // try corners in order of their level

    if (father() != 0) {
	c = father_corner;
	if (move_corner(c)) return;
	/* SAM type cast to correct type */
	if (move_corner((corner_direction)cl_neighbor(cl_corner(c)))) return;
	if (move_corner((corner_direction)ccl_neighbor(ccl_corner(c)))) return;
	if (move_corner(opp_corner(c))) return;
    }

    // move stuck center to side

    if (draw_split() && center->snapped()) {
	// center wants to stay
	// maybe we can move it to the side

	if (phase == 0) return; // dangerous optimization
	if (nbad > 1) return;
	if (nbad == 0) {
	    if (nsides == 0) return;
	    for (n = 0; n < 4; n++) {
		move_center(n);
		if (!draw_split()) break;
	    }
	} else move_center(bad_side);
	return;
    }

    // maybe we can remove the center point

    if (nbad == nsides && !draw_split()) return; // unable to do any more

    // make sure removing sides preserves aspect ratios
    switch (nbad) {
     case 0:
	if (diag_aspect(good_diag()) > good_aspect) {
	    for (n = 0; n < 4 && nbad == 0; n++)
		if (sides[n] != 0 && side_aspect(n) <= good_aspect) {
		    nbad++;		// found a side we can keep
		    bad_side = n;	// to make aspect ratio ok
		}
	    if (nbad == 0) return;	// no way to stop quad being too warped
	    if (nbad == nsides && !draw_split()) return;
	}
	break;

     case 1:
	if (side_aspect(bad_side) <= good_aspect) break;
	if (phase == 0) return;	// very dangerous optimization
	if (!draw_split()) return; // already no center, nothing to do

	// maybe we can make another side bad
	if (sides[cl_neighbor(cl_corner(bad_side))] != 0 &&
	    corner_aspect(cl_corner(bad_side)) <= good_aspect)
	{
	    nbad = 2;
	    bad_side = cl_neighbor(cl_corner(bad_side));
	} else if (sides[ccl_neighbor(ccl_corner(bad_side))] != 0 &&
		   corner_aspect(ccl_corner(bad_side)) <= good_aspect)
	    nbad = 2;
	else return;
	break;

     case 2:
	if (!side_removable(cl_neighbor(cl_corner(bad_side))))
	    bad_side = cl_neighbor(cl_corner(bad_side));
	else if (side_removable(ccl_neighbor(ccl_corner(bad_side))))
	    return;
	if (corner_aspect(ccl_corner(bad_side)) > good_aspect) return;
	if (draw_split()) {
	    triquad * tq = child(ccl_corner(bad_side));
	    if (tq->draw_split() && tq->center->snapped())
		return;		// center is stuck
	    for (n = 0; n < 4; n++) if (!tq->side_removable(n)) return;
	    for (n = 0; n < 4; n++) tq->remove_side(n);
	}
	break;

     default:
	return;
    }

    // remove all non-bad sides
    for (n = 0; n < 4; n++)
	if (sides[n] != 0 && (nbad == 0 || n != bad_side) &&
	    (nbad != 2 || n != ccl_neighbor(ccl_corner(bad_side))))
	    remove_side(n);

    make_unsplit();
    unmark_neighbors();
}


// move stuck center point to unstuck side

void triquad::move_center(neighbor_direction bad_side)
{
    neighbor_direction n;

    if (sides[bad_side] == 0 || !draw_split() || sides[bad_side]->snapped())
	return;
    if (child(cl_corner(bad_side))->some_side_split()) return;
    if (child(ccl_corner(bad_side))->some_side_split()) return;

    triquad * nb = neighbor(bad_side);

    sides[bad_side]->push(*center);
    if (side_aspect(bad_side) > good_aspect) goto bad_ctr_move;

    triquad * clc;
    triquad * cclc;

    if (nb != 0) {
	if (nb->draw_split()) {

	    clc = nb->child(cl_corner(opp_neighbor(bad_side)));
	    if (clc->some_side_split()) goto bad_ctr_move;
	    double ar;
	    if (nb->sides[ccl_neighbor(ccl_corner(bad_side))] == 0)
		ar = aspect(*nb->child(northwest)->corner(southeast),
			    *sides[bad_side],
			    *corner(ccl_corner(bad_side)));
	    else ar = clc->diag_aspect(clc->good_diag());
	    if (ar > good_aspect) goto bad_ctr_move;

	    cclc = nb->child(ccl_corner(opp_neighbor(bad_side)));
	    if (cclc->some_side_split()) goto bad_ctr_move;
	    if (nb->sides[cl_neighbor(cl_corner(bad_side))] == 0)
		ar = aspect(*nb->center, *sides[bad_side],
			    *corner(cl_corner(bad_side)));
	    else ar = cclc->diag_aspect(cclc->good_diag());
	    if (ar > good_aspect) goto bad_ctr_move;

	} else {

	    int nsides = 0;
	    for (n = 0; n < 4; n++) if (nb->sides[n] != 0) nsides++;
	    if (nsides > 1) goto bad_ctr_move;
	    if (nb->side_aspect(opp_neighbor(bad_side)) > good_aspect)
		goto bad_ctr_move;

	}
	nb->unmark_neighbors();
    }
    make_unsplit();
    for (n = 0; n < 4; n++) if (n != bad_side) remove_side(n);
    unmark_neighbors();

    return;

 bad_ctr_move:
    sides[bad_side]->pop();
    return;
}


// find the unique snapped point in a quad
//
// stuck should initially be set empty
// if we do not find anything, we return 0.
// if we find one snapped point, we set stuck to it and return 0.
// if we find several snapped points, we return 1.

static snap_point * stuck;

static int test_stuck_point(snap_point * avoid, snap_point * q)
{
    if (q == 0 || q == avoid || q == stuck || !q->snapped()) return 0;
    if (stuck != 0) return 1;
    stuck = q;
    return 0;
}

int triquad::find_stuck_point(snap_point * avoid)
{
    corner_direction c;
    neighbor_direction n;

    if (!draw_split()) {
	for (c = 0; c < 4; c++)
	    if (test_stuck_point(avoid,corner(c))) return 1;
	for (n = 0; n < 4; n++)
	    if (test_stuck_point(avoid,sides[n])) return 1;
    } else for (c = 0; c < 4; c++)
	if (child(c)->find_stuck_point(avoid)) return 1;
    return 0;
}


// test if a quad would be bad with moved corner and no sides

int triquad::bad_quad(int cl_merge, int ccl_merge)
{
    corner_direction c = father_corner;
    if (father()->sides[cl_neighbor(c)] == 0) cl_merge = 1;
    if (father()->sides[ccl_neighbor(c)] == 0) ccl_merge = 1;

    if (cl_merge == 0 && ccl_merge == 0) {
	// no merger made yet, must be good or must be able to merge
	if (diag_aspect(good_diag()) <= good_aspect) return 0;
	if (father()->side_removable(cl_neighbor(c)) &&
	    father()->merge_ok(cl_neighbor(c))) cl_merge = 1;
	if (father()->side_removable(ccl_neighbor(c)) &&
	    father()->merge_ok(ccl_neighbor(c))) ccl_merge = 1;
    }

    // one or both possible sides merged
    // test aspects assuming ctr-to-corner diagonal

    // first we check if father center point can be removed

    int nsides = 0;
    if (corner(opp_corner(c))->snapped() ||
	father()->diag_aspect(father()->good_diag()) > good_aspect)
	nsides = 4;
    else {
	if (!cl_merge) nsides++;
	if (!ccl_merge) nsides++;
	if (father()->sides[cl_neighbor(opp_corner(c))] != 0) nsides++;
	if (father()->sides[ccl_neighbor(opp_corner(c))] != 0) nsides++;
    }

    if (cl_merge) {
	if (father()->merged_aspect(cl_neighbor(c)) > good_aspect)
	    return (nsides > 0);
    } else if (aspect(*corner(ccl_corner(cl_neighbor(c))),
		      *corner(c), *corner(opp_corner(c))) > good_aspect)
    {
	if (!father()->side_removable(cl_neighbor(c)) ||
	    !father()->merge_ok(cl_neighbor(c))) return 1; 

	nsides--;
    }

    if (ccl_merge) {
	if (father()->merged_aspect(ccl_neighbor(c)) > good_aspect)
	    return (nsides > 0);
    } else if (aspect(*corner(ccl_corner(ccl_neighbor(c))),
		      *corner(c), *corner(opp_corner(c))) > good_aspect)
    {
	if (!father()->side_removable(ccl_neighbor(c)) ||
	    !father()->merge_ok(ccl_neighbor(c))) return 1;
    }

    return 0;
}



// move a stuck point to a corner where it can make bigger triangles
//
// second argument allows us to keep some sides that were not originally
// marked as bad, in order to get a move that would otherwise be bad.
// for some reason it is not good to always do this.

int triquad::move_corner(corner_direction cdir)
{
    if (corner(cdir)->snapped()) return 0; // already stuck, cant move
    if (father() == 0) return 0;	   // top level, no neighbors
    if (father()->child(cl_corner(cl_neighbor(cdir))) == this &&
	father()->sides[cl_neighbor(cdir)] == 0) return 0; // no ctr to snap to
    if (father()->child(ccl_corner(ccl_neighbor(cdir))) == this &&
	father()->sides[ccl_neighbor(cdir)] == 0) return 0;

    // find the four quads around the corner and which way to go from them
    triquad * q[4];
    corner_direction c[4];
    int is_bad[4];
    neighbor_direction bad_side[4];
    int keep_ctr[4];
    q[0] = this;
    c[0] = cdir;
    int i;
    for (i = 1; i < 4; i++) {
	q[i] = q[i-1]->neighbor(cl_neighbor(c[i-1]));
	if (q[i] == 0) return 0;
	c[i] = ccl_corner(ccl_neighbor(c[i-1]));

	// make sure parent still wants to draw this quad
	// if it is gone, must be in corner of two sided father
	if (q[i]->state == tq_gone &&
	    (q[i]->father_corner != c[i] ||
	     q[i]->father()->sides[cl_neighbor(c[i])] == 0 ||
	     q[i]->father()->sides[ccl_neighbor(c[i])] == 0))
	    return 0;
    }

    // make sure the outer sides are removable
    // and all interior points are in the inner quads
    for (i = 0; i < 4; i++) {
	keep_ctr[i] = 0;
	is_bad[i] = 0;
	if (!q[i]->side_removable(cl_neighbor(opp_corner(c[i])))) {
	    if (q[i]->draw_split() &&
		/* SAM type cast corner_direction needed */
	        q[i]->child( (corner_direction)
                        ccl_neighbor(ccl_corner(c[i])) )->
			sides[cl_neighbor(opp_corner(c[i]))] != 0)
		return 0;
	    is_bad[i] = 1;
	    bad_side[i] = cl_neighbor(opp_corner(c[i]));
	}
	if (!q[i]->side_removable(ccl_neighbor(opp_corner(c[i])))) {
	    if (is_bad[i]) return 0;
	    if (q[i]->draw_split() &&
		/* SAM type cast corner_direction needed */
		q[i]->child((corner_direction)cl_neighbor(cl_corner(c[i])))->
			sides[ccl_neighbor(opp_corner(c[i]))] != 0)
		return 0;
	    is_bad[i] = 1;
	    bad_side[i] = ccl_neighbor(opp_corner(c[i]));
	}
	if (q[i]->draw_split()) {
	    if (q[i]->child(opp_corner(c[i]))->some_side_split()) return 0;
	    if (q[i]->child(cl_corner(cl_neighbor(c[i])))->
		sides[cl_neighbor(c[i])] != 0) return 0;
	}
    }

    // find the stuck point
    stuck = 0;
    snap_point * centers[4];
    for (i = 0; i < 4; i++) {
	centers[i] = 0;
	if (q[i]->state == tq_gone) continue;
	if (test_stuck_point(0, q[i]->sides[cl_neighbor(c[i])])) return 0;
	if (test_stuck_point(0, q[i]->sides[ccl_neighbor(c[i])])) return 0;
	if (q[i]->draw_split())  {
	    centers[i] = q[i]->center;
	    if (q[i]->child(c[i])->find_stuck_point(centers[i])) return 0;
	}
    }

    // test which centers are also stuck
    for (i = 0; i < 4; i++) if (centers[i] != 0 && centers[i]->snapped()) {
	if (stuck == 0) {
	    stuck = centers[i];
	    centers[i] = 0;
	} else keep_ctr[i] = 1;
    }

    triquad * stuck_parent = 0;
    if (stuck == 0) {

	// unable to find a stuck point
	// maybe we can take one of the corners and make it look like a merge

	if (father()->child(cdir) != this) return 0; // must be good corner
	for (i = 0; i < 4; i++) {
	    if (is_bad[i]) continue;
	    if (q[i]->state == tq_gone) continue;
	    stuck_parent = q[i]->father();
	    stuck = stuck_parent->sides[cl_neighbor(c[i])];
	    if (stuck == 0 || !stuck->snapped()) continue;
	    triquad * nb = q[i]->neighbor(ccl_neighbor(opp_corner(c[i])));
	    if (nb->some_side_split()) continue;
	    if (!nb->can_merge(cl_corner(cl_neighbor(c[i])),c[i])) continue;
	    int j = (i + 1) & 03;
	    if (is_bad[j]) continue;
	    nb = q[j]->neighbor(cl_neighbor(opp_corner(c[j])));
	    if (nb->some_side_split()) continue;
	    if (!nb->can_merge(ccl_corner(ccl_neighbor(c[j])),c[j])) continue;
	    break;
	}
	if (i == 4) return 0;
    }

    // move it and temporarily remove centers from points
    corner(cdir)->push(*stuck);

    // test that all quads are still ok
    neighbor_direction n;
    for (i = 0; i < 4; i++) {
	if (q[i]->state == tq_gone) {
	    if (aspect(*q[i]->corner(cl_corner(cl_neighbor(c[i]))),
		       *q[i]->corner(ccl_corner(ccl_neighbor(c[i]))),
		       *stuck) > good_aspect)
		goto bad_move;
	    continue;
	}

	if (is_bad[i] && !keep_ctr[i]) {

	    // unremovable side, side_aspect must be ok
	    // or maybe we can leave center in

	    if (q[i]->side_aspect(bad_side[i]) <= good_aspect) continue;
	    if (centers[i] == 0) goto bad_move;
	    keep_ctr[i] = 1;
	}

	if (stuck_parent != 0 &&
	    stuck == q[i]->father()->sides[cl_neighbor(c[i])])
	{
	    // want to make it look like a merge
	    // tell bad_quad it will be merged
	    if (q[i]->bad_quad(1,0)) goto bad_move;
	    continue;
	}

	if (stuck_parent != 0 &&
	    stuck == q[i]->father()->sides[ccl_neighbor(c[i])])
	{
	    // mirror image of previous case
	    if (q[i]->bad_quad(0,1)) goto bad_move;
	    continue;
	}

	if (!keep_ctr[i]) {
	    if (!q[i]->bad_quad(0,0)) continue;

	    // maybe we can leave one of the sides and get ok side_aspect

	    if (phase == 0) goto bad_move;
	    if (q[i]->merged(cl_neighbor(c[i])) ||
		q[i]->merged(ccl_neighbor(c[i]))) goto bad_move;

	    if (q[i]->side_aspect(cl_neighbor(opp_corner(c[i])))
		<= good_aspect)
	    {
		is_bad[i] = 1;
		bad_side[i] = cl_neighbor(opp_corner(c[i]));
		continue;
	    }

	    if (q[i]->side_aspect(ccl_neighbor(opp_corner(c[i])))
		       <= good_aspect)
	    {
		is_bad[i] = 1;
		bad_side[i] = ccl_neighbor(opp_corner(c[i]));
		continue;
	    }
	    goto bad_move;
	}

	// here with keep_ctr[i] != 0
	// make sure center aspect is ok

	for (n = 0; n < 4; n++)
	    if (!is_bad[i] || n != bad_side[i])
		if (q[i]->merged_aspect(n) > good_aspect)
		    goto bad_move;

	if (is_bad[i]) {
	    if (aspect(*centers[i], *q[i]->sides[bad_side[i]],
		       *q[i]->corner(cl_corner(bad_side[i]))) > good_aspect)
		goto bad_move;

	    if (aspect(*centers[i], *q[i]->sides[bad_side[i]],
		       *q[i]->corner(ccl_corner(bad_side[i]))) > good_aspect)
		goto bad_move;
	}
    }

    // remove all the stuff in the middles of the quads
    for (i = 0; i < 4; i++) {
	for (n = 0; n < 4; n++)
	    if (!is_bad[i] || n != bad_side[i])
		q[i]->remove_side(n);
	if (!keep_ctr[i]) q[i]->make_unsplit();
    }
    for (i = 0; i < 4; i++)
	if (stuck_parent == q[i]->father())
	    stuck_parent->remove_side(cl_neighbor(c[i]));

    // now that we are in a consistent state, recheck neighbors
    for (i = 0; i < 4; i++) q[i]->unmark_neighbors();
    return 1;

 bad_move:
    corner(cdir)->pop();
    return 0;
}


// test if a quad should draw one of its sides

int triquad::merged(neighbor_direction side)
{
#ifdef DOHEURISTIC
    triquad * parent = father();
    if (parent == 0) return 0;
    corner_direction c = father_corner;
    if (side == cl_neighbor(c) || side == ccl_neighbor(c))
	return (parent->sides[side] == 0); // outside
    if (!parent->draw_split()) return 1;   // inside but no inside exists
    if (side == cl_neighbor(opp_corner(c)))
	return (parent->sides[ccl_neighbor(c)] == 0);
    return (parent->sides[cl_neighbor(c)] == 0);
#else
    side = side;
    return 0;
#endif
}

int triquad::leaf_box_point_vis( snap_point * p )
//this is a leaf box, p is a corner or side of the box
//true is leaf can see p
{
    return ( leaf_box_geo_point_vis( lf_apex(), p) );
}

int triquad::leaf_box_geo_point_vis( geo* looker, snap_point * p )
//use passed geo instead of leaf
{
    if (looker == 0) return 1;
    geo gp ( p );
    //block doesn't matter
    if (p->who) {
    	if (looker->superfaces) { // vertex looking
	    return 
	      ( looker->is_sub(p->who) || 
		p->who->is_sub( looker->superfaces->first() ) ||
		p->who->is_sub( looker->superfaces->rest()->first() )  );
	}
	else { // edge looking, may be snapped to a visible edge in exteded box -
		// i.e. lf_apex doesn't always return the vertex if one of the edges is
		// in the extended box, and the vertex is not in the box
	    return ( p->who->is_sub( looker ) ||
          	conevisible_noblock_q( looker, &gp, this, 0 )   );
	}
    }
    else {
        return (  conevisible_noblock_q( looker, &gp, this, 0 )  );
    }
}

void triquad::draw_side( snap_point * p1, snap_point * p2, segdrawer* s )
//in calls to conevisible and edge_see,
//target geo is always a point.
//needs to be generalized for 3d
{
    crosspt * c1; crosspt * c2;

    //pass as var parameters, virtual ptquad.c
    get_all_crosses( &c1, &c2, p1, p2 );
    if (c1 == 0)  //no crossing
    { 
	snap_point snap_mid ( midpoint( *p1, *p2) );
	if (leaf_box_point_vis( p1 ) && leaf_box_point_vis( p2 )
	&& leaf_box_point_vis( &snap_mid )  ) {
	    (*s)(p1,p2);
	}
    }
    else if (c2 == 0) { //one crossing
	if ( leaf_box_geo_point_vis( c1->crosse, p1 ) )
	    (*s)( c1->me, p1 );
	if ( leaf_box_geo_point_vis( c1->crosse, p2 ) )
	    (*s)( c1->me, p2 );
    }
    else //two crossings
    {
	if (p1->who->is_sub( p2->who ) || p2->who->is_sub( p1->who ))
	    (*s)( p1, p2 );
	//gaurentee c1 to be closer to p1 than c2 is to p2
	//or the same point!!
	if (left(c2->me,c1->me,p1,p2)) {
	    crosspt * temp=c1; c1=c2; c2=temp; }
	//?draw p1 to c1?
	if (c1->me == c2->me)
	//c1,c2 warped to common lf_apex
	{
	   if ( leaf_box_point_vis(p1) && leaf_box_point_vis(p2) )
		(*s) (p2, p1);
	}
	else  //roundoff error can mess up the below??
	{
    	  geo g1( p1 ), g2( p2 );
	  if ( !p1->who->is_sub( c1->crosse ) )
	    if (conevisible_noblock_q( c1->crosse, &g1, this, 0 ))
		(*s)( p1, c1->me);
	  //?draw p2 to c2?
	  if ( !p2->who->is_sub( c2->crosse ) )
	    if (conevisible_noblock_q( c2->crosse, &g2, this, 0 ))
		(*s)( p2, c2->me);
	  //?draw c1 to c2?
	  // or could check c1->crosse see c2->crosse
	  if ( leaf_box_geo_point_vis( c1->crosse, c2->me) )
	    (*s)( c1->me, c2->me);
	}
    }
}


// GO AHEAD AND DRAW MORE THAN ONCE!
// let () segdraw operator handle degenerate edges
void triquad::do_draw(segdrawer * s)
{ 
  for (triquad * dp=this; dp!=0; dp=dp->dup)
    if (dp->drawit()) 
	dp->draw_box(s); 

  if (is_split()) for (corner_direction c = 0; c < 4; c++)
	(child(c))->do_draw(s);
}

void triquad::draw_box(segdrawer * s)
{
// Box is only drawn once, but edges may be drawn many times
// segdraw operator () detects loop edges and doesn't draw them
    //int deb = ( smallcorner()->x < 430 && smallcorner()->x > 410 &&
	//smallcorner()->y < 380 && smallcorner()->y > 360 );    

    if (no_volume()) return;

    // draw crosses, ie the parts of P passing through the box
    draw_crosses( s );

    // draw each side
    for (neighbor_direction n = 0; n < 4; n++) {       
	if (sides[n] == 0)
	  // draw one side, considering crosses as well
	  draw_side( corner( ccl_corner(n)), corner(cl_corner(n)), s );

	//draw the two split sides
	else { 
	    draw_side( corner(cl_corner(n)), sides[n], s );
	    draw_side( sides[n], corner(ccl_corner(n)), s );
	}
    }
    
    // draw diagonals, from centroid to box sides
    draw_diags( s );
    //if (deb) testme();
}

//EPP work
//9 ****************************** just draw sides for now
/* HOW TO TRIANGULATE

    // parent only wanted us to draw sides
    //if (state == tq_gone) return;

    // draw diagonals
    int num_sides = 0;
    for (n = 0; n < 4; n++) if (sides[n] != 0) num_sides++;

    out_point center;
    if (is_split()) center = *child(northwest)->corner(southeast);
    else center = midpoint(*corner(northwest),*corner(southeast));

    corner_direction c;

    if (!draw_split()) switch(num_sides) {
     case 0:			// no sides, pick better main diagonal
				// unless merged, in which case no choice
	if (father() != 0) {
	    c = father_corner;
	    if ((father())->sides[cl_neighbor(c)] != 0 &&
		(father())->sides[ccl_neighbor(c)] != 0)
		c = good_diag();
	} else c = good_diag();
	(*s)(corner(c), corner(opp_corner(c)));
	return;

     case 1:
	for (n = 0; sides[n] == 0; n++) ;
	if (side_aspect(n) <= good_aspect) {
	    (*s)(corner(cl_corner(opp_neighbor(n))), sides[n]);
	    (*s)(sides[n], corner(ccl_corner(opp_neighbor(n))));
	    break;
	} else { // skip to case 3
     case 2:
	// maybe draw triangle connecting 2 sides to opposite corner
	for (c = 0; c < 4 && (sides[cl_neighbor(c)] == 0 ||
			      sides[ccl_neighbor(c)] == 0); c++) ;
	if (c < 4 && corner_aspect(c) <= good_aspect) {
	    (*s)(corner(opp_corner(c)),sides[cl_neighbor(c)]);
	    (*s)(sides[cl_neighbor(c)],sides[ccl_neighbor(c)]);
	    (*s)(sides[ccl_neighbor(c)],corner(opp_corner(c)));
	    break;
	}
	} // end else in case 1
     case 3:
	for (c = 0; c < 4; c++) (*s)(corner(c),&center);
	for (n = 0; n < 4; n++) if (sides[n] != 0) (*s)(sides[n],&center);
	break;

     case 4:			// all four sides, two big triangles in middle
	for (n = 0; n < 4; n++)
	    (*s)(sides[n], sides[cl_corner(cl_neighbor(n))]);
	(*s)(sides[east], sides[west]);
	break;
    }
end EPP *******/    

//a local way to decide if to draw a particular box
void triquad::decide_draw_this() 
{
   if (!is_split() && (non_empty() || !somedrop()) )
	set_draw();
}

void triquad::decide_draw_dups()
{
    //draw duplicates, can every box be handled this way!
    for ( triquad * dp = this; dp!=0; dp=dp->dup ) //dup, not this
	dp->decide_draw_this();

    if (is_split()) 
        for (corner_direction c=0; c<4; c++) 
            child(c)->decide_draw_dups();
}

//find a leaf that actually has part of bdyP in it
triquad * triquad::find_full_leaf() 
{
    if (!is_split())
        return (non_empty()) ? this : 0; //0 means keep searching
    for ( corner_direction c=0; c<4; c++ ) {
	triquad * ret = child(c)->find_full_leaf();
	if (ret != 0) return ret;
    }
    return 0;
}

//for decide_draw_neighbors
void triquad::decide_draw_neighbor_child( neighbor_direction n )
{
		if ( ! is_split() && 
		!isdrop_neighbor(opp_neighbor(n)) &&
		( non_empty() || somedrop() ) )
			decide_draw_neighbors();
}

//bounce around at the leaf level, visiting all boxes in the interior of
// P,  we assume P is connected
void triquad::decide_draw_neighbors()
{ 
    if ( this == 0 ) return;
    if (drawit()) return; //avoid infinite recursion
    set_draw();

//9 testup();

    for (neighbor_direction n=0; n<4; n++) {
	if (! isdrop_neighbor(n) ){
	    // visit neighbors, but may have to change levels
	    // go up one level
	    if (neighbor(n) == 0 ) { 
		//father->neigh could be outside bounding box
		// or dropped, so check if non-zero
		if (  !is_top() && father()->neighbor(n) != 0 &&
		!father()->isdrop_neighbor(n)  &&
	        !father()->neighbor(n)->isdrop_neighbor(opp_neighbor(n))&&
	        !father()->neighbor(n)->is_split()  ) 
		    father()->neighbor(n)->decide_draw_neighbors();
	    }
	    //stay same level
	    else if ( !neighbor(n)->is_split() ) { 
		if (!neighbor(n)->isdrop_neighbor(opp_neighbor(n)) ) 
		    neighbor(n)->decide_draw_neighbors();
	    }
	    //go down one level, be very careful
	    else {
		neighbor(n)->child(cl_corner(opp_neighbor(n)))->
		  decide_draw_neighbor_child( n );

		neighbor(n)->child(ccl_corner(opp_neighbor(n)))->
		  decide_draw_neighbor_child( n );
	    }    
	}
    }
}

void triquad::decide_draw()
{
    decide_draw_dups(); //formerly more complicated
}

void triquad::draw_sub(segdrawer * s)
{
    decide_draw();
    warp();
    do_cross();
    do_draw(s); //includes triangulation
}

void triquad::do_cross() //warp and calculate crossingpoints
{

  for (triquad* dp = this; dp!=0; dp=dp->dup) 
    if (dp->drawit()) {
      for (crosspt * cross = dp->crosses; cross != 0; cross = cross->next) 
	cross->calc_cross();
    }

  if (is_split())
    for (corner_direction c=0; c<4; c++)
	child(c)->do_cross();
}

triquad * triquad::getlast()
{
    return (dup == 0) ? this : dup->getlast();
}

void triquad::add_dup(triquad * dp) 
{
//9 cout << "add_dup ";
    getlast()->dup = (triquad*) dp;
}

void triquad::dupbalance(evenquad * fneven, neighbor_direction d)
{
//9 return;

#define fn ((triquad*) fneven)
    for (triquad * dp=fn; dp!=0; dp=dp->dup)
	//correct balance condition propogation barriers
	if (!dp->is_split()) {
	  int do_split = 0;
	  if ( !dp->is_leaf ) //by BFS, this should never be true
	    { do_split = 1; cout << "hmmmmm "; }  // error
	  else {
	    do_split = balance_adjacent(d, this, dp);
	  }
	  if (do_split) 
	    fn->dup_children( dp );
	}

#undef fn
}

//ALL DUPLICATES->SPLIT() MUST BE CALLED
//BY ORIG->DUP_CHILDREN( DUPLICATE ), NOT DIRECTLY BY SPLIT!!!!
//put children of dp onto duplicate list for children
//this is the orig box of which dp is a duplicate
void triquad::dup_children ( triquad * dp ) 
{

    if (this == dp) { split(); return; }

    //trouble if orig is not split, so switch roles
    if (!is_split()) {
        //9 cout << "swap1 " << "\n";
	swap(dp); //contents are reversed, 
		  //might be trouble with parent pointers
	split();
    }
    else {
      dp->split();
      for (corner_direction c=0; c<4; c++ )  {
        //put children on list
	((triquad *) child(c))->add_dup( dp->child(c) );
	//fix intrachild neighbor pointers, to point to orig children
	// and not each other.  extrachild pointers are already ok.
	//but leave computed drops
	dp->child(c)->sameneighbors( child(c) );



      }
    }

}

void triquad::warp()
{
    //actual warping, virtual function
    if (drawit()) warpbox();  //ptquad

    //recursion
    if (is_split()) 
	for (corner_direction c = 0; c<4; c++ )
	    child(c)->warp();
    for (triquad * dp = dup; dp != 0; dp = dp->dup )
	if (dp->drawit()) dp->warpbox(); 
	//no recursion, as then warp twice

 }

//now, special balance condition,
//if a box has a P-vertex, it may not have a neighbor smaller than it.
//Needed because of how we triangulate a box with a P-vertex.
//Call after other, normal splittings have been done to 
// not upset the "ptquad.c stack"
//but note this may still cause a chain reaction of many other splits
// and upset the previous special balance condition, so we keep
// doing this as long as something is changed
void triquad::do_special_balance_recur() 
{
    if (special_balance_recur()) do_special_balance_recur();
}

int triquad::special_balance_recur()
{
    int retval = 0;
    int split_on_entry = is_split();

    for (triquad* dp = this; dp != 0; dp = dp->dup )
   	if (!dp->is_split() && dp->has_Pvertex()) 
	    retval = retval || dp->special_balance(this);
 
    if (split_on_entry)
	for (corner_direction c=0; c<4; c++) 
	    retval = retval || child(c)->special_balance_recur();
    return retval;
}

//conditionally split this to same size as neighbors
int triquad::special_balance(triquad* orig) {
    for (neighbor_direction d = 0; d<4; d++) 
        if (orig->neighbor(d)) if ( orig->neighbor(d)->is_split() ) {
	    triquad * k;
	    for (k = orig->neighbor(d)->child( cl_corner(opp_neighbor(d)) ); 
	    k!=0; k=k->dup ) 
	        if ( true_adjacent(ccl_corner(d),d , this, k, 1) ) {
		    //calls split, maintaining invarients of quadtree
		    orig->dup_children(this); 
		    return 1;
		}
	    for (k = orig->neighbor(d)->child( ccl_corner(opp_neighbor(d)) ); 
	    k!=0; k=k->dup)
	        if ( true_adjacent( cl_corner(d),d , this, k, 1 ) ) { 
		    //calls split, maintaining invarients of quadtree
		    orig->dup_children(this);
		    return 1;
		}
	}
    return 0;
}

