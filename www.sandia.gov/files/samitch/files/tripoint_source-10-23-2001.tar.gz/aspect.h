// aspect -- compute a measure of the sharpness of a triangle
// Scott Mitchell, Xerox PARC, 1991
// David Eppstein, Xerox PARC, 28 Feb 1990
//
// Larger measures imply sharper triangles.
// The measure currently computed is: hypotenuse/altitude

#ifndef ASPECT_H
#define ASPECT_H

extern double maxaspect;

class point;
extern double aspect(point a, point b, point c);

#endif
