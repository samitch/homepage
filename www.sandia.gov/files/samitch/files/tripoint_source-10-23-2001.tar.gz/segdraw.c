// segdraw.c - support for enumeration/output of line segments
// Scott Mitchell, Xerox Parc, 1991
// David Eppstein, Xerox Parc, 1990

#include "segdraw.h"


void translate_segdrawer::out_label( out_point* a ) {
    if (a->label()==0) {
 	a->label_it();
	/*translate coordinates - but don't store*/
	out_point b; 
	(&b)->dup(a);   /*duplicate point a, data and label*/
	b += trans;
	outputlabel( b );
    }
}

