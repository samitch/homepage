// compass - compass directions for quadtrees etc
// Scott Mitchell, Xerox PARC, 1991
// David Eppstein, Xerox PARC, 27 Feb 1990

#ifndef COMPASS_H
#define COMPASS_H

//enum neighbor_direction {north = 0, east = 1, south = 2, west = 3};
// silly C++ version 2 won't allow neighbor_direction ++
typedef int neighbor_direction;
//	#define north 0
//	#define east  1
//	#define south 2
//	#define west  3
const int north = 0;
const int east  = 1;
const int south = 2;
const int west  = 3;

//neighbor_direction neighbor_direction::operator++(neighbor_direction n)
//{return (neighbor_direction) ((int n) ++);} 

//enum corner_direction {northeast = 0, southeast = 1,
//		       southwest = 2, northwest = 3};
typedef int corner_direction;
const int northeast = 0;
const int southeast = 1;
const int southwest = 2;
const int northwest = 3;
//	#define northeast 0
//	#define southeast 1
//	#define southwest 2
//	#define northwest 3

static inline corner_direction cl_corner(neighbor_direction d) {
    return (corner_direction) d;
}

static inline corner_direction ccl_corner(neighbor_direction d) {
    return (corner_direction) (( ((int) d) - 1) & 03);
}

static inline corner_direction opp_corner(corner_direction d) {
    return (corner_direction) ( ((int) d) ^ 2 );
}

static inline neighbor_direction cl_neighbor(corner_direction d) {
    return (neighbor_direction) (( ((int) d) + 1) & 03);
}

static inline neighbor_direction ccl_neighbor(corner_direction d) {
    return (neighbor_direction) d;
}

static inline neighbor_direction opp_neighbor(neighbor_direction d) {
    return (neighbor_direction) ( ((int) d) ^ 2 );
}

static inline int ccl(int i) {
    return ( (i-1) & 03 );
}

static inline int cl(int i) {
    return ( (i+1) & 03 );
}

#endif
