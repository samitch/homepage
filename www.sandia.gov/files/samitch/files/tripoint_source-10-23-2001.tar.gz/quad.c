// data structure for quadtrees
// Scott Mitchell, Xerox PARC, 1991
// David Eppstein, Xerox PARC, 27 Feb 1990

#include <iostream.h>
#include "quad.h"
#include "snap.h"
#include "point.h"
#include "segdraw.h"

void quadtree::samecorners(quadtree * orig) {
    for (corner_direction c=0; c<4; c++ )
	corners[c] = orig->corner(c);
}

void quadtree::sameneighbors(quadtree * orig) {
    for (neighbor_direction n=0; n<4; n++ )
	neighbors[n] = orig->neighbor(n);	
}

//stuff for class snap
void snap_point::changeallptrs( snap_point ** source )
//this is destination
{
    if (this==0) { *source = 0; return; }
    snap_point * s = *source;
    if (s == 0) { *source = this; addbackptr(source); return; }
    if (s == this) return;
    //something in both
//9
if (s->backptrs == 0) cout <<  "changeallptrs error ";

    while ( s->backptrs != 0 ) {
	addbackptr( s->backptrs->backptr );
	*(s->backptrs->backptr) = this;
	s->deletebackptr();
    }
    delete s;
}

void quadtree::redirect_neighbors( quadtree* condemmed )
{
for (neighbor_direction n = 0; n<4; n++ ) 
  if (condemmed->neighbor(n) != 0) 
    if (condemmed->neighbor(n)->neighbors[opp_neighbor(n)] != this)
    {
	condemmed->neighbor(n)->neighbors[opp_neighbor(n)]=this;
	/*9
	cout << "redirect_neighbors " << n << bigcorner()->x 
	<< "," << bigcorner()->y << " " << smallcorner()->x << "," 
	<< smallcorner()->y << "\n";
	*/
    }
}

// CONSTRUCTOR: build one big bounding quadtree
// coordinate axis:
//
//	0,0  --------> +x
//	 |
//	 |
//	 |
//	 |
//	 V
//	 +y
//
quadtree::quadtree( points * ptlist )
{
    is_leaf = 0;
    parent = 0;
    for (int i = 0; i < 4; i++) { neighbors[i] = 0; children[i] = 0; };
    zerodrops();

    corners[northeast] = new snap_point(ptlist->MAXpt.x,ptlist->minpt.y);
    corners[northwest] = new snap_point(ptlist->minpt.x,ptlist->minpt.y);
    corners[southeast] = new snap_point(ptlist->MAXpt.x,ptlist->MAXpt.y);
    corners[southwest] = new snap_point(ptlist->minpt.x,ptlist->MAXpt.y);
    for (corner_direction c = 0; c<4; c++ )
	corners[c]->addbackptr(&corners[c]);

}

//make sure each corner has nobody else pointing to it
void quadtree::fixcorners() 
{
    for (corner_direction c=0; c<4; c++ ) {
	corners[c] = new snap_point( corner(c)->x, corner(c)->y ); //leave as is
	corners[c]->addbackptr(&corners[c]);
    }
}


quadtree::quadtree()
{
    is_leaf = 0;
    parent = 0;
    for (int i = 0; i < 4; i++) { neighbors[i] = 0; children[i] = 0; };
    zerodrops();
}

// subdivide a square into smaller squares

void set_neighbor(neighbor_direction d, quadtree * qt1, quadtree * qt2)
//note, this doesn't do the right thing if we are splitting a duplicate!
{
	if ( !qt1->isdrop_neighbor(d) && 
	     !qt2->isdrop_neighbor(opp_neighbor(d)) &&
	     adjacent( d, qt1,qt2 )) {
  	  qt1->neighbors[d] = qt2;
	  qt2->neighbors[opp_neighbor(d)] = qt1;
	}
	else {
	  qt1->drop_neighbor(d);
	  qt2->drop_neighbor(opp_neighbor(d));
	  qt1->neighbors[d] = qt2;
	  qt2->neighbors[opp_neighbor(d)] = qt1;
	}
}

void set_nb_nodrop(neighbor_direction d, quadtree * qt1, quadtree * qt2)
{
//forget drop info, its not really used except for empty boxes,
// anyway
   qt1->neighbors[d] = qt2;
   if (qt2->neighbors[opp_neighbor(d)] == 0)
       qt2->neighbors[opp_neighbor(d)] = qt1;
}



void quadtree::split(int unmarked_only) //unmarked_only initialized to 0
{
    if (is_split()) return;

    // find corners of children

    snap_point * side[4];
    neighbor_direction d;	
    for ( d = 0; d < 4; d++) 
    {
	//in current version, we go back and set all shares accordingly
	// for LEAF boxes, 
	// for non-leaf boxes, we let boxes share to save space
	if ( neighbor(d) != 0
 	&& neighbor(d)->is_split()) {
	    neighbor_direction o = opp_neighbor(d);
	    side[d] = neighbor(d)->child(cl_corner(o))->
		corner(ccl_corner(o));
	}
	else  
        side[d] = new snap_point(midpoint(*corner(cl_corner(d)), 
			*corner(ccl_corner(d))));
    }
    snap_point * center = new snap_point 
	(  midpoint( *(side[east]), *(side[west]) )  );

    // make children

    for (int e = 0; e < 4; e++) {
	quadtree * child = children[e] = new_quad(); //make a new ptquad
	child->father_corner = e;
	child->parent = this;
	child->is_leaf = is_leaf; //if this is_leaf, all progeny is_leaf
	//other stuff initialized by constructor
	child->corners[e] = corners[e];
	child->corners[cl_corner(cl_neighbor(e))] = side[cl_neighbor(e)];
	child->corners[ccl_corner(ccl_neighbor(e))] = side[ccl_neighbor(e)];
	child->corners[cl_corner(cl_neighbor(cl_corner(cl_neighbor(e))))] =
	    center;
    }

//9
/*
 if (testintegrity()) { //see if we have split something we shouldn't have
    cout << "you split the wrong box, buster! \n";
 }
*/

    split_sub(unmarked_only); //distribute contains, virtual:ptquad 


    // set neighbors of children within this square
    for (d = 0; d < 4; d++) 
	set_neighbor( ccl_neighbor(ccl_corner(d)), 
		child(cl_corner(d)), child(ccl_corner(d)) ); 

    // now, see if additional drops are necessary to prevent
    // balance condition from propogating beyond P
    // if balance condition needs to propogate into duplicated box,
    // the duplicated box is split instead of this one
    corner_direction c;

    if (non_empty()) {
	for (c=0; c<4; c++ ) {
	    if (!child(c)->non_empty() && child(c)->somedrop() )
	        child(c)->drop_all();
	}
    }
    for (c=0; c<4; c++) {
      	    if ( child(c)->isdrop_neighbor( (neighbor_direction) 
      	    cl(cl_neighbor(c)) ) && 
            !child( (corner_direction) cl(c) )->non_empty() )
	    	child( (corner_direction) cl(c) )->drop_all();
            if ( child(c)->isdrop_neighbor( (neighbor_direction) 
            ccl(ccl_neighbor(c)) ) &&
            !child( (corner_direction) ccl(c) )->non_empty() )
	    	child( (corner_direction) ccl(c) )->drop_all();
    }
    //only empty boxes should/need to have drops
    for ( c=0; c<4; c++) 
	if (child(c)->somedrop() && !child(c)->non_empty())
		child(c)->drop_all();
	else
		child(c)->zerodrops();

    

    // set neighbors of children outside this square
    neighbor_direction n;
    for ( n = 0; n < 4; n++) {
      int neighbor_there = neighbor(n) != 0 && neighbors[n]->is_split();

      if (neighbor_there) {
	//formerly set_neighbor, introduced bad drops
	//note second arguments neighbor is changed only if it was 0
	set_nb_nodrop( n, children[cl_corner(n)], neighbor(n)->child
		(cl_corner(cl_neighbor(cl_corner(n)))) );
	set_nb_nodrop( n, children[ccl_corner(n)], neighbor(n)->child
		(ccl_corner(ccl_neighbor(ccl_corner(n)))) );
      }

    }

    balance(); //balance condition, virtual:evenquad

    // if this is split by a balance condition and not by the 
    // crowded rules, the children need to be duplicated NOW,
    // as they will not be considered otherwise.
    if ((!unmarked_only) && has_Pvertex()) 
	for (c=0; c<4; c++) 
	    child(c)->recurse(1);
}




quadtree::~quadtree()
{
    if (is_split()) join();

    /* if (parent != 0) {		// have a parent?
	for (int d = 0; d < 4; d++) if (this == parent->children[d]) break;
	if (d < 4) corners[d] = 0; // dont flush parents corner
    } */
    for (int d = 0; d < 4; d++) if (neighbors[d] != 0) {
	//corners[cl_corner(d)] = corners[ccl_corner(d)] = 0; // neighbors corner
	//neighbors[d]->
	    neighbors[cl_corner(cl_neighbor(cl_corner(cl_neighbor(d))))] = 0;
	neighbors[d] = 0;
    }
    // SOMEONE ELSE MAY HAVE DELETED IT
    // Let the program termination free all the store?
    /* for (d = 0; d < 4; d++)
	if (corners[d] != 0)
	    delete corners[d];*/
}



// undo effects of split()

void quadtree::join()
{
    if (!is_split()) return;
    join_sub();

    // delete children (they will take care of corner points)
    
    for (int d = 0; d < 4; d++) {
	// delete children[d]; forget for now
	children[d] = 0;
    }
}


void quadtree::swap(quadtree * dp) 
{

//9 cout << "swapping" << "\n"; 

	int temp = drops;
	drops = dp->drops;
	dp->drops = temp; 
	
	temp = is_leaf;
	is_leaf = dp->is_leaf;
	dp->is_leaf = temp;

	//DON'T CHANGE PARENT OR NEIGHBOR INFO
	// parent->child ( which_child() ) == this; Is invariently true
	//  but now the geo's in this box is not nec a subset of
	//  geo's in parents box.
	// but neighbor(n)->neighbor(opp_neighbor(n)) != this
	//  necessarily, as neighbor is the HEAD of the list of neighbors.

}

//from now on, boxes have non-trivial same sized neighbors based 
// on adjacency
void quadtree::sharecorners(neighbor_direction n, quadtree * nb) 
{
    //neighbors[n] = nb; //is this line needed ? wanted ?
    if (nb==0) ;// drop_neighbor(n);
    else {
	//this next line might overwrite valuable neighbor information
	// in an "orig" (first of many duplicate) box
	//nb->neighbors[ opp_neighbor(n) ] = this; 
	nb->corner( ccl_corner(opp_neighbor(n)))
	    ->changeallptrs( &corners[ cl_corner(n) ] );
	nb->corner( cl_corner(opp_neighbor(n)))
	    ->changeallptrs( &corners[ ccl_corner(n) ] );
    }
}


int conevisible_block_q( geo* looker, geo* target, quadtree* lbox, quadtree* tbox ) {
    point big, lit;
    get_extreme_corners( lbox, tbox, &big, &lit );
    return conevisible_block( looker, target, &big, &lit );

}

int conevisible_noblock_q( geo* looker, geo* target, quadtree* lbox, quadtree* tbox ) {
    point big, lit;
    get_extreme_corners( lbox, tbox, &big, &lit );
    return conevisible_noblock( looker, target, &big, &lit );
}


static inline void sublit( point* test, point* lit )
{
if (test->x < lit->x) lit->x=test->x;
if (test->y < lit->y) lit->y=test->y;
}

static inline void subbig( point* test, point* big )
{
if (test->x > big->x) big->x=test->x;
if (test->y > big->y) big->y=test->y;
}


void get_extreme_corners(quadtree* lbox, quadtree* tbox, point* big, point* lit )
{
    *big = *lbox->bigcorner(); 
    *lit = *lbox->smallcorner();
    for (corner_direction c=0; c<4; c++) {
	sublit( lbox->corner(c), lit );
	if (tbox != 0) sublit( tbox->corner(c), lit );
	subbig( lbox->corner(c), big );
	if (tbox != 0) subbig( tbox->corner(c), big );
    }
}
