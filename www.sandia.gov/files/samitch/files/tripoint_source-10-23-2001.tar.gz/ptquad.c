// ptquad -- quadtree warped to fit a set of points
// Scott Mitchell, Xerox PARC, 1991
// David Eppstein, Xerox PARC, 28 Feb 1990

#include <iostream.h>
#include "ptquad.h"
#include "snap.h"
#include "segdraw.h"

ptquad*  ptquad::top;
ptquad*  ptquad::last;

/* debug */
//#include "define.h"

    static ptquad * topbox;

    int testintegrity() //virtual quad.h
    {return topbox->testboxes(); }

    void ptquad::set_top()
    { topbox = this;  }

void geosnap( snap_point** p, geo * pt )
{
    if (pt->whosnapped != 0 && pt->whosnapped != *p)
        pt->whosnapped->changeallptrs( p );
    pt->whosnapped = *p;
    (*p)->addbackptr( & pt->whosnapped );
    (*p)->snap( *(point*) pt->r );
    (*p)->who = pt;

    //9 if (pt->subfaces) cout << "foul, foul !!!!!!!!!!!!!! \n";
}

typedef points * tvarray[4];
// c is center of box, returns which quadrant p is in
static corner_direction side_of(point p, point c) {
    corner_direction retval;
    if (p.x <= c.x) {
	if (p.y <= c.y) retval = northwest;
	else retval = southwest;
    } else {
	if (p.y <= c.y) retval = northeast;
	else retval = southeast;
    }
    return retval;
}

// boolean, does this belong in box tq, assuming same connected component
    
double ptquad::box_dist( geo* f ) 
{
    return inbox( f, bigcorner(), smallcorner() ) ? 0.0 : 
	f->box_dist( bigcorner(), smallcorner() );
}


inline void markseen( geo * g ) { g->markait(); }    // traversed in cone list
inline int isseen( geo * g ) { return g->marka(); }  //
inline void crossoff( geo * g ) { g->markbit(); }    // invalid cone apex
inline void uncrossoff( geo * g ) {g->markbit(0); }
void crossoffsup( geo * g ) {  // cross off strict superfaces
    for (points* slist = g->superfaces; slist != 0; slist = slist->rest() ) {
	crossoff( slist->first() );
	crossoffsup( slist->first() );
    }
}
inline int iscross( geo * g ) { return g->markb(); }
inline void unmark( geo * g ) { g->markait(0); g->markbit(0); }

void unmarklist( points * glist, int up) {
    for (; glist != 0; glist=glist->rest()) {
	geo * g = glist->first();
	unmark( g );  //unmark self
	// unmark superfaces, and sup-subfaces
	if (up > 0) unmarklist( g->superfaces, up );
	unmarklist( g->subfaces, 0 );  // unmark subfaces only
    }
}

//no going up
void marklist( points * glist ) {
    for (;glist !=0; glist=glist->rest()) {
	crossoff( glist->first() );
    }
}

void unseeall( points * ptlist, points * elist ) {
    //unmark all faces, and all superfaces, and all subfaces of superfaces
    //not the most efficient, but still O( |contains| * f(d) )
    // could just use 1,1 for everyone, 3d 2,2
    unmarklist( ptlist, 1 );  
    unmarklist( elist, 0 ); //could call with 1, but this faster
    //3d  unmarklist( flist, 0 );  and (elist, 1)
}

void ptquad::split_sub(int unmarked_only)
{
    if (!is_split()) return;

    if (unmarked_only==0) {
	marklist( containse );
	marklist( containsp );
    }

    // -- DISTRIBUTE CONTAINS --
    // first put child POINTS where they belong
    // points are placed in only one box at present (may change)
    snap_point * center_point = child(southwest)->corner(northeast);
    tvarray touch_verts;
    corner_direction c;
    for (c=0; c<4; c++)
	touch_verts[c] = 0;

    for (points * plist = containsp; plist != 0; plist = plist->rest()) {
      if (iscross( plist->first() ) ) 
      {
	geo * pt = plist->first();
	point p = * ((point *)(pt->r));

/*
	//test input alignment
	for (neighbor_direction n = 0; n < 4; n++)
	    if (*child(cl_corner(n))->corner(ccl_corner(n)) == p) break; //
	if (n < 4) {
		child(cl_corner(n))->corner(ccl_corner(n))->snap(p);
		cout << "ptquad.c snap corner to p"; }
	else if (*center_point == p) { center_point->snap(p); 
		cout << "ptquad.c snap center_point to p";}
	else {
	    corner_direction c = side_of(p,*center_point);
	    ((ptquad *) child(c))->containsp =
		new points(pt, ((ptquad *) child(c))->containsp);
	}
*/

	    corner_direction c = side_of(p,*center_point);
	    ((ptquad *) child(c))->containsp =
		new points(pt, ((ptquad *) child(c))->containsp);
	    if ( (p.x==bigcorner()->x) || (p.x==smallcorner()->x) ||
 	         (p.y==bigcorner()->y) || (p.y==smallcorner()->x) ||
	         (p.x == center_point->x) || (p.y == center_point->y) ) 
	      touch_verts[c] = new points(pt, touch_verts[c]);  
      }
    }

    // second put child EDGES where they belong
    // edges may be in several boxes
    for (points * elist = containse; elist != 0; elist = elist->rest()) {
	geo * e = elist->first();
	if (iscross(e)) 
	    for (c = 0; c<4; c++) 
	    	if ( put_edge_inbox(e, child(c)->bigcorner(), 
		child(c)->smallcorner(), touch_verts[c]) )
	            ((ptquad *) child(c))->containse =
		        new points(e, ((ptquad *) child(c))->containse);
    }

    for (c=0; c<4; c++)
	delete touch_verts[c];
}

//EPP needed force_neighbor as explained below.
// This is not needed now, as we check crowded on a BFS instead of a DFS
// tree basis


/********** EPP


// the timing of split_sub() may leave us unbalanced
// when we are trying to decide whether we can stop and snap a point.
// therefore we force a neighbor of the same size to exist
// if its at all possible to get one.
//
// we use drop_neighbor to find borders of the bounding square as well,
// so as to avoid going through all the work identifying this twice
ptquad * ptquad::force_neighbor(neighbor_direction n)
{
    if (this==0) return 0;
    if (isdrop_neighbor(n)) return 0; 
	//already decided no neighbor that way
    if (neighbor(n) != 0) {
	ptquad * nb;
	for ( nb = (ptquad *) neighbor(n)->dup; nb!=0; 
	nb=(ptquad *) nb->dup ) 
	    if (true_adjacent( n, this, nb )) return nb;
	if (!adjacent( n, this, neighbor(n) ) ) //return an empty one
	    for ( nb = (ptquad*) neighbor(n)->dup; nb!=0; 
	    nb = (ptquad*) nb->dup )
		if (!nb->non_empty()) return nb;
	//neighbor(n) is adjacent, or there is nothing else more suitable
	return (ptquad *) neighbor(n); 
    }
    if (father() == 0) return 0;
    ptquad * pq = ((ptquad *) father())->force_neighbor(n);
    if (pq == 0) {
	drop_neighbor(n); 
	return 0;
    }
    pq->split();
    return (ptquad *) neighbor(n);
}

// check if the square a boxes over and b boxes across is empty
// a and b are in {0,1,2}.
// we are allowed to split larger boxes.

int ptquad::snap_ok_sub(int a, int b, corner_direction c)
{
    ptquad * pq = this;
    while (a > 0) {
	pq = pq->force_neighbor(cl_neighbor(c));
	if (pq == 0) return 1;
	a--;
    }
    while (b > 0) {
	pq = pq->force_neighbor(ccl_neighbor(c));
	if (pq == 0) return 1;
	b--;
    }
    return (pq->containsp == 0); 
}

int ptquad::snap_ok(corner_direction c)
{
    if (is_split()) return 0;
    if (!snap_ok_sub(1,0,c)) return 0;
    if (!snap_ok_sub(0,1,c)) return 0;
    if (!snap_ok_sub(1,1,c)) return 0;
    return 1;
}

***********/


// *************************** for  ptquad::recurse ******************

int inlist( geo * me, points * lst )
// return 1 if successful, 0 otherwise
{
   if (lst==0 || me==0) return 0;
   for( ;lst !=0; lst=lst->rest() ) 
	if (lst->first() == me) 
	    return 1;
   return 0;
}

void ptquad::add_leaf_sup( ptquad * pq, geo * apex ) {
    //use OO to decide which list to put apex on
    //uncrossoff, so that if split, when we distribute points we
    //can tell who we have already placed
    //MAKE sure geo is in ptquad before automatically placing in box
    uncrossoff(apex);
    if (inlist(apex, pq->containsp) || inlist(apex, pq->containse))
        add_f( apex, &containsp, &containse ); 
    for (points * sups = apex->superfaces; sups != 0; sups=sups->rest() ) 
	add_leaf_sup( pq, sups->first() );
}

//need this==the original box, to test if geo were originally in box
ptquad * ptquad::dupbox(geo * leaf) {
    ptquad * dp = new ptquad();
    add_dup( dp ); //add dp onto the chain of duplicates
    
    // put leaf cone into box
    dp->add_leaf_sup( this, leaf );
    dp->samecorners(this);
    dp->sameneighbors(this);
    dp->samefather(this);
    dp->is_leaf = 1;
    return dp;
}

ptquad* ptquad::find_prev( ptquad * chink )
// find the previous dup to chink
{
    for ( triquad* prev = this; prev != 0; prev=prev->dup )
	if (prev->dup == chink) return (ptquad*) prev;
    cout << "ptquad.c find_prev==0 error";
    return 0;
}

void ptquad::splice_dup( ptquad * condemmed )
{
     // assume no parent, and not split, next unset
    if ( condemmed->is_split() ) {
	cout << "ptquad.c splice_dup error";
	//exit(9);
    }
    ptquad * prev = find_prev(condemmed);
    prev->dup = prev->dup->dup;
    condemmed->dup = 0;
    // delete condemmed;  watch corners, etc
}

void ptquad::duplicate(points ** leaf, int crowded ) {
    if (!crowded) is_leaf = 1;
    ptquad * last_new_leaf = 0;
    for ( points * lf = *leaf; lf != 0; lf = lf->rest()) 
	last_new_leaf = dupbox( lf->first() );
  
    // Since we no longer split, throw away the original contents,
    // by covering it with the first (new) leaf box contents
    if (!crowded && last_new_leaf != 0) {
	containsp = last_new_leaf->containsp;
	containse = last_new_leaf->containse;
	copydrops( last_new_leaf );
	redirect_neighbors( last_new_leaf );
       	splice_dup( last_new_leaf );
	is_leaf = 1;
    }
    delete *leaf;
}

static inline double min (coor v1, coor v2 ) { return (v1<v2) ? v1 : v2; }
//not used at present
//compute "distance" between cone with apex a and face f
double ptquad::conedist( geo* a, geo* f) {
    // find point for a
    // note, no subface of a intersects with the box this
    // a modeller would be nice
    point p1, p2, f1, f2;    
    int p2valid= a->r->apex_points(a, bigcorner(), smallcorner(), &p1, &p2 );
    int f2valid= f->r->apex_points(f, bigcorner(), smallcorner(), &f1, &f2 );

    if (p2valid && f2valid) 
	return 
	  min(  a->r->f_to_pt_dist( a, &f1 ), f->r->f_to_pt_dist( f, &p1 ) );
    else if (p2valid)
	return a->r->f_to_pt_dist( a, &f1 );
    else 
        return f->r->f_to_pt_dist( f, &p1 );
}

void ptquad::allcones( points* ptlist, int * crowded, double hfactor )
{
     for ( ; ptlist != 0; ptlist=ptlist->rest() ) {
	geo * pt = ptlist->first();
	markseen(pt);
	// for superface edge
	for (points * elist = pt->superfaces; elist != 0; elist=elist->rest()){
	    geo * e = elist->first();
	    markseen(e);
	    crossoff(e);
	    // for subface point
	    for (points * plist = e->subfaces; plist != 0; plist=plist->rest()){
		geo * p2 = plist->first();
		// ignore if pointing back at self
		if (p2 != pt) {
		    // if its in the box, or extended box
		    if ( isseen(p2) || 
		    (p2->box_dist(bigcorner(),smallcorner()) < hfactor) )
		    { 
			crossoff( pt );
			crossoff( p2);
			*crowded=1;
		    }
		    
		}
	    }
	}
    }
}


// used by ptquad::recur()
// leaf is a list of leaf cones that can't see one another, but
// perhaps see non-leaf face
// apexlist is a list of candidates for addition to leaf

void ptquad::buildleafcan( points * apexlist, points ** leaf, int * crowded ) 
{
    // for all cones on apexlist
    for ( ; apexlist != 0; apexlist=apexlist->rest()) 
    {
      if (! iscross( apexlist->first() )) 
      {
	geo * lfcan = apexlist->first(); //candidate leaf cone
	// check if visible with existing leaf cone list
	points * prev=0;
	for ( points * lf = *leaf; lf != 0; /*below*/ ) 
	{
	    geo * lfc = lf->first();
	    int lfcansee = conevisible_block_q(lfcan, lfc, this, 0 );
	    int lfcsee = conevisible_block_q( lfc, lfcan, this, 0 );
	    
	    if (lfcsee || lfcansee) {
		// try to find common apex
		geo * a = apex_common( lfcan, lfc );
		if (a != 0) 
		{
		    // put common apex on list instead
		    lf->g = a;
		    crossoffsup( a ); //cross off *all* superfaces in lattice
		    prev=lf; lf=lf->rest(); //iterate
		    continue; //skip rest of tests
		}
		else { *crowded = 1; }
	    }

	    if (lfcansee) crossoff( lfcan );

	    if (lfcsee) { 
		crossoff( lfc );
		//remove lfc from leaf list
		splice( leaf, prev, &lf );  //iterates, too
	    }
	    else {  prev=lf;  lf=lf->rest();  }  //iterate
	}
	if (!iscross( lfcan )) //can't see any candidate, is apex, put on list
	    *leaf = new points( lfcan, *leaf );
      }
    }
}
    

// check if any leaf cone can see a face, and act accordingly
// this is the box that the leafs are in
void ptquad::check_box( points * flist, points ** leaf, int * crowded, 
	double hfactor, ptquad * fbox )
{
    if (*leaf == 0 ) return;  //speedup
    for ( ; flist!=0; flist=flist->rest() ) {
	geo * f = flist->first();
   	points * prev=0;
	for ( points * lf = *leaf; lf!=0; /*below*/ ) {
	    geo * a = lf->first();
	    int iterate_already = 0;
	    if ( conevisible_block_q( a, f, this, fbox) )
		//ignore if they have a common subface
		if (apex_common( f, a ) == 0) 		
		  if (f->box_dist(bigcorner(),smallcorner()) < hfactor)
                  // a can see f, f not part of cone, take a out
	          {
		    *crowded = 1;
		    crossoff( a );
		    splice( leaf, prev, &lf );  //iterates, too
		    iterate_already = 1;		
	          }
		
	    if ( !iterate_already ) {  prev=lf; lf=lf->rest();  }
	}
    }
}


// get a box covering the extended neighbor "zone" in direction n
// the original box, and not any duplicates, are returned
//
// -------------
// |__|__|     |
// |  | *|     |   for box *, the "zones" are the four big boxes,
// +------+-----   numbered from the parent clockwise
// |     |     |   
// |     |     |
// +------+-----
//
//
// n is not a true compass direction, but only an index to
// one of four boxes that contain the extended box 
//
ptquad * ptquad::get_ext_neighbor( int n ) 
//Because of BFS, if there is not a neighbor, it is because it is
// not truly adjacent (balance condition did not require it).
//Or, of course, the bdy of the big bounding square may have been 
// reached.
{

    int m; 
    ptquad * fn;
    if (n==0) m=0;
    else if (n<3) m=1; 
    else if (n==3) m=2;
    else m=3;
    neighbor_direction i = (neighbor_direction) which_child();
    switch (m) {
	case 0: return (ptquad*) father();
	case 3: i=(neighbor_direction) cl(i);
		n=n-3;
	case 1: fn = (ptquad*) father()->neighbor(i);
		if (fn==0) return 0;
		if (n==1) return (ptquad*) fn->child( cl_corner( opp_neighbor(i) ) );
		else      return (ptquad*) fn->child( ccl_corner( opp_neighbor(i) ) );
	case 2:  // try two paths to corner neighbor
		 fn = (ptquad*) father()->neighbor(i);
		 if (fn) {
		    fn = (ptquad*) fn->neighbor( (neighbor_direction) cl(i) );
		    if (fn) {
			fn = (ptquad*) fn->child( opp_corner( which_child() ) );
			if (fn) return fn;
		    }
		 }
		 fn = (ptquad*) father()->neighbor( (neighbor_direction) cl(i) );
		 if (fn) {
		    fn = (ptquad*) fn->neighbor( i );
		    if (fn) {
			fn = (ptquad*) fn->child( opp_corner( which_child() ) );
			if (fn) return fn;
		    }
		 }
		 return 0;
	default: return 0;
    }
}


void ptquad::check_ext_box( points ** leaf, int * crowded,
	double hfactor )
{   // MUST check this box as well as true neighbors
    if ( *leaf == 0 ) return; //speedup
    if (is_top()) return;
    for (int i=0; i<6; i++) 
        for (ptquad * nb = get_ext_neighbor(i); nb != 0; nb= (ptquad*) nb->dup )
            {
	        check_box( nb->containsp, leaf, crowded, hfactor, nb );
	        check_box( nb->containse, leaf, crowded, hfactor, nb );
	    }

}

// continue splitting boxes or stop (and snap??)
// SAM in progress


void ptquad::recurse(int dup_only) //defaulted to 0
{


    if (is_split()) {
	if (!is_leaf) {
	    for(corner_direction c=0; c<4; c++)
		((ptquad*) child(c))->stack();
	    cout << "why ";
	}
	return;
    } //already split, why were we called? stack?

    // TEST if crowded - a lot of work!!
    // find cones
    unseeall( containsp, containse ); // cleanup BEFORE self
    int crowded=0;
    coor hfactor = h();  //depends on box geometry
  
    // eliminate from consideration as apexes points that are endpoints
    // of an edge that has another point close by
    // for point in question
    allcones( containsp, &crowded, hfactor );

    // now, cone appexes are uncrossed points and edges
    // and apexoutside cones (unbuilt so far)
    // build (candidate) list of leaf (component) cones
    // considering visibility to **one another only**
    points * leaf = 0;
    buildleafcan( containsp, &leaf, &crowded ); //important to do p first
    buildleafcan( containse, &leaf, &crowded ); // e second

    // make sure component cones can see no face in extended box 
    // note extended box contains the box itself, wich needs to be checked, too
    if (!dup_only) check_ext_box( &leaf, &crowded, hfactor );

    // duplicate for remaining cones (no dup if one leaf cone, and uncrowed)
    // special balancing conditions around boxes with points goes in duplicate
    duplicate( &leaf, crowded );


    if (crowded && !dup_only) {
	split(1);
        // recursively split children
        for (corner_direction c = 0; c < 4; c++) 
	    ((ptquad *) child(c))->stack();
    }
}


void ptquad::recur()
{
    set_top(); //9 debugging
    top=0;
    for( this->stack(); top != 0; top = top->pop() ) {
	top->recurse();
    }

}

//friend
int checkcross(point &p1, point &p2, geo * e, int d, 
		       point &b1, point &b2, point& bc, int cwb1, int cwb2,
		       point &first_cross, geo*& first, int &first_cross_d)
//p1, p2 are endpts of Pedge e, b1 b2 are box vertices on Oedge d
//bc for checking rotation, d for side b1,b2
//returns one if an intersection is detected, whether replaced or not
{

    if (cwb1 == cwb2 && cwb2 != 0) return 0; 
    //heuristic speedup, no crossings

    int cwp1 = cw(b1,b2,p1);
    int cwp2 = cw(b1,b2,p2);

    if (cwp1==0 || cwp2==0) { //speedup, usually skip over these tests

        //cout << " colinearity detected ";

	int p1on = (cwp1==0) && pointbetween(b1,b2,p1);
	int p2on = (cwp2==0) && pointbetween(b1,b2,p2);

	//note, only the far box edge may be contained by the Pedge, and
	// for this case the next cw edge would pick it up as a cross edge 
        if (p1on && p2on) {
	    if (cw(bc,p1,p2)<0) //p2 is more cw, so better
		p1on = 0;
	    else
		p2on = 0;
	}
	if (p1on) {
	    if ((first_cross_d < d) || cw(bc, first_cross, p1)<0) {
		first = e->subfaces->first();
		first_cross = p1;
		first_cross_d = d;
	    }
	    return 1;  //no need to check other box edges
	}
	else if (p2on) {
	    if ((first_cross_d < d) || cw(bc, first_cross, p2)<0) {
		first = e->subfaces->rest()->first();
		first_cross = p2;
		first_cross_d = d;
	    }
	    return 1;  //no need to check other box edges
	}
	return 0;
    }

    //normal interior cap tests
    else if (cwp1 != cwp2) { //tested cwb1 != cwb2 already

	//calculate crossing
	point c = crossingpt(p1,p2,b1,b2); 
	if ((first_cross_d < d) || cw(bc,first_cross,c)<0) {
	    first = e;
	    first_cross = c;
	    first_cross_d = d;
	}
	return 1;
    }
    return 0;
}


int adjacent(neighbor_direction d, quadtree* qt1in, quadtree* qt2in) 
// d is direction from qt1in to qt2in, same size boxes
//
// if qt1 non_empty, can qt1 see qt2,
// watch what happens when duplicates are around
//
// boundary march scheme
//
//having this function in this file avoids moving almost all of
//quad.c into ptquad.c
{
#define qt1 ((ptquad*) qt1in)
#define qt2 ((ptquad*) qt2in)

    //if both empty, return 1, else swap so that qt1 is non-empty
    if (qt1->containse == 0 && qt1->containsp == 0) {
	if (qt2->containse == 0 && qt2->containsp == 0)
	    return 1;
	else {
	    quadtree * qtemp = qt1in;
	    qt1in = qt2in;
	    qt2in = qtemp;
	    d = opp_neighbor(d);
	}
    }

    geo * first = 0;  //first edge encountered around the bdy
    point first_cross;  //where it intersects
    int first_cross_d = -1; //which box side it intersects

    //box corners
    point b[4];
    b[0] = * qt1->corner(ccl_corner(d));  //shared corner
    b[1] = * qt1->corner(cl_corner(d));  //shared corner
    b[2] = * qt1->corner(ccl_corner(opp_neighbor(d)));  //far corner
    b[3] = * qt1->corner(cl_corner(opp_neighbor(d)));  //far corner

    int cw0, cw1, cw2, cw3; //cw from edge to box corners?
    int cwp1, cwp2;  //cw from box edge to P vertices

    for (points * elist= qt1->containse; elist != 0; elist=elist->rest()) {
	geo * e = elist->first();
	
	point * p1 = e->endpt1();
	point * p2 = e->endpt2();

 	cw0 = cw(*p1,*p2,b[0]); cw1 = cw(*p1,*p2,b[1]); 

	// ***** E0 check common edge first *****
	if ((cw0==0) && (cw1==0)) return 1; //colinear with box edge, must cap

	cwp1 = cw(b[0],b[1],*p1); cwp2 = cw(b[0],b[1],*p2);

	if ((cw0 != cw1) && (cwp1 != cwp2)) return 1; //crosses shared box edge

	// ***** check E3, cwmost edge *****
	cw3 = cw(*p1,*p2,b[3]);
        if (checkcross(*p1, *p2, e, 3, b[3], b[0], b[1], cw3, cw0,
		first_cross, first, first_cross_d) || (first_cross_d>2))
		continue;

	// ****** check E2, far edge ******
	cw2 = cw(*p1,*p2,b[2]);
        if (checkcross(*p1, *p2, e, 2, b[2], b[3], b[0], cw2, cw3,
		first_cross, first, first_cross_d) || (first_cross_d>1))
		continue;

	// ****** check E1, least cw edge ******
        checkcross(*p1, *p2, e, 1, b[1], b[2], b[3], cw1, cw2,
		first_cross, first, first_cross_d);

    } //for elist

    //first is found, now check if it can see in the right direction

    //hole or isolated component
    //find lowest vertex and look from there
    if (first == 0)  {
	if (qt1->containsp==0) {  //9
	    cout << " error no cross edge or vertex in adj \n";
	    qt1->testme();
	    point p1 (*qt1->containse->g->endpt1());
	    point p2 (*qt1->containse->g->endpt2());
	    cout << " p "<< p1.x<< "," << p1.y<<"  "<<p2.x <<","<< p2.y << "\n";
	    cout << " cw " << cw0 << cw1 << cw2 << cw3;	   
	    cout.flush();
	}
	first = qt1->containsp->g;
	first_cross = *((point *)first->r);
	first_cross_d = 3; //so points towards box qt2
	for (points* vlist =qt1->containsp->rest(); vlist; vlist=vlist->rest()) {
	    if (bigger( *(point*)vlist->g->r, first_cross, d)) {
		first = vlist->g;
		first_cross = *((point *)first->r);
	    }
	}
    }
    point t; //point to test visiblity
    if (first_cross_d == 3)
	t = b[0] + b[0] - b[3];
    else if (first_cross_d == 2)
	t = b[3] + b[3] - b[2];
    else 
	t = b[2] + b[2] - b[1];
    return first->r->conesee(&t, first);
   
#undef qt1 
#undef qt2  
}

		

geo * ptquad::lf_apex()
//used by true_adjacent
//given that this is a leaf box, find the leaf cone apex
//if this is not a leaf box, just return any old face
{
    if (containsp != 0) return containsp->first();
    if (containse != 0) {
	if (containse->rest() == 0) 
	    return containse->first();  //just one edge 
	else {
	    geo * a = apex_common
		(containse->first(),containse->rest()->first());
	    if (a != 0)       //vertex cone with apex outside box
		return a;
	    else 
		return containse->first(); //wasn't a leaf box, return
					   // any old edge
	}
    }
    return 0;  //empty box
}

int true_adjacent(corner_direction c, neighbor_direction n,
 quadtree* qt1in, quadtree* qt2in, int qt2small)
 //returns correct adjacency after boxes have been duplicated
//assumes boxes are neighbors, from qt1 to qt2 is in direction c, a common corner,
//and BOTH boxes have leaf cones (but may have been split by the balance 
// condition) 
//boxes differ in height by one level if qt2small = 1 or 2
// qt2small = 2 means treat adjacent if they share an edge, or other tests
// hold
//boxes have not been warped
{
#define qt1 ((ptquad*) qt1in)
#define qt2 ((ptquad*) qt2in)

   geo * a1 = qt1->lf_apex();
   geo * a2 = qt2->lf_apex();
   if (a1 == 0 && qt1->isdrop_neighbor( n ) 
   ||  a2 == 0 && qt2->isdrop_neighbor(opp_neighbor(n)) ) return 0;
   if (a1 == 0 && a2 == 0) return 1;
   // be truly empty, as the child of duplicated box split because of
   // the balance condition is tested above
   // I think this is ok

   if (a1 == 0) {
	point p( midpoint(*qt1->corner(southwest),*qt1->corner(northeast)) );
	geo g( &p );
	return conevisible_noblock_q(a2,&g,qt2,qt1);
   }
   if (a2 == 0) {
	point p( midpoint(*qt2->corner(cl_corner(opp_neighbor(n))),
			  *qt2->corner(ccl_corner(opp_neighbor(n))) ) );
	geo g( &p );
	return conevisible_noblock_q(a1,&g,qt1,qt2);
   }

   //cone in each box, as opposed to one or other being empty
   // i don't think block or noblock matters here
   if (qt2small==0)
       return ( conevisible_noblock_q(a1,a2,qt2,qt1) && 
 	        conevisible_noblock_q(a2,a1,qt1,qt2) ); 
   else {
	if ( ! (conevisible_noblock_q(a1,a2,qt2,qt1) &&
            conevisible_noblock_q(a2,a1,qt1,qt2) ) ) return 0;
	if (qt1->has_Pvertex() && qt2->has_Pvertex()) 
		return (qt1->containsp->first() == qt2->containsp->first());
		//by crowded rules, this is correct, actually never happens
	//check if the corner point on their boundary is in P 
	if (qt1->leaf_box_point_vis(qt1->corner(c)) 
	&&  qt2->leaf_box_point_vis(qt1->corner(c))) 
	    return 1;
	// corner point not seen, check if boundary is crossed
	// as if boundary not crossed, entire boundary not seen
	//  with some cases removed because of crowded conditions
	edge erep; point p1 ( *qt1->corner(c) );
	point p2 ( * qt2->corner(opp_corner(c)) );
	geo edg(&erep), g1( &p1 ), g2( &p2 );
	edg.contains( &g2); edg.contains( &g1 ); 
	for (points* elist = qt2->containse; elist != 0; elist=elist->rest())
	    if (   inlist(elist->first(), qt1->containse) && 
	    ( (qt2small == 2) || (edg.r->cap(&edg, elist->first()) == 1)  ) )
		return 1;
	return 0;
   }
}


int balance_adjacent( neighbor_direction d, quadtree* qt1in, quadtree* qt2in) 
//for balance,  we know that qt2in is a leaf box, by BFS crowded checking
//this could serve for true_adjacent, as well
//qt2in is the big box, that we may want to split by balance
{
    geo * a1 = qt1->lf_apex();  //if not a leaf box, returns any face
    geo * a2 = qt2->lf_apex();
    //both empty case
    if (a1 == 0 && a2 == 0)
	return !(qt2->isdrop_neighbor(opp_neighbor(d)) ||
	         qt1->isdrop_neighbor(d));
    //little box empty case
    if (a1 == 0) {
	if (qt1->isdrop_neighbor(d)) return 0;  //i think this is always 
	//test far corners for visibility
	geo pg1 ( qt1->corner( cl_corner(d) ) );
	geo pg2 ( qt2->corner( ccl_corner(d) ) );
	return ( conevisible_block_q( a2, &pg1, qt1, qt2) 
	      && conevisible_block_q( a2, &pg2, qt2, qt1) );
    }
    //big box empty case
    if (a2 == 0) {
	return (!qt2->isdrop_neighbor(opp_neighbor(d)) && 
	    adjacent( d, qt1, qt2 ));
    }
    //neither box empty case
    // note that qt2 is a leaf box.  So, by our crowded rules,
    // any face in qt1 that is visible
    // in the connected component sense would have to be "non-foreign"
    // to the the apex of qt2 = a2.
    for (points * elist = qt1->containse; elist!=0; elist=elist->rest()) {
        if (a2->is_sub( elist->first() )) return 1;
	//also, could be two edges
	geo * a = apex_common( a2, elist->first() );
	if (a) if (!a->reflex()) 
	    return 1;
    }
    return 0;
}


//---------------------------- WARPING STUFF --------------------

//return the i^th crosspoint for edge e in this box
/*
snap_point * ptquad::crosspoint( geo * e, int i )
{
    for(int j=0; j<maxcross; j++) 
        if (crosses[j] != 0)
	  if (crosses[j]->crosse == e) {
	      dec(i);
	      if (i==0) return crosses[j]->me;
	  }
    return 0;
}
*/
/*
int ptquad::addbest( snap_point * p, geo * e, snap_point * pbox1, snap_point * pbox2 )
//return value of 1 indicates successful change
{
    if (p==0) return 0;
    snap_point * p1 = crosspoint(e, 1);
    snap_point * p2 = crosspoint(e, 2);
    if (p2 != p && p1 != p) {
        if (p2 == 0) addcross(p,e,pbox1,pbox2);
	else { //p1!=0 && p2!=0
	    if ( norm(*p-*p2) > norm(*p1-*p2) && norm(*p-*p1) > norm(*p1-*p2) )
		addcross(p,e,pbox1,pbox2);
	}
	return 1;
    }
}
*/
//-------------- ABOVE IS NOT CURRENT -----------------
void ptquad::get_all_crosses(crosspt** c1, crosspt** c2, snap_point*p1, snap_point*p2)
//return all crosses of edge p1, p2 in c1 and c2
{
    *c1 = 0; *c2 = 0;
    for( points * elist = containse; elist != 0; elist=elist->rest() ) {
	geo * e = elist->first();
	crosspt * c = crosses->findcrosspt( e, p1, p2 );
	//store for future use
	if (c) {
	    if (! *c1) *c1=c; 
	    else *c2=c;
	}
    }
}

void ptquad::find_both_e_crosses( snap_point** c1, snap_point** c2, geo* e )
{
    *c1 = 0; *c2 = 0;
    if (containsp !=0) {
	*c1 = centroid; //snap point for lf_apex
	for (crosspt * c = crosses; c!=0; c=c->next)
	    if (c->crosse == e)
		*c2 = c->me;
    }
    else {
        for (crosspt * c = crosses; c!=0; c=c->next) 
	    if (c->crosse == e) {
	        if (*c1==0) 
		    *c1 = c->me;
		//allow some overwrite for degen
	        else if (*c2==0 || *c2 == *c1)
		    *c2 = c->me;
	    }
    }
}


// set crossing edges to share the same data space
//O-edge is between c1 and c2
//nb is neighbor sharing the O-edge
void ptquad::share_edge_crosses(snap_point* c1, snap_point* c2, 
	snap_point* vboxin, int vboxsubin, triquad * nbt)
{
//typcast
#define nb ((ptquad*)nbt)

    //check to see if any P-edge crosses O-edge
    for (points * elist = containse; elist != 0; elist=elist->rest() ) {
	geo * e = elist->first();
	if (inlist(e,nb->containse)) 
	    if (ecap(*c1,*c2,*e->endpt1(),*e->endpt2())) 
		allocate_cross( c1, c2, vboxin, vboxsubin, e )->
		  sharedata( nb->allocate_cross( c1, c2, vboxin, vboxsubin, e));
    }
#undef nb
}


void ptquad::set_edge_crosses()
//call after sides set, within set_sides
{

    //check to see if any P-edge crosses O-edge
    for (points * elist = containse; elist != 0; elist=elist->rest() ) {
	geo * e = elist->first();
	for (neighbor_direction n=0; n<4; n++) 
	    if (side(n) == 0)
		set_edge_crosses_loc( corner(cl_corner(n)), 
		  corner(ccl_corner(n)), e);
	    else {
		set_edge_crosses_loc( corner(cl_corner(n)),
		  side(n), e);
		set_edge_crosses_loc( corner(ccl_corner(n)),
		  side(n), e);
	    }
    }
}

//utility for draw_crosses

typedef int (*binfn)( snap_point * p, snap_point * p2);
inline	int xless( snap_point * p, snap_point * p1) {return p->x < p1->x;} 
inline	int yless( snap_point * p, snap_point * p1) {return p->y < p1->y;} 
typedef snap_point * snaparray[8];

class linesnaps {
  private:
	//member
	snaparray snaps;
	int numsnaps;
	geo * e;

	//functions
	void sort();

  public:
	//constructor
	linesnaps() {;}
	void reset(geo * ein) {numsnaps = 0; e=ein;}

	//functions
	void addsnap(snap_point * p);
	void draw(segdrawer * s);

};


void linesnaps::sort() {
//assume numsnaps > 2

  if (numsnaps < 3) return;  //no need to sort if just two,
			     //as we don't care if we ascend or descend
				
  //decide if about horizontal or about verticle
  int i;
  coor maxx = snaps[0]->x;  coor minx = maxx;
  coor maxy = snaps[0]->y;  coor miny = maxy;
  for (i=1; i<numsnaps; i++) {
	if (snaps[i]->x > maxx) maxx=snaps[i]->x;
	if (snaps[i]->x < minx) minx=snaps[i]->x;
	if (snaps[i]->y > maxy) maxy=snaps[i]->y;
	if (snaps[i]->y < miny) miny=snaps[i]->y;
  }
  binfn lessthan = ((maxx-minx)>(maxy-miny)) ? &xless : &yless;

  //bubble sort
  snap_point * tmp;
  for (i=0; i<(numsnaps-1); i++)
    for (int j=i+1; j<numsnaps; j++)
	if (lessthan(snaps[j],snaps[i])) 
	{
	    tmp = snaps[j];
	    snaps[j] = snaps[i];
	    snaps[i] = tmp;
	}
}

void linesnaps::draw(segdrawer * s)
{
    int i;
    if (numsnaps<2) return;
    sort();
    for (i=0; i<(numsnaps-1); i++)
	(*s) (snaps[i], snaps[i+1]);  //actual drawing
}


void linesnaps::addsnap(snap_point * p)
//find unique snap points, put in this->snaps
{
  if ((p != 0) && (p->who) && (p->who->is_sub(e))) {
    int found_prev=0;
    for (int i=0; (i<numsnaps) && (found_prev==0); i++)
	if (p == snaps[i]) 
	    found_prev=1;
    if (found_prev==0)
	snaps[numsnaps++] = p;
  }
}

void ptquad::draw_crosses(segdrawer * s)
//care must be taken to not draw an edge that is warped to a split side
{
    linesnaps snapped_to_e;
    for (points * elist = containse; elist != 0; elist=elist->rest() ) {
	geo* e = elist->first();
	snap_point * c1, * c2;
	find_both_e_crosses( &c1, &c2, e );
	//if (c1==0 || c2==0) cout << " draw_crosses error ";
	//not an error in the presence of long Pedges aligned with Oedges

	//find all the vertices snapped to the edge, including the crosses
	snapped_to_e.reset( e );
	snapped_to_e.addsnap(c1); 
	snapped_to_e.addsnap(c2); 
	for (neighbor_direction n=0; n<4; n++) 
	  snapped_to_e.addsnap(side(n));
	for (corner_direction c=0; c<4; c++)
	  snapped_to_e.addsnap(corner(c));

	//draw consecutive edges
	snapped_to_e.draw(s);
    }
}

//used as a test by triquad to totally skip drawing boxes with no volume
int ptquad::no_volume() 
//return 1 if the box intersected with P has no volume
{
  if (containsp || !containse) return 0;  //has a vertex, or no edges
  geo * e = containse->first();
  for (neighbor_direction n=0; n<4; n++)
	if (side(n) &&  //side exists
	  !(side(n)->who && side(n)->who->is_sub(e)) //not snapped to edge
	  && (e->r->conesee(side(n),e)) ) return 0;     //but still visible
  for (corner_direction c=0; c<4; c++)
	if ( !(corner(c)->who && corner(c)->who->is_sub(e)) //not snapped toedge
	  && (e->r->conesee(corner(c),e)) ) return 0;     //but still visible
  return 1;
}

void ptquad::chose_centroid()
{
    neighbor_direction n;
    corner_direction c;

    if (centroid) return;
    if (containse==0) {  //easy way for simple boxes, with nothing snapped
	int no_snap = 1;
	for (n=0; n<4; n++)
	    if (side(n)) if (side(n)->who) no_snap = 0;
	for (c=0; c<4 && no_snap==1; c++)
	    if (corner(c)->who) no_snap = 0;
	if (no_snap) {
	    for (n=0; n<4; n++)
	        if (side(n)) {
		    side(n)->changeallptrs( &centroid );
		    return;
	        }
	    corner((corner_direction) 0)->changeallptrs( &centroid );
	    return;
	}
    }
    int volume = 0, numpts=0, colinear_point=0;
    geo * e = 0;
    
    for (c=0; c<4; c++)
	if (regularize(c, colinear_point))
          chose_centroid_loc( corner(c), &numpts, &e, &volume );  
    for (n=0; n<4; n++) 
   	chose_centroid_loc( side(n), &numpts, &e, &volume );
    for (crosspt * test = crosses; test !=0; test=test->next) {
	// make sure not already counted - not critical if counted twice
	int doit = 1;
	for (n=0; n<4 && doit==1; n++) 
	  doit = test->me != side(n);
	for (c=0; c<4 && doit==1; c++)
	  doit = test->me != corner(c);
	if (doit) 
	    chose_centroid_loc( test->me, &numpts, &e, &volume );
    }

    chose_centroid_finalize( volume, numpts, colinear_point );

}

// return true if this point is on the boundary if we regularize the
// box cap P  , if combined with visibility checks as well
int ptquad::regularize( corner_direction c, int & colinear_point)
{
   if ( !corner(c)->who ) return 1;
   geo * w = corner(c)->who;
   snap_point * ccwpt = side( ccl_neighbor(c) )!=0 && 
	side( ccl_neighbor(c) )!=corner(c) ?
 	side( ccl_neighbor(c) ) : corner( ccl_corner( ccl_neighbor( c ) ) ); 
   snap_point * cwpt = side( cl_neighbor(c) )!=0 &&
        side( cl_neighbor(c) )!=corner(c) ?
	side( cl_neighbor(c) ) : corner( cl_corner( cl_neighbor( c ) ) ); 
   if ( corner(c)->who->subfaces ) {
	if (!cwpt->who->is_sub(w) && leaf_box_geo_point_vis( w, cwpt ) ) return 1;
        if (!ccwpt->who->is_sub(w) && leaf_box_geo_point_vis( w, ccwpt ) ) return 1;
 	//bug fix april 2 1993, colinear_point
	if (cwpt->who->is_sub(w) && ccwpt->who->is_sub(w)) 
		colinear_point = 1;
	return 0;
   }
   else { //corner snapped to a vertex, need to be tricky

	if (cwpt->who)  
	    return (leaf_box_geo_point_vis(cwpt->who, 
		corner(ccl_corner(ccl_neighbor(c)))));
        if (ccwpt->who) 
 	    return (leaf_box_geo_point_vis(ccwpt->who,
		corner(cl_corner(cl_neighbor(c)))));

	//neither point snapped, test if any point of box other 
	// than corner(c) is in P
	if (leaf_box_point_vis(cwpt) || leaf_box_point_vis(ccwpt)) return 1;
	
	for (crosspt * cp = crosses; cp!=0; cp=cp->next) 
	  if (cp->me != corner(c)) return 1; //this edge cuts through the box

	return 0;
   }
}

// average of points on the boundary
void ptquad::chose_centroid_loc( snap_point * boxpt, int * numpts, geo ** e,
int * vol ) 
{
    if (boxpt) if (leaf_box_point_vis( boxpt )) {
	if (centroid!=0) 
	    centroid->snap( (*centroid) + (*boxpt) ); //vector add
	else  {
	    centroid = new snap_point ( boxpt->x, boxpt->y ); //leave as is
	    centroid->addbackptr( &centroid );
	}
	(*numpts)++;
	//now check if the box cap P has volume
	// by checking if a visible point is unsnapped, or two visible
	// points are snapped to different edges.
	if (boxpt->who) {
	     if (boxpt->who->subfaces)  //snapped to edge
	  	if (*e) { //somebody was snapped to an edge.
	  	  if (*e != boxpt->who) //boxpt snapped to different edge
			*vol = 1;
	  	}
	  	else //save the first edge someone was snapped to
	    	  *e = boxpt->who;
	}
	else //boxpt visible, and not snapped to anything
	  *vol = 1;
    }
}

void ptquad::chose_centroid_finalize( int volume, int numpts, int colinear_point )
{
  if (volume==0 || (numpts+colinear_point)<4) {  //no centroid wanted or needed
    if (centroid) {
      //delete (centroid);
      centroid = 0;
    }
    return;
  }
  else {
    centroid->snap( (*centroid) / numpts ); //scalar division
  }
}

int ptquad::has_Pvertex()
{
    return (containsp != 0);
}



void ptquad::draw_diags(segdrawer * s)
// for this to work, we need that a box with an vertex
{

    chose_centroid();
    if (!centroid) return; //no centroid if all snapped to one line and pt

    // can be trouble if containsp != 0 and split sides are adjacent to 
    // the corner that is warped to the P-vertex.
    // this is because centroid is not centered, but snapped to a side
    //this trouble is avoided by the additional balance condition that
    //no box containing a vertex is bigger! than its neighbor,
    //so sides are always zero for a P-vertex containing box
    for (corner_direction c=0; c<4; c++)
	draw_diags_loc( corner(c), s );

    for (neighbor_direction n=0; n<4; n++)
	if (side(n)) 
	    draw_diags_loc( side(n), s );

    for (crosspt * cr = crosses; cr != 0; cr=cr->next) 
	 (*s)( centroid, cr->me );
}

//draw from centroid to p if p is inside the region
void ptquad::draw_diags_loc( snap_point * p, segdrawer * s)
{
    if (leaf_box_point_vis( p ))
	(*s)( centroid, p );
}

void ptquad::warpcrosspoints_loc(snap_point** p, coor close) 
//find the closest edge that is close to pt p of box, and warp to it
{
    snap_point * pp = *p;
    if (pp==0) return;
    if (pp->snapped()) return; //don't warp again to an edge
    geo * eclosest = 0; coor eclosest_dist = close;
    geo * e; coor edist;

    //find the closest Pedge (may be two if has_Pvertex())
    for ( points * elist = containse; elist !=0; elist=elist->rest() ) {
	e = elist->first();
	edist = e->r->f_to_pt_dist(e, pp);
	if ( edist <= eclosest_dist ){
	    eclosest_dist = edist;
	    eclosest = e;
	}
    }
    if (eclosest != 0) {
	int which;
	pp->snap( closestpt(*eclosest->endpt1(), 
		  *eclosest->endpt2(), *pp, which));
	if (which==0)
		pp->who = eclosest;
	else { //snap to a vertex, heavy sharing to do
	  geosnap(p, (which==1) ? eclosest->subfaces->g : 
				  eclosest->subfaces->rest()->g);
	}
    }
}
  

void ptquad::warpcrosspoints( coor close ) 
//warp corners and sides to edges
{
  //for each possible warping point
  for (corner_direction c = 0; c<4; c++ ) 
	warpcrosspoints_loc( &corners[c], close );
  for (neighbor_direction n = 0; n<4; n++ )
	warpcrosspoints_loc( &sides[n], close );
}



/* 1/8 of box diagonal length */
#define eclosefactor 0.125

void ptquad::warpbox()
{
    if (!non_empty()) return;
    coor d, hfact = h();  //diag
    coor close = hfact * eclosefactor;
    if (containsp != 0) 
    {

	geo * ptgeo = containsp->first();
	point * pt = (point *) ptgeo->r;

	//warp closest corner or side to vertex
	//ok to warp something already warped HERE only
	coor mind=hfact;  corner_direction minc;
	neighbor_direction minn; int side_closest = 0;
	for (corner_direction c=0; c<4; c++ ) {
	    d=dist( corner(c), pt );
	    if (d < mind) 
		{ minc=c; mind=d; }
	}
	for (neighbor_direction n=0; n<4; n++ ) 
	    if (side(n) != 0) 
	    {
	 	d=dist( side(n), pt );
		if (d < mind) 
		    { side_closest = 1; minn=n; mind=d; }
	    }

	if (side_closest) { //not used because of special balance
	    cout << " side is a centroid ! "; //9
	    geosnap( &sides[minn], ptgeo ); 
            side(minn)->changeallptrs(&centroid);
	    centroid_side = 1;
	    centroid_index = minn;
	}
	else {

	    //added march.17.93
	    //look for this corner being taken as a vbox point of
	    //some cross point.  If found, snap that vertex, too.
 	    for (crosspt * cr = crosses; cr; cr=cr->next) 
		if (cr->vbox == corner(minc)) {
		   if (cr->vboxsub==1)
                       corner(minc)->changeallptrs(&cr->p1);
		   else
                       corner(minc)->changeallptrs(&cr->p2);
		}

	    //snap the box corner to the Pvertex
	    geosnap( &corners[ minc ], ptgeo );
	    corner( minc )->changeallptrs(&centroid);
	    centroid_side = 0;
	    centroid_index = minc;

	}
    }
    warpcrosspoints(close); //warp to edges
}

int ptquad::testboxes()
{
  int retval = 0;
  if (is_split())
	for (corner_direction c=0; c<4; c++)
	    retval = retval || ((ptquad*) child(c))->testboxes();
  else {
    for (ptquad * dp = (ptquad*) dup; dp !=0; dp= (ptquad*) dp->dup)
	if (dp->is_split()) {
		cout << "err ";
		retval = 1;
	}
  }
  return retval;
}

void ptquad::testup()
{ 
    cout << state;
    if (is_split())
	for (corner_direction c=0; c<4; c++) {
	    cout << ".";
	    ((ptquad*) child(c))->testup();
	}
    triquad * dupt = dup;
    for (ptquad * dp = (ptquad*) dup; dp != 0; dp = (ptquad*) dp->dup) {
	cout << "^";
	dp->testup();
    }
}

void ptquad::testme()
{
  cout << "-----------------------" << this << "---------------------------\n";
  cout << bigcorner()->x << " " <<  bigcorner()->y << " : " <<
	smallcorner()->x << " " << smallcorner()->y << "\n";
  for (neighbor_direction n=0; n<4; n++)
	if (side(n)) 
	  cout << "side n= " << n << "  " << 
	   	side(n)->x << "," << side(n)->y << "\n";
  for (points * elist = containse; elist != 0; elist=elist->rest() ) {
	geo * e = elist->first();
	cout << "edge " << e->endpt1()->x << "," << e->endpt1()->y << " to " << e->endpt2()->x << "," << e->endpt2()->y << "\n";
  }
  for (points * plist = containsp; plist != 0; plist=plist->rest() ) {
	cout << "point " << ((point*) plist->first()->r)->x << ","
	     << ((point*) plist->first()->r)->y << "\n";

  }
}

static ptquad* spq = 0; //special quad to debug
void ptquad::settest()
{
  spq = this;
}
  
void dumptest(int ctrl) 
{
if (!spq) { cout <<  " spq undefined "; return; }
cout << "------------------------- \n" << ctrl << 
" spq "  << spq->bigcorner()->x <<
"," << spq->bigcorner()->y << " : " << spq->smallcorner()->x << "," <<
spq->smallcorner()->y << "\n";
  
   for (neighbor_direction n=0; n<4; n++) {
       cout << n << " side " << spq->side(n);
       if (spq->side(n)) cout << " who " << spq->side(n)->who << " coor " <<
       spq->side(n)->x << "," << spq->side(n)->y;
       cout << "\n";
   }
}

void ptquad::cond_dump(int ctrl)
{
  if (this==spq) dumptest(ctrl);
}

