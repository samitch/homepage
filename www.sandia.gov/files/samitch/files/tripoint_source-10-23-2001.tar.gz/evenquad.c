// evenquad - quadtree with balancing between adjacent squares
// whenever one square is split, its parents neighbors must be split
//
// Scott Mitchell, Xerox PARC, 1991
// David Eppstein, Xerox PARC, 27 Feb 1990

#include "evenquad.h"


//SAM split neighboring boxes, and neighboring box duplicates,
// to create same-sized neighbors of this 
// where this is already split
// where there is only one level difference now
void evenquad::balance() {
  //orthogonally adjacent to someone at most twice as big
  // we must look at select neighbors  of father.
  //if this is a duplicate, note that it either has its own father,
  //or its father is the same as the origonals father

//9 return;

  if (father() != 0) {
    evenquad * fn;
    neighbor_direction d;
    d = cl_neighbor( which_child() );
    fn = (evenquad*) father()->neighbor(d);
    if (fn != 0) 
	dupbalance(fn,d);
    d = ccl_neighbor( which_child() );
    fn = (evenquad*) father()->neighbor(d);
    if (fn != 0) 
	dupbalance(fn,d);
  }
}

//SAM for each child of this, if a neighbor is split then join it
void evenquad::join_sub() {
    if (father() != 0)
	for (corner_direction c = 0; c<4; c++)
	    for (neighbor_direction d = 0; d<4; d++)
		if (child(c)->neighbor(d) != 0 &&
		    child(c)->neighbor(d)->is_split())
		    child(c)->neighbor(d)->join();
}
