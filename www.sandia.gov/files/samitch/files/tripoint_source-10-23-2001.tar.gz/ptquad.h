// ptquad -- quadtree warped to fit a set of points
// Scott Mitchell, Xerox PARC, 1991
// David Eppstein, Xerox PARC, 28 Feb 1990

#ifndef PTQUAD_H
#define PTQUAD_H

#include "triquad.h"
#include "point.h"

class ptquad : public triquad {
private:
    points * containsp;
    points * containse;
    //border stuff now taken care of by more general 
    // quadtree::drop_neighbor() and quadtree::isdrop_neighbor()

    //for warp
    crosspt * allocate_cross( snap_point * c1, snap_point * c2, 
	snap_point* vboxin, int vboxsubin, geo * e )
    {
	//check if crosspt already allocated
	//relies on vboxin not being a p1, p2 of some cross
	crosspt * found = crosses->findcrosspt( e, c1, c2 );
	if (found) return found;  

	//allocate a new one
	crosses = new crosspt( new snap_point(), e, c1, c2, 
		crosses, vboxin, vboxsubin);
	crosses->me->addbackptr( &crosses->me );
	crosses->p1->addbackptr( &crosses->p1 );
	crosses->p2->addbackptr( &crosses->p2 );
	if (crosses->vbox!=0) crosses->vbox->addbackptr( &crosses->vbox );
	return crosses;
    }

    ptquad * neighbor( neighbor_direction n) { return (ptquad*) quadtree::neighbor(n); }
    //used by recurse
    void allcones( points* ptlist, int * crowded, double hfactor );
    ptquad * get_ext_neighbor(  int n );
    void check_box( points * flist, points ** leaf, int * crowded,
	 double hfactor, ptquad * fbox );
    void check_ext_box( points ** leaf, int * crowded,
	 double hfactor );
    double conedist( geo* a, geo* f);
    void buildleafcan( points * apexlist, points ** leaf, int * crowded );
    void recurse(int dup_only = 0);  //main work for a particular box
    void recur(); //calls recurse
 
    // for dup
    void add_leaf_sup( ptquad * pq, geo * apex ); 
    void add_sup( geo * apex );
    ptquad * dupbox(geo * leaf);
    void duplicate( points ** leaf, int crowded );
    ptquad* find_prev( ptquad * chink ); // find previous dup to chink
    void splice_dup( ptquad * condemmed );

    // CONSTRUCTOR - private, see also below
    ptquad() : triquad() { containsp = 0; containse = 0; dup=0;
	crosses=0; }

    //EPP ptquad * force_neighbor(neighbor_direction);
    //EPP int snap_ok_sub(int, int, corner_direction);  warp on a seperate
    //EPP int snap_ok(corner_direction);                 pass now.

    static ptquad* top; static ptquad* last;
    ptquad * pop() {
	ptquad * oldtop = top; 
	top = (ptquad*) top->next; oldtop->next = 0;
	return top;
    }
    void stack() {
	if (last==0) 
	    top=this;
	else 
	    last->next = this;
	last=this;
	last->next = 0;
    }

    friend int checkcross(point &p1, point &p2, geo * e, int d, 
		       point &b1, point &b2, point& bc, int cwb1, int cwb2,
		       point &first_cross, geo*& first, int &first_cross_d);


 public:
    ~ptquad() { delete containsp; delete containse; }
    quadtree * new_quad() { return new ptquad; }
    // CONSTRUCTOR - public
    ptquad(points * ptlist, points * elist) : triquad(ptlist) {
	containsp = ptlist;
	containse = elist;
	dup = 0;
	crosses = 0;
	recur();  //do splitting
    }
    void split_sub(int unmarked_only); //virtual

    int non_empty() { return (containse != 0 || containsp != 0); }

    double box_dist( geo* f );

    friend int adjacent( neighbor_direction d, quadtree * qt1, quadtree * qt2 );
    friend int true_adjacent(corner_direction c, neighbor_direction n,
 quadtree* qt1in, quadtree* qt2in, int qt2small);
//returns correct adjacency after boxes have been duplicated

    friend int balance_adjacent( neighbor_direction d, quadtree* qt1in, quadtree* qt2in); //for balance

    virtual void swap(quadtree * dp) { 
	points * te = containse; 
	containse = ((ptquad*) dp)->containse;
	((ptquad*) dp)->containse = te;

	points * tp = containsp; 
	containsp = ((ptquad*) dp)->containsp;
	((ptquad*) dp)->containsp = tp;

	triquad::swap(dp); 
    }

    geo * lf_apex();

    //return all crosses of edge p1, p2 in c1 and c2
    void get_all_crosses(crosspt** c1, crosspt** c2, snap_point * p1, snap_point * p2);

    //virtual triquad
    void share_edge_crosses(snap_point* c1, snap_point* c2, snap_point* vboxin,
	int vboxsubin, triquad * nbt); 
    void warpbox();
    void set_edge_crosses();
    void draw_crosses(segdrawer * s);
    void draw_diags(segdrawer * s);
    void chose_centroid();
    void chose_centroid_loc( snap_point * boxpt, int * numpts, 
	geo ** e, int * vol ); //not virtual
    int regularize( corner_direction c, int & colinear_point ); //not virtual
    void chose_centroid_finalize( int volume, int numpts, int colinear_point );
    int no_volume();

    int has_Pvertex();

    void draw_diags_loc( snap_point * p, segdrawer * s);
    void find_both_e_crosses( snap_point** c1, snap_point** c2, geo* e );
    void set_edge_crosses_loc( snap_point *p1, snap_point *p2, geo * e) {
        if (ecap(*p1,*p2,*e->endpt1(),*e->endpt2()))
	    allocate_cross( p1, p2, 0, 0, e);
    }

    void warpcrosspoints( coor close );
    void warpcrosspoints_loc(snap_point** p, coor close);

    //-------- debugging ----------
    int testboxes();
    void testme(); //virtual triquad.h
    void testup(); //virtual triquad.h
    void test_cross(); 


    void set_top();

   void settest();
   friend void dumptest(int ctrl);
   void cond_dump(int ctrl);


};

//quadtree really *should* be ptquad
int adjacent( neighbor_direction d, quadtree * qt1, quadtree * qt2 );


#endif
