// evenquad - quadtree with balancing between adjacent squares
// whenever one square is split, its parents neighbors must be split
//
// Scott Mitchell, Xerox PARC, 1991
// David Eppstein, Xerox PARC, 27 Feb 1990
// the fact that dup is defined in triquad prohibits evenquad from truly
// carrying out its tasks, so instead triquad does most of the work.
// dup should really be part of quad - change later

#ifndef EVENQUAD_H
#define EVENQUAD_H

#include "quad.h"

//include "point.h" forward declaration
class points;

class evenquad : public quadtree {
 // SAM - evenquad() formerly private by default
 public:
    // CONSTRUCTORS
    evenquad() { ; }
    evenquad(points * ptlist) : quadtree( ptlist ) { ; }

    void balance();
    virtual void dupbalance(evenquad*, neighbor_direction ) = 0; //triquad.c
    void join_sub();
    virtual void swap(quadtree * dp) { quadtree::swap( dp ); }
};

#endif
