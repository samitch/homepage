// segdraw - support for enumeration/output of line segments
// Scott Mitchell, Xerox PARC, 1991

#ifndef SEGDRAW_H
#define SEGDRAW_H

#include "point.h"
#include "out.h"
#include <string.h>
#include <fstream.h>
#include <iostream.h>

class segdrawer {
 public:
    virtual void operator()(out_point *, out_point *) { ; }
};  


// translate_segdrawer constructor is called with a pointer
// to a segdrawer (which, in the current implementation,
// is an io_segdrawer).  Thus, the virtual functions () and
// outputlabel(a) are called for the correct object.

/*translate x,y coordinates before output*/

class translate_segdrawer : public segdrawer {
private:
    point trans;
    ostream * xy;
    ostream * incidence;

    filebuf fxy, finc; /* a member, since need the buffer around */


    void out_incidence ( tripoint_idtype a, tripoint_idtype b) {
	(*incidence) << a << " " << b << "\n";
    }

    void outputlabel( out_point a ) {
	(*xy) << a.x << " " << a.y << "\n";
    }

    void out_label( out_point* a ); /*in segdraw.c*/
	
 public:
    translate_segdrawer(point p, char * fname) {
	trans = p; 
	char * fnamebuf;
	fnamebuf = new char[strlen(fname)+3];

	// start xy point data stream
	strcpy( fnamebuf, fname );
	strcat( fnamebuf, ".p" );
	fxy.open( fnamebuf, ios::out); /* I "should" do error checking */
	xy = new ostream(&fxy);

	// start incidence edge data stream
	strcpy( fnamebuf, fname );
	strcat( fnamebuf, ".e" );
	finc.open( fnamebuf, ios::out); /* I "should" do error checking */
        incidence = new ostream(&finc);
    }

    void operator()(out_point* a, out_point* b) { 
    //handles degenerate edges by not outputting them
    	out_label(a);
        out_label(b);
	if (a != b) out_incidence( a->label(), b->label() ); 
    }

};

#endif

