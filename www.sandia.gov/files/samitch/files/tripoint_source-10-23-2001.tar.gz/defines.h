// defines.h
// Scott Mitchell, Xerox PARC, 1991 

#ifndef DEFINES_H
#define DEFINES_H

#define nl << "\n"
#define sp << "  "

#endif
