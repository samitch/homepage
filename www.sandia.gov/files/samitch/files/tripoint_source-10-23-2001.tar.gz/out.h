// out.h -- points that are part of output structure
// Scott Mitchell, Xerox PARC, 1991 

#ifndef OUT_H
#define OUT_H

#include "point.h"

typedef long tripoint_idtype;

class out_point : public point {
private:
    tripoint_idtype id;
    static tripoint_idtype maxid; 

public:
    // CONSTRUCTORS
    out_point(coor a, coor b) : point(a,b) { id=0; }
    out_point(const point &p) : point(p) { id=0; } 
    out_point() : point() { id=0; }

    void label_it() { if (id==0) id = ++maxid; }
    tripoint_idtype label() { return id; } 
    void dup(out_point* that) {
	*this=*that; /*duplicate point class info*/
	this->id=that->label();
    }
};

#endif
