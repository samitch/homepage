// out.h -- points that are part of output structure
//
// Scott Mitchell, Xerox PARC, 1991

#include "out.h"

tripoint_idtype out_point::maxid = 0;
