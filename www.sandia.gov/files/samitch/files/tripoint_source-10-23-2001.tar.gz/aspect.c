// aspect -- compute a measure of the sharpness of a triangle
// Scott Mitchell, Xerox PARC, 1991
// David Eppstein, Xerox PARC, 28 Feb 1990
//
// Larger measures imply sharper triangles.
// The measure currently computed is: hypotenuse/altitude

#include "aspect.h"
#include "point.h"


/* global constant, this aspect ratio treated as inf*/
double maxaspect = 1000.0; 

/* SAM "coor" formerly "long" */
static coor max3(coor a, coor b, coor c)
{
    coor x = (a > b ? a : b);
    return (x > c ? x : c);
}

double aspect(point a, point b, point c)
{
    point side1 = b-a;
    point side2 = c-a;
    point side3 = c-b;

    point perp(side1.y, - side1.x);
    /* SAM "coor" formerly "long" */
    coor area = side2 * perp;	 // twice area of triangle or its negative
                                 // vector dot product - overloaded *
    if (area < 0) area = - area; // make positive

    /* SAM "coor" formerly "long" */
    coor hypsquare = max3(side1 * side1, side2 * side2, side3 * side3);

    /* SAM prevent overflow/division by zero */
    return area * maxaspect < hypsquare ? maxaspect : hypsquare / area;
}
