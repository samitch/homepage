// snap.h -- points that can be snapped to a new location
// Scott Mitchell, Xerox PARC, 1991
// David Eppstein, Xerox PARC, 1 Mar 1990

#ifndef SNAP_H
#define SNAP_H

#include <iostream.h>
#include "point.h"
#include "out.h"

//SAM  grid points that can be snapped to a new location
//     additional members for state

class backlink {
  friend class snap_point;
  snap_point ** backptr;
  backlink * next;
  //CONSTRUCTORS
  backlink() { backptr = 0; next = 0; }
  backlink( backlink * first, snap_point ** b ) { 
	backptr = b; next = first; }
};

class snap_point : public out_point {
    enum { snap_loose, snap_snapped, snap_moved } state;
    snap_point * stack;

    backlink * backptrs;

 public:
    geo * who;

    // CONSTRUCTORS
    /* SAM "coor" formerly "long" */
    snap_point(coor a, coor b) : out_point(a,b) { 
	state = snap_loose; stack = 0; backptrs = 0; who = 0; }

    snap_point(point p) : out_point(p) { 
	state = snap_loose; stack = 0; backptrs = 0; who = 0; }

    snap_point() : out_point() {
	state = snap_loose; stack = 0; backptrs = 0; who = 0; }


    //SAM add a copy of a snap point to this->stack
    void push(snap_point p)	// temporarily look like argument
    {
	snap_point * copy = new snap_point(x,y);
	copy->state = state;
	copy->stack = stack;
	state = p.state;
	x = p.x;
	y = p.y;
	stack = copy;
    }

    //SAM this->stack becomes this, original this deleted
    void pop()
    {
	if (pushed()) { 
	  x = stack->x;
	  y = stack->y;
	  state = stack->state;
	  snap_point * temp = stack;
	  stack = temp->stack;
	  delete temp;
	}
    }

    //SAM is stack non-empty?
    int pushed() { return (stack != 0); }

    //SAM set state to snapped
    void snap() { if (state == snap_loose) { state = snap_snapped; who=0; 
	cout << "snapping to nothing"; } }

    //SAM move coordinates of this to argument, set state to moved
    void snap(point p) { x = p.x; y = p.y; state = snap_moved; }

    //SAM is state not loose?
    int snapped() { return (state != snap_loose); }

    //SAM is state moved?
    int moved() { return (state == snap_moved); }


    void addbackptr(snap_point ** me) {
	backptrs = new backlink( backptrs, me ); }

    void changeallptrs( snap_point ** source ); //this is destination
  private:
    void deletebackptr()
    {
    	backlink * condemmed = this->backptrs;
    	this->backptrs = this->backptrs->next;
    	condemmed->next = 0;
    	delete condemmed;
    }


};

#endif
