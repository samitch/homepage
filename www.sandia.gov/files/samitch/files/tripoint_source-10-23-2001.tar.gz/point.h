// planar points and vector operations on them
// Scott Mitchell, Xerox PARC, 1991
// David Eppstein, Xerox PARC, 27 Feb 1990

#ifndef POINT_H
#define POINT_H

#include "compass.h"
#include <math.h>


// DATA TYPE FOR COORDINATES
typedef double coor;

//forward declarations
class triquad;
class geo;
class point;
class points;
class snap_point;


//base class for representation of points, edges, facets, . . .
class rep {
  public:
    // does this intersect with that? 
    virtual int cap( geo* thisg, geo* thatg ) = 0; //dim of this/that unkown

    virtual int pcap( geo * thatg, geo * thisg ) = 0; //thatg is a point
    virtual int ecap( geo * thatg, geo * thisg ) = 0; //thatg is an edge

    // used by inbox(geo * g) to determine
    // boolean, is this wholy inside tq, knowing that we don't intersect
    virtual point * inbox_testpoint(geo * thisg) = 0;

    // used by ptquad::conedist
    virtual int apex_points( geo* , point* , point* , point* , point*  ) = 0; 
    virtual double f_to_pt_dist( geo* , point*  ) = 0;

    //bare bones visiblity test, does an infinite cone contain point p
    virtual int conesee(point *, geo * ) = 0;

    // can cone with apex this=looker see {cone with} apex target
    friend int conevisible_block( geo* looker, geo* target,
	point* target_box_big, point* target_box_small );
    friend int conevisible_noblock( geo* looker, geo* target,
		point* target_box_big, point* target_box_small  ); 

    // add apex
    friend void add_f( geo * , points ** containsp, points ** containse ); 
    virtual double box_dist_loc( geo* f, point* big, point* lit ) = 0;

    virtual int conevisible_loc( geo* looker, geo* target,
	point* target_box_big, point* target_box_small ) = 0;
    virtual int conevisible_block_loc( geo* , geo* ,
	point* , point*  ) = 0;

  protected:
    virtual void add_f_loc( geo * /*f*/, points ** /*containsp*/, 
	points ** /*containse*/ ) {;}


};

class point:public rep {
 public:
    /* SAM "coor" formerly  "long" */
    coor x, y;
    point() { x=-99; y=-99; }
    point(coor ix, coor iy) { x = ix; y = iy; }
    point(const point & p) { x = p.x; y = p.y; }

    // comparison
    int operator==(const point& that) {
	return (this->x == that.x && this->y == that.y);
    }
    int operator!=(const point& that) {
	return (this->x != that.x || this->y != that.y);
    }

    // vector sum
    point operator+(const point& that) {
	return point(this->x + that.x, this->y + that.y);
    }
    void operator+=(const point& that) {
        this->x += that.x; this->y += that.y; 
    }
    point operator-() {
	return point(- this->x, - this->y);
    }
    point operator-(const point& that) {
	return point(this->x - that.x, this->y - that.y);
    }
    void operator-=(const point& that) {
        this->x -= that.x; this->y -= that.y; 
    }

    // dot product
    coor operator*(const point& that) {
	return (coor) this->x * (coor) that.x +
	       (coor) this->y * (coor) that.y;
    }  

    // scalar product
    point operator*(coor a) {
	point z( a * this->x, a * this->y );
	return z;
    }
    point operator*(int a) {
	point z( a * this->x, a * this->y );
	return z;
    }
    point operator/(int a) {
	point z( this->x / a, this->y /a );
	return z;
    }

    virtual int cap( geo * thisg, geo * thatg );

    virtual int pcap( geo * thatg, geo * thisg ); //thatg is a point
    virtual int ecap( geo * thatg, geo * thisg ); //thatg is an edge

    virtual point * inbox_testpoint( geo * thisg );
    virtual int apex_points( geo* , point* , point* , point* p1, point * p2 ) 
	{ *p1 = *this; *p2 = *this; return 0; }
    virtual double f_to_pt_dist( geo* thisg, point * pt );

    //bare bones visiblity test, does an infinite cone contain point p
    virtual int conesee(point * p, geo * thisg );

    friend int conevisible_block( geo* looker, geo* target,
	point* target_box_big, point* target_box_small );
    friend int conevisible_noblock( geo* looker, geo* target,
		point* target_box_big, point* target_box_small  ); 

    friend void add_f( geo * f, points** containsp, points** containse ); 
    virtual double box_dist_loc( geo* f, point* big, point* lit );

    virtual int conevisible_loc( geo* looker, geo* target,
	point* target_box_big, point* target_box_small );
    virtual int conevisible_block_loc( geo* looker, geo* target,
	point* target_box_big, point* target_box_small );

 protected:
    virtual void add_f_loc( geo * f, points** containsp, 
	points** containse ); 
 
 public:
    friend double dist( point * pt1, point * pt2 );

};

int ecap( point & c1, point & c2, point & e1, point & e2 );
// do two edges intersect, including just touching at a vertex?
// first edge is c1 to c2, second edge is e1 to e2


static inline point midpoint(point & a, point & b) {
    return point((a.x + b.x) / 2, (a.y + b.y)/2);
};

class edge : public rep {
    //no data, just stuff in geo
 public:
    //CONSTRUCTOR
    edge() { ; }

    // lots of functions for endpoint, intersection, etc
    // not part of the class, and not friend at this point,either
    // see above functions

    virtual int cap( geo * thisg, geo * thatg );
    virtual int pcap( geo * thatg, geo * thisg ); //thatg is a point
    virtual int ecap( geo * thatg, geo * thisg ); //thatg is an edge

    virtual point * inbox_testpoint(geo * thisg);
    virtual int apex_points( geo* thisg, point* big, point* lit,
	point* p1, point* p2 );
    virtual double f_to_pt_dist( geo* thisg, point * pt );

    //bare bones visiblity test, does an infinite cone contain point p
    virtual int conesee(point * p, geo * thisg );

    friend int conevisible_block( geo* looker, geo* target,
	point* target_box_big, point* target_box_small );
    friend int conevisible_noblock( geo* looker, geo* target,
	point* target_box_big, point* target_box_small );
    friend void add_f( geo * f, points** containsp, points** containse ); 
    virtual double box_dist_loc( geo* f, point* big, point* lit );

    //considers if endpoints can see as well
    virtual int conevisible_loc( geo* looker, geo* target,
	point* target_box_big, point* target_box_small );
    virtual int conevisible_block_loc( geo* looker, geo* target,
	point* target_box_big, point* target_box_small );

protected:
    virtual void add_f_loc( geo * f, points** containsp, 
	points** containse ); 

};


//----------------
// data structure for lists of points

// linked list of points, for containment by boxes.
// also, list of edges is also of class "points"
class points {
 private:
    points * next;
    // take a link out of the list from the middle
    friend void splice( points ** head, points * prev, points ** current );
 public:
    /* static public members - like global vars - for readdata */
    // shared by all points class objects
    static point minpt, MAXpt;

    geo * g;
    geo * first() { return g; }

    //CONSTRUCTOR
    points(geo * ip, points * in = 0) { next=in; g=ip; }
    // create a new points, put on list after this but before this->next
    points* addafter( geo * ip ) { 
	this->next = new points(ip,this->next);
	return this->next;
    }

    //DESTRUCOR
    //base class list destructor automatically called
    ~points() { if (next != 0) delete next; }

    points * rest() { return next; }
    points * pop() {
	points * retval = next;
	next = 0;
	delete this;
	return retval;
    }

    // return lattice of points p and edges e
    friend void readdata(char * fname, points ** p, points ** e);

};

//for saving a little space
struct marks { unsigned a:1; unsigned b:1; unsigned c:1; };

//clockwise perp vector
inline point perp(point& p1, point& p2) {
  return point( p2.y - p1.y, p1.x - p2.x); }
  

// a geometric object
class geo {
public:
  rep * r; //either an edge or a point for now
  points * subfaces, * superfaces;
  snap_point* whosnapped; //for ptgeo only

private:
  marks mark;

public:
  //CONSTRUCTORS
  //note:mark.a .b not set
  geo( rep * ir ) { r=ir; subfaces=0; superfaces=0; mark.c =0; whosnapped=0; } 
  geo( rep * ir, geo * sub1, geo * sub2 ) { 
	r=ir; subfaces=0; superfaces=0; mark.c =0; whosnapped=0; 
	contains(sub1); contains(sub2);
  } 

  //dangerous if not edge
  point * endpt1() { return (point*) subfaces->first()->r; }
  point * endpt2() { return (point*) subfaces->rest()->first()->r; }
  // perpendicular to edge vector pointing to interior sided of this
  // left side of edge from endpt1 to endpt2 in ordinary coordinate system
  // that is, right side in 0 -----> +x
  //			    |
  //			    |	coordinate system
  // 			    v
  //			    +y
  point perp() { 
	point * e1=endpt1();
        point * e2=endpt2(); 
 	return point( e1->y - e2->y, e2->x - e1->x); }

  geo * chum( rep * pt ) { //returns chum edge to this edge, sharing pt
	geo * sub = (subfaces->first()->r == pt) ?
		subfaces->first() : subfaces->rest()->first();
	return (sub->superfaces->first() != this) ?
		sub->superfaces->first() :
		sub->superfaces->rest()->first();
  }

  //assume this->r is a point, see point.c for details
  // pt1, pt2 set so that cone is pt2-this-pt1
  int reflex( point** pt1, point** pt2);
  int reflex() {
    point* jnk1, * jnk2;
    return reflex(&jnk1, &jnk2);
  }


  // set this to contain argument
  void contains( geo * sub ) {  
	subfaces = new points(sub,subfaces);  //add sub to subfaces
        // add this to sub's superfaces
	sub->superfaces = new points(this,sub->superfaces);  
   }
    
  // set this to be contained in argument
  void contained( geo * sup ) {
	superfaces = new points(sup,superfaces); //add sup to superfaces
	// add this to sup's subfaces
	sup->subfaces = new points(this,sup->subfaces);
  }

  point * inbox_testpoint() { return this->r->inbox_testpoint( this ); }
  double box_dist( point* big, point* lit ) {
	return this->r->box_dist_loc( this, big, lit ); }


  void readdata(char * fname, points ** p, points ** e); //in points.c

  // used by apex_common, mark.c non-strict subfaces
  void mark_sub_c(int i=0);
  geo* find_sub_c();
  friend geo * apex_common ( geo * g1, geo * g2 );

public: void markait(int val = 1) { mark.a=val; }
  	void markbit(int val = 1) { mark.b=val; }
private:void markcit(int val = 1) { mark.c=val; } 
public:	int marka() { return mark.a; }
  	int markb() { return mark.b; }
private:int markc() { return mark.c; }

public:
  int is_sub( geo * sup );  //is this a subface of sup?
};

void test_stuff();

static inline double norm( point v ) {
    return sqrt( v.x*v.x + v.y*v.y );
}

static inline double normsqr( point v ) {
    return v*v; }

// sgn of Right Hand Rule for points c1, c2, c3
// colinearity returns zero
int cw( point& c1, point& c2, point& e1 );

// is x3 (non-strictly) between x1 and x2, knowing that x1,x2,x3 are colinear and x1<x2
static inline int between( coor& x1, coor& x2, coor& x3 )
{ return ((x1 <= x3) && (x3 <= x2)); }

// is x3 (non-strictly) between x1 and x2, not knowing relation between x1 and x2
static inline int between_noorder(coor& x1, coor& x2, coor& x3 )
{ return (x3 >= x1) ? (x3 <= x2) : (x3 >= x2); }

static inline int pointbetween(point p1, point p2, point q) {
  return (fabs(p1.y-p2.y) > fabs(p1.x-p2.x))  ?
     between_noorder(p1.y,p2.y,q.y) 
     :
     between_noorder(p1.x,p2.x,q.x);
}

int left( point* c1, point * c2, point * p1, point * p2);

point crossingpt(geo * e1, geo * e2); //return coor of where they intersect
point crossingpt( point p1, point p12, point p2, point p22 );
//two lines, p1 to p12, and p2 to p22.
//calculate the point at which they cross, (assumes that they do, see ecap)

point closestpt( point p1, point p2, point c, int & which );

int inbox( geo * g, point* big, point* lit);
int put_edge_inbox( geo * g, point* big,  point* lit, points * touch_verts );
//should an edge be put in contains?

//true if p1 is further in direction d than p2 is
static inline int bigger(point &p1, point&p2, neighbor_direction & d) {
  switch (d) {
	case north : return (p1.y < p2.y);
	case south : return (p1.y > p2.y);
	case east :  return (p1.x > p2.x);
	case west :  return (p1.x < p2.x);
  }
  return 0;
}

#endif

