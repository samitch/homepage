function [] = plotalmond(specifier,p2,p1,color);
%  function [] = plotalmond(specifier,p2,p1,color);
%  draw almond arcs, input may be many almonds in column order
%  default color is 'b'

if nargin<4
  color = 'b';
end

v1 = p1(specifier(:,3))-specifier(:,1);
v2 = p2(specifier(:,3))-specifier(:,1);

th1=atan2(imag(v1),real(v1));
th2=atan2(imag(v2),real(v2));


I = find(th1>th2);
th1(I)=th1(I)-2*pi;

stepsize=(th2-th1)/20;
for k=1:size(th1,1) %for all almonds
  steps=[th1(k):stepsize(k):th2(k)];
  plot( specifier(k,1)+specifier(k,2)*[cos(steps) + i*sin(steps)], color );
end

  


