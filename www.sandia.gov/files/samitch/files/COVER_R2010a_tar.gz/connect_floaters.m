function [centers,radii,plaps1,plaps2,newcells,is_almond]=connect_floaters(c,r, almonds, almondsspecifier, cells); 



%determine floaters
% look at leftmost point
newcells=cells;

for q=1:size(cells,2)
  [jnk jnk cmp] = find(cells(:,q));
  cmpwrap = [cmp; cmp(1)];

  %construct polygonal approximation
  b=zeros(size(cmp,1),1);
  for j=1:size(cmp,1)
    %if non-consecutive in a bdycmp, add  plaps 1 or 2 arbitrarily
    %else consecutive in a bdycmp, add common vertex
    if plaps1(cmpwrap(j),cmpwrap(j+1)) ~= 0
      b(j) = plaps1(cmpwrap(j),cmpwrap(j+1));
    else
      b(j) = centers(cmpwrap(j)); %ok in wrap case
    end
  end
  [x j]=max(b);
  prv=mod_nz(j-1,size(b,1));
  nxt=mod_nz(j+1,size(b,1));
  %an outward vector from x
  n1 = i*(b(j)-b(prv)); n1=n1/norm(n1);
  n2 = i*(b(nxt)-b(j)); n2=n2/norm(n2);
  if real(n1+n2)<0 %its a disconnected hole, called a floater
    %do the connections
     
  end
end %for q


