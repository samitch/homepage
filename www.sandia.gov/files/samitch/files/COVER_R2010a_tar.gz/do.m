%
addpath('..');

% do script
echo on
[c,r,l,bdycmps]=get2d;
[almonds,almondsspecifier]=compute_almonds(c,r,bdycmps);
[plaps1,plaps2,acells]=almond_cells(c,r, almonds, almondsspecifier, bdycmps); 

%unknown how to handle "pointy" almond overlap points (input verticies)
%  so do the way we say in the paper and do a polygonal approximation first.

[pr, pc, pl, almond_associate, pcells, floaters, is_floater ] = build_polygons(c,r, plaps1, plaps2, acells, almonds, almondsspecifier);

[esav,psav,pdefsav] = triangulate_poly(pc,pr,pl,pcells, is_floater, floaters);

[e2,p2]=triang_almonds(esav,psav,pdefsav, c,r, pc, pr, almond_associate, almonds, almondsspecifier,bdycmps);

shortzoom
%return

E=list_to_matrix(e2,p2);
P=[real(p2) imag(p2)];
[t,bdy]=findtri(E,P);
%% checktri(E, P, t, bdy); %% waste of time for demo

%look at quality
%true lower bound actually about 10% bigger, see multiplicative factor 
% times d in compute_almonds.m, also this assumes bound is more than 2pi/3
disp(sprintf('Theoretical local maximum angle lower bound is about pi(%d).', 2*(pi-max(almondsspecifier(:,5)))/pi  ));
a = cos_of_angles(t,p2);

%look at cardinality
disp(sprintf('almond/input cardinality < 1+%f.',size(pr,1)/size(c,1)));
%one from points at center of almonds

disp(sprintf('final output/input cardinality < %f.',size(p2,1)/size(c,1)));



echo off
%is it realy a covering triangulation?
triangholes=0;
for j=1:size(bdycmps,2)
  cmp = find(bdycmps(:,j));
  if size(cmp,1)==3
    triangholes = triangholes+1;
  end
end;
if (size(find(bdy),1) + 3*triangholes) == size(c,1)
  disp('Its a covering triangulation.');
elseif size(find(bdy),1) > size(c,1)
  disp('Boundary Steiner points were added.');
else
  disp('Error, fewer triangles on the boundary than edges!?');
end

  
  
%shortzoom;

echo on
%  clf; plotcircle2(c,r,l,'g'); plotalmond(almondsspecifier,c,r);
%   plotcircle2(pc,pr,pl,'m');
%for a nice final view, try the following line
  clf; axis('equal'); plottri(e2,p2,'b'); plottri(esav,psav,'r'); 
