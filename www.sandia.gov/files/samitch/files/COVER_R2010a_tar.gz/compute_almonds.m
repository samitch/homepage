function [almonds,almondsspecifier]=compute_almonds(p2,p1,bdycmps);
%  function [almonds,almondsspecifier]=compute_almonds(p2,p1,bdycmps);
%    Compute the almonds for the given input edges
%    bdycmps colums are consecutive vertex indicies in the connected
%    components of the boundary.
%    Vertices have p1 to p2 ordering, with outward normal by right hand rule
%    thus passing "centers,radii" = "p2,p1" is the proper call

pi3factor = 2*sqrt(3);

almonds = sparse(size(bdycmps,1),size(bdycmps,2)); %all zeros
almondspecifier=sparse(size(almonds,1)*size(almonds,2),1);
maxindex = 0;

for j=1:size(bdycmps,2) %columns
  [jnk,jnk,cmp]=find(bdycmps(:,j));
  for k=1:size(cmp,1)
    edge = cmp(k);
    df=p2(edge)-p1(edge);
    e_len = norm(df);
    n=i*df;n=n/e_len; %outward normal
    mid_point = (p1(edge)+p2(edge))/2;
    dmax = 0;
    for p=p2.'
      if cwi(p1(edge),p2(edge),p)==-1  %on right side of edge
        %center of the almond c is equadistant from all three points
        mid_point2 = (p1(edge)+p)/2;
        n2 = i*(p1(edge)-p); n2=n2/norm(n2);
        c=lineintersect([mid_point;mid_point2],[n,n2]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%	r = norm(c-p1(edge));
%	plot(p,'m*');
%	plot(mid_point2,'rx');
%	plot(mid_point,'ro');
%	plotcircle(c,r,'m');
%	shortzoom;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
        d=point_to_line_dist(c,n,p1(edge)); %positive if on outside of edge
        if (d>dmax)
  	  dmax=d;
        end
      end %on right side of edge
    end %for p
    %shrink to avoid exact hits on vertices, and overlap

    pi3almondd = e_len/pi3factor;
    if dmax<pi3almondd,  %we have a too big almond
      dmax=pi3almondd;
    end
    dmax=dmax*1.1;  %change to smaller value as desired
    c = mid_point + n*dmax;
    r = norm(c-p1(edge));  

    maxindex=maxindex+1;  
    almonds(k,j)=maxindex;

    %compute angle that the almond arc subtends at the almond center
    e_len = norm(p1(edge)-p2(edge));
    atheta = 2* atan( e_len/(2*dmax) ); % *ra = almond arc length

    almondsspecifier(maxindex,:) = [c r edge dmax atheta];
				%   1 2  3    4     5
%%%%%%%%%
%   plotalmond(almondsspecifier(maxindex,:),p2(edge),p1(edge),'b');
%   shortzoom;
%   drawnow
%%%%%%%%%

  end %for k
end %for j
    
  
%%%%%%%%%
    plotalmond(almondsspecifier,p2,p1,'c');
    shortzoom;
%    drawnow
%%%%%%%%%
