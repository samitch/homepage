function [pr, pc, pl, almond_associate, pcells, floaters, is_floater ] = build_polygons(c, r, plaps1, plaps2, acells, almonds, almondsspecifier);

pcells = [];
pc = [];
pr = [];
almond_associate = [];
  
for q=1:size(acells,2)
  [jnk jnk cmp] = find(acells(:,q));
  cmpwrap = [cmp; cmp(1)];

  %construct polygonal approximation
  b=zeros(size(cmp,1),1);
  for j=1:size(cmp,1)
    %if non-consecutive in a bdycmp, add  plaps 1 or 2 arbitrarily
    %else consecutive in a bdycmp, add common vertex
    if plaps1(cmpwrap(j),cmpwrap(j+1)) ~= 0
      b(j) = plaps1(cmpwrap(j),cmpwrap(j+1));
    else
      b(j) = c(cmpwrap(j)); %ok in wrap case
    end
  end

  %need extra interpolation points?
  bb=[];
  pa_associate=[];
  for j=1:size(b,1);
    e = cmpwrap(j);  %associated edge
    de = almondsspecifier(e,4);
    ra = almondsspecifier(e,2); %almond radii
    ca = almondsspecifier(e,1); %almond center
    atheta = almondsspecifier(e,5);  %angle edge subtends at almond center

    g=b(j); h=b( mod_nz(j-1,size(b,1)) );
    btheta = 2* atan( norm(g-h) / (2*point_to_line_dist(ca, two_point_to_line(g,h,1), h ) ) );

    if btheta > 2*atheta/3  %two interps needed
      shiftth = [-2*btheta/3;-btheta/3];
    elseif btheta > atheta/3
      shiftth = -btheta/2;
    else
      shiftth = [];
    end
    v = (b(j) - ca);
    v =[real(v) imag(v)];
    add=[];
    for t = shiftth'
      rot = [cos(t) sin(t); -sin(t) cos(t)];
      p = v*rot;
      p = ca + p(1) + i*p(2);
      add=[add; p];
    end;
    add=[add; b(j)];
    bb = [bb; add ];
    pa_associate =  [pa_associate; e*ones(size(add))];
  end;


  who
  %convert to r,c format
  m = size(pr,1)+1;
  mm = m + size(bb,1)-1;
  pcells = mergecells( pcells, [m:mm]');
  pc = [pc;bb];
  pr = [pr;bb(size(bb,1)); bb(1:size(bb,1)-1)];
  almond_associate = [almond_associate; pa_associate];

%%%%%%%%%%%%%%% draw the approximation %%%%%%%%%%
H = plot([bb;bb(1)],'m');
drawnow;
%b
%bb
%shortzoom;
%delete(H);
%%%%%%%%%%%%%%%%%%%%%%%%

end %for q

pl = ones(size(pr));  %polygon, all ones


%determine floaters
is_floater=zeros(1,size(pcells,2));
xsav=is_floater;
nsav=is_floater;

for q=1:size(pcells,2)
  [jnk jnk b] = find(pcells(:,q));
  bb=pr(b); %coordinate points
  [x j]=max(real(bb));
  x=x(1); j=j(1);  
  prv=mod_nz(j-1,size(bb,1));
  nxt=mod_nz(j+1,size(bb,1));
  %an outward vector from x
  n1 = i*(bb(j)-bb(prv)); n1=n1/norm(n1);
  n2 = i*(bb(nxt)-bb(j)); n2=n2/norm(n2);
  if real(n1+n2)<0 %its a disconnected hole, called a floater
    is_floater(q) = 1;
    xsav(q)=x;
    nsav(q)= (n1+n2)/norm(n1+n2);
  end
end %for q


%associate floaters, ray shooting query to determine closest one
floaters = 1:size(is_floater,2); %default is self
INFX=2*max(real(pr)); %same as infinity
for q=find(is_floater)  %for all floaters
  hit_dist = Inf;
  farpt = INFX + i*imag(xsav(q));
  for qq=find(~is_floater)  %find associated non-floater
    [jnk jnk cmp]=find(pcells(:,qq));
    for j=cmp'
      if edgeintersect(xsav(q),farpt,pr(j),pc(j))
        dist = abs(point_to_line_dist(xsav(q), two_point_to_line(pc(j),pr(j),1), pr(j)));
        if dist<hit_dist
          floaters(q)=qq;
          hit_dist=dist;
        end %if closest so far
      end %if hit
    end %for j
  end %  qq
end %for q


