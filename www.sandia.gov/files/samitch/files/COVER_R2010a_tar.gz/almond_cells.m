function [plaps1,plaps2,cells]=almond_cells(centers, radii, almonds, almondsspecifier, bdycmps); 
% function [plaps1,plaps2,cells,is_almond]=almond_cells(centers, radii, almonds, almondsspecifier, bdycmps); 
%  cells is index into almonds!
%  connects & computes cells  
% almonds is in the same format as bdycmps on input
% floater is list of cells that still need to be connected

%label for each bdycmps column, index of boundary component it is connected to
connectlabel = 1:size(bdycmps,2); 

[I,J,a]=find(almonds);
plaps1=sparse(size(I,1),size(I,1)); 
plaps2=plaps1;
hits=plaps1;

eps = i*1e-300;  %small value for perturbing from zero

%intersection points for almond intersection of which two almonds,
%sorted within by column (plaps1 then plaps2)
%first column is coordinates, second is how defined,
maxindex=0;

%for each almond
for k=1:size(I)

  c1 = almondsspecifier(k,1);
  r1 = almondsspecifier(k,2);
  e1 = almondsspecifier(k,3);
%%%%
HHH = plot([centers(e1);radii(e1)],'w');
%%%%

  %for each other almond
  for kk=k+1:size(I)

    %compute intersection points
    c2 = almondsspecifier(kk,1);
    r2 = almondsspecifier(kk,2);
    e2 = almondsspecifier(kk,3);

    % do circles truly overlap & one doesn't contain the other?
    % no numerical issues due to tangency to worry about
    df = c2-c1;   cd = norm(df); %cd = center distance
    if ((r1 + r2) >= cd) & (abs(r1-r2) <= cd)
      %tangpt
      df = df/cd; %direction
      r12=r1^2; 
      x = (r2^2 - r12 - cd^2 ) / (2*cd); %distance
      tangpt = c1 - x * df;
      tangdir= i*df;

      %commonpts
      t=sqrt(r12 - x^2)*tangdir;
      p=[tangpt+t; tangpt-t];

%%%%%%%%%%%%%%%%%%%%%%%%%%%
%HHHH = plot([centers(e2);radii(e2)],'w');
% HH=plot(tangpt,'co');
% H=plot(p,'cx');
%  shortzoom;
%drawnow
%  delete(H);
%  delete(HH);
%  delete(HHHH);
%%%%%%%%%%%%%%%%%%%%%%5

      %make sure points match exactly

      %does kk imediatly follow k in a bdy component, or vice versa
      consec = (J(k) == J(kk)); %same column
      if consec
        conseci=e1;
        consec = I(k)+1==I(kk); 
        if ~consec & (I(k)==1)
	  conseci=e2;
	  consec = size(bdycmps,1) < I(kk)+1;
	  if ~consec 
	    consec = bdycmps(I(kk)+1,J(kk))==0;
	  end
	end
      end
      if consec
 	if norm(p(1) - centers(conseci)) < norm(p(2) - centers(conseci))
		p(1) = centers(conseci);
	else
		p(2) = centers(conseci);
	end
      end

      %add non-endpts to list p and pdef
      %do almonds truly overlap?

      if (  (cwi(radii(e1), centers(e1), p(1)) == -1) & (cwi(radii(e2),centers(e2),p(1)) ==- 1)  ) | (  (cwi(radii(e1), centers(e1), p(2)) == -1) & (cwi(radii(e2),centers(e2),p(2)) == -1)  )

	%perturb so non-zero for recognition in plaps
        if centers(conseci) == 0
	    centers(conseci) = eps;
        end
        if (p(1)==0) 
	  p(1) = eps;
        end
        if (p(2)==0)
          p(2) = eps;
        end

	df=centers(e1)-radii(e1);
	key1 = dot(p(1)-radii(e1),df); key2=dot(p(2)-radii(e1),df);
	if key1<key2  %enforce this order
  	  plaps1(k,kk)=p(1);
	  plaps2(k,kk)=p(2);
	else
	  plaps1(k,kk)=p(2);
	  plaps2(k,kk)=p(1);
	end
	%reverse order for other almond
	plaps1(kk,k)=plaps2(k,kk);
	plaps2(kk,k)=plaps1(k,kk);

	hits(k,kk) = ~consec;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% show intersection pts as we go along
%  H=plot(p,'wx');
% HH=plot([centers(e1);radii(e1)],'r');
%  HHH=plot([centers(e2);radii(e2)],'w');
%  e1
%  e2
%  shortzoom;
%  delete(H); delete(HH); delete(HHH);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	

      end %do almonds truly overlap?    
    end %do circles truly overlap?
  end %for kk
%%
delete(HHH)
%%
end %for k

%%%%%%%%%%%%%%%%%%%%
%full(hits)
%disp('hits')
%shortzoom;
%%%%%%%%%%%%%%%%%%

%divide_cell (connect) if necessary

%consecutive bdy components covered by almonds
cells = almonds;
ccell=almondsspecifier(:,1);
rcell=almondsspecifier(:,2);
lcell=sparse(size(ccell,1),1); %almonds==circle boundary

%divide cell based on hits, ignoring consecutive

%for all almonds
I
for j=1:size(I,1)
    j
  hitsj = find(hits(j,:))
  %for h=hitsj'
  for h=hitsj
      j
      h
      find(cells==j)
      find(cells==h)
    [cmpx, cmpy] = find(cells==j);
    [othx, othy] = find(cells==h);

    %find where it true_touches, jj and hh set, indicies into cmp and oth
    for jj=1:size(cmpx,1)
      [jnk jnk cmp]=find(cells(:,cmpy(jj)));
      cmpwrap = [cmp(size(cmp,1)); cmp; cmp(1);];
      for hh=1:size(othx,1)
        [jnk jnk oth]=find(cells(:,othy(hh)));
        othwrap = [oth(size(oth,1)); oth; oth(1);];
	send1 = [oth(othx(hh)); cmpwrap(cmpx(jj)+[0 2 1])];
        send2 = [cmp(cmpx(jj)); othwrap(othx(hh)+[0 2 1])];
        found = true_touch( ccell(send1), rcell(send1), sparse(4,1) ) & true_touch( ccell(send2), rcell(send2), sparse(4,1) );
	if found, break; end
      end %for hh
      if found, break; end
    end %for jj
     
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%cmp(cmpx(hh))
%oth(othx(jj))
%disp('are touching')
%shortzoom;
%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %split component?
    if othy(hh) == cmpy(jj)
      cells = removecolumn(cells, cmpy(jj));
      if othx(hh) < cmpx(jj), f = othx(hh); s = cmpx(jj);
      else 		      s = othx(hh); f = cmpx(jj); end
      newcells = mergecells(cmp([1:f s:size(cmp,1)]), cmp([f:s]));
      cells = mergecells(cells, newcells); 

    %merge component?
    else
      cells = removecolumn(cells, [cmpy(jj) othy(hh)]);
      cells = mergecells(cells, [cmp(1:cmpx(jj)); oth([othx(hh):size(oth,1) 1:othx(hh)]); cmp(cmpx(jj):size(cmp,1))]);
    end

%%%%%%%%%%%%%%%%%%%%%%%%%
%full(cells)
%disp('full cells');
%%%%%%%%%%%%%%%%%%%%%%%%%

  end %for h
end %for j



%%%%%%%%%%%%%%% show all the intersection points at end %%%%%%%
[jnk jnk p1] = find(plaps1);
[jnk jnk p2] = find(plaps2);

plot(p1,'rx');
plot(p2,'rx');
%%%%%%%%%%%%%%%%%%%%%%%%%%%

