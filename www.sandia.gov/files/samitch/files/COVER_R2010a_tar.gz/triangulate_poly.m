function [esav,psav,pdefsav] = triangulate_poly(pc,pr,pl,pcells, is_floater, floaters);

esav=[];
pdefsav=[];
psav=[];

%associate floaters
Q = size(pcells,2); % #columns = bdy components
for q=find(~is_floater)
disp(sprintf('Triangulating polygonal approximation to outside almond region #%i.',q));
  send = find(floaters == q);

  %make sure outer bdy component is the first one sent
  k = find(~is_floater(send)); %outer bdy component
  kk=find(is_floater(send));
  

  [c2,r2,l2,cells]=preprocess(pc,pr,pl,pcells(:,send([k kk]) ));
  title('+ Triangulating Cells +');
  [e,p,pdef] = triangulate_cells(c2, r2, l2, cells );

  %% The pdef indicies corresponding to polygon edges are correct,
  %% but the circles generated for different polygons with holes
  %% share indicies:
  %% Something like circle_indicies = find(pdef>size(pr)), 
  %%  pdef(circle_indicies) ++ max(pdefsav)

  esav=[esav;e+size(psav,1)];
  pdefsav=[pdefsav;pdef];
  psav=[psav;p];
end; %for q

  
