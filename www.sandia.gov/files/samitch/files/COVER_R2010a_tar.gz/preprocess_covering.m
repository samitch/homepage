function [centers,radii,is_line,almonds,cells] = preprocess_covering(centers, radii,is_line,bdycmps);
%  function [centers,radii,is_line,almonds,cells] = preprocess_covering centers, radii, is_line,bdycmps);
%     assume is_line is all 1 on input

%compute maximal almonds
[a]=compute_almonds(centers,radii,bdycmps);

%connects & computes cells  
[centers,radii,is_line,p,cells]=almond_cells(centers,radii,a,bdycmps); 

[centers,radii,is_line] = fix_almond_verts(ceneters,radii,is_line,p,cells);
almonds=a;
