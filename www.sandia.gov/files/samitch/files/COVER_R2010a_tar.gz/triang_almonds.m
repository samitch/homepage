function [e,p] = triang_almonds(e,p,pdef,c,r,pc,pr,almond_associate,almonds, almondsspecifier,bdycmps);

% c and r are bdy points

%for identifying vertices on the edges of the input shared by several almonds
input_to_p_index = sparse( size(c,1), size(c,1) );
last_non_almond_edge = size(e,1);

%%% triangulate the almonds
for a=1:size(almondsspecifier,1)  %for all almonds
disp(sprintf('Triangulating almond for input edge #%i.',a));
edg=almondsspecifier(a,3);
%%%%%
%H = plot([c(edg);r(edg)],'b');
%%%%%

  %find the points on approximation to the almond
  chordpts = [];
  for j=find(almond_associate == a)'
    [cp jnk] = find(abs(pdef) == j);
    chordpts = [chordpts; cp]; %may be repeats
  end
  
  %remove repeats in chordpts
  cp = sparse( size(pdef,1),1 );
  cp( chordpts ) = ones(size(chordpts,1),1);
  chordpts = find(cp);

  %sort points along arc
  v = c(edg) - r(edg);
  key = dot(p(chordpts)-r(edg),v);  %it really works!
  [jnk, S] = sort(key);
  chordpts = chordpts(S);

  %find the points exactly on the almond
  cp_on_arc = find((pdef(chordpts,1) <= size(pc,1)) & (pdef(chordpts,1) > 0) & (pdef(chordpts,2) > 0) & (pdef(chordpts,2) <= size(pc,1)));
  %cp_on_arc is automatically sorted
  arcpts = chordpts(cp_on_arc); %automatically sorted

  %add endpts from input edge if necessary
  if p(arcpts(1)) ~= r(edg)  %no roundoff errors, as exact in almond_cells
    [j k] = find(bdycmps == edg); %just one found
    [jnk jnk cmp] = find( bdycmps(:,k) );
    prvedg = cmp( mod_nz(j-1,size(cmp,1)) );
    if input_to_p_index( edg, prvedg )
      paddindex = input_to_p_index( edg, prvedg );
    else
      p(size(p,1)+1)=r(edg);
      paddindex = size(p,1);
      input_to_p_index( edg, prvedg ) = paddindex;
      input_to_p_index( prvedg, edg ) = paddindex;
    end
    chordpts = [paddindex;chordpts];
    cp_on_arc = [1;1+cp_on_arc];
  end
  m = size(arcpts,1);
  if (p(arcpts(m)) ~= c(edg)) %no roundoff errors, as exact in almond_cells 
    [j k] = find(bdycmps == edg); %just one found
    [jnk jnk cmp] = find( bdycmps(:,k) );
    nxtedg = cmp( mod_nz(j+1,size(cmp,1)) );
    if input_to_p_index( edg, nxtedg )
      paddindex = input_to_p_index( edg, nxtedg );
    else
      p(size(p,1)+1)=c(edg);
      paddindex = size(p,1);
      input_to_p_index( edg, nxtedg ) = paddindex;
      input_to_p_index( nxtedg, edg ) = paddindex;
    end
    chordpts = [chordpts; paddindex];
    cp_on_arc = [cp_on_arc; size(chordpts,1)];
  end
  arcpts = chordpts(cp_on_arc);


  %add edges between consecutive almond intersection vertices.
  for j=1:size(cp_on_arc,1)-1
    if cp_on_arc(j)+1 == cp_on_arc(j+1)
      e(size(e,1)+1,:) = [arcpts(j) arcpts(j+1)];
    end
  end
  e(size(e,1)+1,:) = [arcpts(1) arcpts(size(arcpts,1))]; %the input edge

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%disp('arc points');
%HH = plot(p(arcpts),'w*');
%shortzoom;
%delete(HH);
%disp('chord points');
%HH = plot(p(chordpts),'wo');
%shortzoom;
%delete(HH);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  

  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%disp('chord points');
%for pp = p(chordpts).'
%  HH = plot(pp,'wo');
%  shortzoom;
%  delete(HH);
%end
%disp('arc points');
%for pp = p(arcpts).'
%  HH = plot(pp,'w*');
%  shortzoom;
%  delete(HH);
%end
%delete(H);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  

  %find the maximal arc chord, and its arclength
  maxtheta = 0;
  ca = almondsspecifier(a,1);
  atheta = almondsspecifier(a,5);

  lastpt =  size(arcpts,1);
  for j=1:lastpt-1
    %chord is arcpts(j), arcpts(j+1)
    g=p(arcpts(j)); 
    h=p(arcpts(j+1));
    theta = 2* atan( norm(g-h) / abs(2*point_to_line_dist(ca, two_point_to_line(g,h,1), h ) ) );
    if theta>maxtheta
      maxtheta=theta;
      max_edge = j;
    end
  end

  %TRIANGULATE INTERNAL TO ALMOND, two cases
  %BIG CHORD
  if maxtheta > atheta/2  
    a_edges = []; %edges internal to the almond
    me = cp_on_arc(max_edge);
    lastchordpt = size(chordpts,1);
    %heuristic, find if j or j+1 is closer to edg <==> shorter chord to edg
    if norm( p(arcpts(max_edge)) - p(arcpts(1)) ) < norm( p(arcpts(max_edge+1)) - p(arcpts( lastpt )) ) 
      a_edges = [arcpts(lastpt)*ones(me,1) chordpts(1:me); arcpts(max_edge)*ones(lastchordpt-me-1,1) chordpts(me+2:lastchordpt)];
    else
%%%%%%%%%%%%%
%  plottri([arcpts(1)*ones(lastchordpt-me,1) %chordpts(me+1:lastchordpt)],p,'c','y');
%  shortzoom;
%  plottri([arcpts(max_edge+1)*ones(me-1,1) chordpts(1:me-1)],p,'g','y');
%  shortzoom;
%%%%%%%%%%%

      a_edges = [arcpts(1)*ones(lastchordpt-me,1) chordpts(me+1:lastchordpt);
arcpts(max_edge+1)*ones(me-1,1) chordpts(1:me-1)];
    end;

  %NO BIG CHORD
  else
    %compute (one point of) pretend chord with half the almond arc
    v = (p(arcpts(1)) - ca);
    v =[real(v) imag(v)];
    t = atheta/4;
    rot = [cos(t) sin(t); -sin(t) cos(t)];
    pt = v*rot;
    pt = ca + pt(1) + i*pt(2);
    pv = pt-p(arcpts(lastpt)); pv=pv/norm(pv);
 
    %use symettry to compute intersection of diagonals
    midpoint = (p(arcpts(1))+p(arcpts(lastpt))) /2;
    mv = midpoint-ca; mv=mv/norm(mv);
    %point and vector
    centerpt = lineintersect( [ca;p(arcpts(lastpt))],[mv;pv] ); 

    p(size(p,1)+1) = centerpt;
    a_edges=[ size(p,1)*ones(size(chordpts,1),1) chordpts];
  end %no big chord  

%%%%%%%%%%%%%
%  plottri(a_edges,p,'b','y');
%  shortzoom;
%%%%%%%%%%%
  m=size(e,1);
  e(m+1:m+size(a_edges,1),:) = a_edges;

end  

%%%%%%%%%%%%%%%
plottri(e(last_non_almond_edge:size(e,1),:),p,'b');
drawnow
%%%%%%%%%%%%%%

%get rid of redundant edges added interior to two almonds
e= matrix_to_list( list_to_matrix(e,p) ); 
