function [] = zoom(A,xy,E,p)
%function [] = zoom(A,xy,E,p)
%  A is sparse mesh edge matrix, xy mesh point coordinates
%  E is input Edge matrix, p input point coordinates
%
%  Assumes axis/graphics window already initialized
%  To skip a display, pass xy or p as empty matrix []
%  Numerous control variables may be set in file zoom.m
%

%control variables
cols = size(xy,2);
domesh = ~isempty(xy);
dopoints =  domesh & 0;  % do i draw output vertices or not?
% colors = green, blue, red, white, invisible
Pcolor = 'g'; %Polygon input color
Pcolordot = 'go'; Pnocolor = 'g.';
Mcolor = 'r'; %mesh color
Mcolordot = 'rx'; Mnocolor = 'r.';
doP = 1 & ~isempty(p);
doaxis = 1;
doquad = 1;  %show the leaf quadtree before warping
squishsquares = 1 & doquad;
dotitle = 1;

if (doquad)
  disp('Loading quadtree squares from file "quadsquares".')
  load 'quadsquares' -ascii
  if (squishsquares) & (size(quadsquares,1)>0)
    j=1; jmod = 0; %jmod for shrinking duplicates a bit less
    old = quadsquares(2,:); %no chance of equality
    while (j < size(quadsquares,1))
      % shrink more if duplicates
      if (quadsquares(j,:) == old) 
	jmod = jmod + 2; 
      else
	jmod = 0;
      end
      old = quadsquares(j,:);
      shrink = (quadsquares(j+1,2) - quadsquares(j,2))/ (8 + jmod);
      quadsquares(j:j+3,:) = quadsquares(j:j+3,:) + [-shrink, shrink; -shrink,-shrink;  shrink,-shrink; shrink, shrink];
      j=j+4;
    end %while
  end
else
  quadsquares = [];
end

if (doP)
  %convert e to sparse matrix format for zoom.m
  n = size(E,1);
  E = sparse(E(:,1),E(:,2),1,n,n);
  E = E | E' | speye(n);
end

res=1e-6;  %how small can we zoom in

disp('Drawing, please wait . . .')

%figure out title
if (dotitle)
  t='+ ';
  if (domesh)
	t = [t,'Output mesh + '];  end
  if (doP)
	t = [t,'Input polygon + '];  end
  if (doquad)
	t = [t,'Quadtree + '];  end
end;

%figure out axis limits, draw axis
dobuff = 1;
if ~isempty(p)
  xmax = max(p(:,1));  xmin = min(p(:,1));  
  ymax = max(p(:,2));  ymin = min(p(:,2));
elseif (~isempty(xy))
  xmax = max(xy(:,1));  xmin = min(xy(:,1));
  ymax = max(xy(:,2));  ymin = min(xy(:,2));
elseif (~isempty(quadsquares))
  xmax = max(quadsquares(:,1));  xmin = min(quadsquares(:,1));
  ymax = max(quadsquares(:,2));  ymin = min(quadsquares(:,2));
  dobuff = 0;
else
  xmax = 1000; xmin = 0;
  ymax = 1000; ymin = 0;
  dobuff = 0;
end

if (ymax-ymin) > (xmax -xmin)
	diff = ymax-ymin;
else
	diff = xmax -xmin;
end
if (dobuff)
  buff = diff/4;
else
  buff = diff/100;
end
xmax = xmin + diff + buff; 
ymax = ymin + diff + buff; 
xmin = xmin - buff;
ymin = ymin - buff;

clg
hold off
%erase previously drawn axis
if (doaxis==0) axis('off'); end; 
axis('square') 
axis([xmin xmax ymin ymax])
if (dotitle)  title(t); end
hold on

%draw something so we can turn on hold
if (dopoints==1)
        plot (xy(:,1), xy(:,2), Mcolordot);
elseif (~isempty(p))
        plot (p(1,1), p(1,2), Pnocolor);
elseif (~isempty(xy))
  plot (xy(1,1), xy(1,2), Mnocolor);
elseif (~isempty(quadsquares)) 
	plot (quadsquares(1,1), quadsquares(1,2), 'c.');
else
	plot(0);
end
hold on
if (domesh) gplot0(A,xy,Mcolor); end;
if (doP)
  plot( p(:,1),p(:,2),Pcolordot );
  gplot0(E,p,Pcolor);
end;
	

if (doquad) quadplot(quadsquares); end;

drawnow;
hold off

% matlab graphics now subsumes the following

%zoom in/out
disp('');
%but = 1; x1=0; y1=0; x2=1000; y2=1000;
%while ( (but==1) | (but==3) )
%    disp('Press the left button to frame a zoom area, right to zoom out, center to quit.');
%    [x,y,but]=ginput(1);
%    %zoom into box
%    if (but == 1)
%         x1=x; y1=y;
% 	disp('Press the left button again to frame the zoom area.');
%         [x2,y2]=ginput(1); % get other bdy of square
% 	disp('wait');
%         %make sure display is square
%         bsize = max( [abs(x2-x1) abs(y2-y1) res ]);
%         x1 = min( [x1 x2] ); y1 = min( [y1 y2] );
%         x2=x1+bsize; y2=y1+bsize;
%         axis( [x1 x2 y1 y2]);
% 	if (doaxis == 0) axis('off'); end
%         hold('on');
% 	if (dopoints==1)
%         	plot (xy(:,1), xy(:,2), Mcolordot);
% 	elseif (~isempty(p))
%         	plot (p(1,1), p(1,2), Pnocolor);
% 	elseif (~isempty(xy))
%         	plot (xy(1,1), xy(1,2), Mnocolor);
% 	elseif (~isempty(quadsquares))
% 		plot (quadsquares(1,1), quadsquares(1,2), 'c.');
% 	else
% 		plot(0);
% 	end
%         hold on
% 	if (dotitle)  title(t); end
%         if (domesh) gplot0(A,xy,Mcolor); end;
% 	if (doP)	
%             plot( p(:,1),p(:,2),Pcolordot );
%             gplot0(E,p,Pcolor);
% 	end;
% 	if (doquad) quadplot(quadsquares); end;
%         drawnow;
%         hold off
%     %zoom out
%    elseif (but == 3)
% 	disp('wait');
%         diffx = x2-x1; diffy = y2-y1;
%         x1=x1-2*diffx; x2=x2+2*diffx;
%         y1=y1-2*diffy; y2=y2+2*diffy;
%         axis( [x1 x2 y1 y2] );
% 	if (doaxis == 0) axis('off'); end
% 	hold('on');
% 	if (dopoints==1)
%         	plot (xy(:,1), xy(:,2), Mcolordot);
% 	elseif (~isempty(p))
%         	plot (p(1,1), p(1,2), Pnocolor);
% 	elseif (~isempty(xy))
%         	plot (xy(1,1), xy(1,2), Mnocolor);
% 	elseif (~isempty(quadsquares))
% 		plot (quadsquares(1,1), quadsquares(1,2), 'c.');
% 	else
% 		plot(0);
% 	end
%         hold on
%  	if (dotitle)  title(t); end
%         if (domesh) gplot0(A,xy,Mcolor); end;
%         if (doP)
% 	    plot( p(:,1),p(:,2),Pcolordot );
% 	    gplot0(E,p,Pcolor);
% 	end;
% 	if (doquad) quadplot(quadsquares); end;
%         drawnow;
%         hold off
%    end
% end
% disp('done')
% %axis('square')
% 
