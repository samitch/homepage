function [G,xy,E,p] = dispmesh
% function [G,xy,E,p] = dispmesh
%   Assumes tst.in.p and tst.in.e are files containing an input polygon and
%   tst.p tst.e are files containing a  mesh (produced by tripoly). 
%   Displays the input and the mesh, and perhaps the quadtree squares.
%
%   See also trizoom.m, drawmesh.m;
%

%drawing control variables mostly appear in trizoom.m, not here

doinput = 1;  %display separately?  See also trizoom.m

disp('Loading mesh and input polygon from tst.e, tst.p, tst.in.e and tst.in.p')

%load input polygon and mesh
%matlab has unfortunate matrix naming conventions with load
!mv tst.in.e E; mv tst.in.p p; mv tst.e G; mv tst.p xy
load 'E' -ascii
load 'p' -ascii
load 'G' -ascii
load 'xy' -ascii
!mv E tst.in.e; mv p tst.in.p; mv G tst.e; mv xy tst.p 

%rearrange the data a bit

nn=size(xy,1);
mm=size(G,1);
G = sparse(G(:,1),G(:,2),1,nn,nn,mm);
G = G | G' | speye(nn);


if (doinput)  %display

  disp('Displaying input polygon.');

  %look at just polygon first
  trizoom([],[],E,p);
end

if (doinput)
  disp('Displaying output mesh.');
end

trizoom(G,xy,E,p);  %output together with input

% Data format  is xy coordinates of vertices
% in files "xxx.p".  Each line of the file (=row of the matrix) is a vertex, 
% referenced by its index in file "xxx.e"
% xxx.e is a list of all the edges, one edge per line.
%
% i.e.
%
% xxx.p, 
%
%  	 x_coordinate_of_vertex_#1  y__coordinate_of_vertex_#1
%  	 x_coordinate_of_vertex_#2  y__coordinate_of_vertex_#2
%  	 x_coordinate_of_vertex_#3  y__coordinate_of_vertex_#3
%	 . . . 
%
% xxx.e
%	i_1 j_1    (signifies an edge between vertex i_1 and j_1)
%	i_2 j_2    (signifies an edge between vertex i_2 and j_2)
%	i_3 j_3    (signifies an edge between vertex i_3 and j_3)
% 	. . .
%


