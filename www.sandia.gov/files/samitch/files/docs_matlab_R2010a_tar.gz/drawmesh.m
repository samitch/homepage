function [G,xy,E,p] = drawmesh
%function [G,xy,E,p] = drawmesh
%  User draws an input polygon {E,p} with the mouse by get2d.m.
%  Then, tripoint creates a triangulation {G,xy} of that polygon by trimesh.m.
%  Finally, the input and the mesh is displayed by zoom.m.
%

clf
[E,p] = get2d;  %user draws polygon
[G,xy] = trimesh(E,p);  %tripoint creates the mesh

trizoom(G,xy,E,p);  %display

