function quadplot(quadsquares)
% function quadplot(quad)
% plot a series of boxes
% quadsquares is a 4k x 2 matrix of coordinates, k=number of boxes
%
Qcolor = 'c'; %cyan  -. == dashdot line style

A = [1 1 0 1; 1 1 1 0; 0  1 1 1; 1 0 1 1];

j=1;
while (j < size(quadsquares,1))
  gplot(A, quadsquares(j:j+3,:), Qcolor);
  j=j+4;
end

