function tops (A, xy);
% saves in format usable by gpp (gpp4)
%

[I,J] = find(A);  % non-zero entries
data = [xy(I,:), xy(J,:)];
save tops.out data  % -ascii -double
