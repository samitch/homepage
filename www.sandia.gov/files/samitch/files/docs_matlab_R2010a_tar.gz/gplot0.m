function gplot0(A,xy,c)
% gplot0(A,xy,c): Plot a picture of a graph in color c (optional).
% The graph is the graph of sparse matrix A.
% Row i of xy is the position [x y] for vertex i.
% The axes are not reset before the plot is made, unlike gplot.
%
% See also gplot, mplot, unmesh, submesh.


[i,j] = find(A);
[ignore, p] = sort(max(i,j));
i = i(p);
j = j(p);


X = [ xy(i,1) xy(j,1) ]';
Y = [ xy(i,2) xy(j,2) ]';

if nargin > 2, 
	d = [c '-']; 
else,
	d = 'r-';
end;

xymin = min(xy);
xymax = max(xy);
range = max(xymax-xymin);
plot (X, Y, d);
