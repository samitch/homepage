function [G,xy] = trimesh(e,p)
% [G,xy] = trimesh(e,p)
% Generate a triangular mesh including the given input
% points, with bounded-aspect-ratio triangles.
%
%input
% e is nx2 matrix of directed edges
% p is list of coordinates for data points
%
%output
% G is sparse incidence matrix of vertices (entries 0 or 1)
% xy is x,y coordinates of mesh vertices
%

% xyin = round(xyin); If you want data rounded (to integer?)

disp('Saving input polygon to files tmp.in.p and tmp.in.e')

fp = full(p);
fe = full(e);

save('tmp.in.p', 'fp', '-ascii', '-double') %full(p) 
save('tmp.in.e', 'fe', '-ascii', '-double') %fll(e)

%do the actual meshing
!./tripoint tmp

disp('Loading mesh from files tmp.p and tmp.e')

%load mesh
%matlab has unfortunate matrix naming conventions with load
!mv tmp.e G; mv tmp.p xy
load('G','-ascii');
load('xy','-ascii');
!mv G tmp.e; mv xy tmp.p 

%convert G to sparse matrix format
nn=size(xy,1);
mm=size(G,1);
G = sparse(G(:,1),G(:,2),1,nn,nn,mm);
G = G | G' | speye(nn);
