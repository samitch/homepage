function checktri(G, xy, trilist, isbdry);
%function checktri(G, xy, trilist, isbdry);
%
%input
% G is incidence matrix (A in drawmesh), xy is vertex coordinates
% trilist is the list of three vertices in each triangle, 
% isbdy is true/false vector of "is triangle i on the boundary?"
%
% writes out text if a degeneracy is detected
% also gives some indication of smallest and largest angles
%

[numtri,scrap] = size(trilist);

[i,j] = find(G);  %nonzero entries

mask = (i < j);   %look only at entries where i<j

imask = i(mask);
jmask = j(mask);  %edge list, each edge only listed once

enum = length(imask);  %number of edges
errorflag = 0;		%found a bad triangle yet?

ecount = sparse(imask,jmask,zeros(enum,1));  %incidence matrix, all zero
edet = sparse(imask,jmask,zeros(enum,1));    %determinants of triangles
equality = edet;  %determinants of triangles/edge_length^2

for j = 1 : numtri  %j=which triangle under consideration
  for q = 1 : 3  %which edge of triangle j to consider
    if q == 1
      i1 = 1;
      i2 = 2;
    elseif q == 2
      i1 = 1;
      i2 = 3;
    else
      if trilist(j,2) < trilist(j,3)
        i1 = 2;
        i2 = 3;
      else
        i1 = 3;
        i2 = 2;
      end
    end
    v1 = trilist(j,i1);  %first vertex of edge
    v2 = trilist(j,i2);  %second vertex of edge
    if G(v1,v2) == 0
      disp(sprintf(' Nonedge j = %i  v1 = %i  v2 = %i', j, v1, v2));
      errorflag = 1;
    end
    h = ecount(v1,v2);
    %three or more triangles sharing a side
    if h >= 2
      disp(sprintf(' %i previous triangles contain this edge, plus j = %i, edge v1 = %i  v2 = %i', h, j, v1, v2));
      errorflag = 1;
    end
    v3 = trilist(j, 6 - i1 - i2);
    newdet = det([(xy(v3,:)-xy(v1,:));(xy(v2,:)-xy(v1,:))]);
    %check that triangles do not overlap
    if h == 1
      s = edet(v1,v2);
      if s * newdet > 0
        disp(sprintf(' same side triangles j = %i  v1 = %i  v2 = %i', j, v1, v2))
        errorflag = 1;
      end
      equality(v2,v1) = abs(newdet)/ ((xy(v1,:)-xy(v2,:)) * (xy(v1,:)-xy(v2,:))');
    end
    if h == 0
      edet(v1,v2) = newdet;  %determinant of first triangle seen with this edge
      equality(v1,v2) = abs(newdet)/ ((xy(v1,:)-xy(v2,:)) * (xy(v1,:)-xy(v2,:))');
    end
    ecount(v1,v2) = h + 1;  %increment number of times this edge has been seen
  end
end


%????
for i = 1 : ecount
  ebdry = isbdry(imask(i)) * isbdry(jmask(i));
  ec = ecount(imask(i), jmask(i));
  if (ec ~= 1) & ebdry
    disp(sprintf(' bdry edge %i %i with %i tris', imask(i), ...
       jmask(i), ec))
    errorflag = 1;
  end
  if (ec ~= 2) & (ebdry == 0)
    disp(sprintf(' nonbdry edge %i %i with %i tris', imask(i), ...
       jmask(i), ec))
    errorflag = 1;
  end
end

if errorflag == 1
  disp('some errors found in the triangulation!!')
  disp(' press any key to continue')
  pause
end

%report on element quality
[i,j,V] = find(equality);
[Y,i2] = max(V);
[Z,i3] = min(V);

%this sort of identifies the smallest edge in the "long and skinny"est triangle
%that has no large angles  --> finds a small angle when no large angles
disp(sprintf('Small angle -> Max (det/edge_length^2) = %f for edge %i %i',Y,i(i2),j(i2)));
disp(xy([i(i2),j(i2)],:))

%this sort of identifies the largest edge in the "long and short"est triangle
%--> finds the largest angle, but sometimes a long edge next to a short angle 
disp(sprintf('Big.small angle -> Min (det/edge_length^2) = %f for edge %i %i',Z,i(i3),j(i3)));
disp(xy([i(i3),j(i3)],:))


%check for degeneracy, two vertices having the same coordinates
%would sorting help? there are a lot of points with the same x OR y coordinate
checkdegen=1;
if (checkdegen)
  for z=1:size(xy,1)-1
    for zz=z+1:size(xy,1)
       if xy(z,:) == xy(zz,:)
  	 disp('two vertices with same coordinates');
 	 disp([z,zz,xy(z,:)])
       end
    end
  end
end %if
