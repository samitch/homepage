function [e,p] = get2d(holdit)
% function [e,p] = get2d(holdit)
%	User draws a polygon with holes in the graphics window using the mouse.
%       e is an m by 2 matrix of directed edges
%       p is an n by 2 matrix of coordinates of vertices
%       The polygon drawing is held in the graphics window unless the optional
%	argument "holdit" is zero.

Pcolor = 'g';
Pcolordot = 'go';
dotitle = 1;

if nargin < 1
  holdit = 1;
end

disp('Draw a polygon with holes: draw successive cycles of the boundary.')
disp('The polygon interior is to the right of the directed edges.')
disp('  Left mouse button = first or middle vertex of a cycle.')
disp('  Right mouse button = last vertex of a cycle.')
disp('  Center mouse button = last vertex of the LAST cycle.')

clf
hold off
axis([0 1000 0 1000])
axis('square')
hold on
if (dotitle)
	title('+ Drawing input polygon +'); end;
%axis(axis)
%plot(0)

% Initially, the list of points is empty and its length is 0.
p = [];
e = [];
n = 0; %total number of points inputed
k = 1; %first point of new simply poly (points labeled 1:n)

% Loop, picking up the points.
but = 1;
while (but ~= 2)
   [xi,yi,but] = ginput(1);

   n = n + 1;
   p = [p; xi yi];  %add point coordinates to row 
   plot(xi,yi,Pcolordot)
   if (n ~= k) 
  	e=[e; n-1 n];  %add segment
	plot( p(n-1:n,1), p(n-1:n,2), Pcolor );
	if (but ~= 1)   % finish poly
	    e=[e; n k];  %edge from last to first
	    plot( [p(n,1), p(k,1)], [p(n,2), p(k,2)], Pcolor );  
	    k=n+1;  %new poly starts with this
	end
   end
   drawnow; %flush graphics, so things are drawn right away
   %text(xI,yi,int2str(n))
end %while

% note, matlab 4.0.beta.3 will only display if there's nothing
% else to do, so last two lines and dot don't appear for a while

if ~holdit
  hold off
  axis('auto')
end

 
