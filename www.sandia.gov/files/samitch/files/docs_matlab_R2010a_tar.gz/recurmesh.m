function [A,xy] = recurmesh
% call tripoint again and again on output
% user draws original points

clf
xyin=get2d;

while (1) %repeat forever

[A,xy]=trimesh(xyin);
size(xyin) % display size
d
gplot0(A,xy);
hold off

%trizoom in/out
disp('');
disp('Use left button to frame zoom in, right to zoom out, center to quit');
but = 1; x1=0; y1=0; x2=1000; y2=1000;
while ( (but==1) | (but==3) )
   [x,y,but]=ginput(1);
   %zoom into box
   if (but == 1)
	x1=x; y1=y;
	[x2,y2,jnk]=ginput(1);
	%make sure display is square
	bsize = max( [abs(x2-x1) abs(y2-y1)] );
	x1 = min( [x1 x2] ); y1 = min( [y1 y2] );
	x2=x1+bsize; y2=y1+bsize;
        axis( [x1 x2 y1 y2]);
	plot (xyin(:,1), xyin(:,2), 'go')
	hold on
	gplot0(A,xy);
	hold off
    %zoom out
   elseif (but == 3)
	diffx = x2-x1; diffy = y2-y1;
	x1=x1-diffx/2; x2=x2+diffx/2;
	y1=y1-diffy/2; y2=y2+diffy/2;
	axis( [x1 x2 y1 y2] );
	plot (xyin(:,1), xyin(:,2), 'go')
	hold on
	gplot0(A,xy);
	hold off
   end
end

xyin=xy; %output mesh points are new input data

end %while
