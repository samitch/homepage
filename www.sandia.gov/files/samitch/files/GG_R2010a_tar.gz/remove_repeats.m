function [a]=remove_repeats(x);
%  function [a]=remove_repeats(x);
%    sort x and remove repeated elements in x

if isempty(x)
  a = [];
  return;
end

x=sort(x);
a=zeros(size(x));
k=2; 
a(1)=x(1);
for j=2:size(x,1)
  if x(j) ~= x(j-1)
    a(k) = x(j);
    k=k+1;
  end
end;
[jnk, jnk, a] = find(a);
