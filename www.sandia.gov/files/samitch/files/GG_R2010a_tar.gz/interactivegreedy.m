function [e,p] = interactivegg(holdit)
% function [p] = interactivegg(holdit)
%	recomputes Gabriel graph as points are added
%

Pcolor = 'g';
Pcolordot = 'go';
dotitle = 1;
t = '+ Gabriel Graph of Point set +';
docircles = 1;

if nargin < 1
  holdit = 1;
end

disp('Draw a point set.')
disp('  Left mouse button = a vertex.')
disp('  Center mouse button = quit.')
disp('  Right mouse button = remove previous vertex.')

clf
hold off
axis([0 1000 0 1000])
axis('equal')
hold on
if (dotitle)
	title(t); end;
%axis(axis)
%plotfast(0)

% Initially, the list of points is empty and its length is 0.
p = []; h = [];
n = 0; %total number of points inputed

% Loop, picking up the points.
but = 1;
while (but ~= 2)
   [xi,yi,but] = ginput(1);

   if but == 1
     p = [p; xi yi];  %add point coordinates to row 
     e = gg_insert(e,p);
   end
   if but == 3
     if size(p,1) > 0 
        [e,p] = gg_delete(e,p);
     end
   end

   if but ~= 2  
     clf
     hold off
     axis([0 1000 0 1000])
     axis('square')
     hold on
     if (dotitle)
	title(t); end;

     if size(p,1) > 0
       plotfast2(p(:,1),p(:,2),Pcolordot);
     end
     if size(e,1) > 0
   	gplotg(list_to_matrix(e,p),p);
	if docircles, plotcircles(e,p); end;
     end;
   end
   
   %drawnow; %flush graphics, so things are drawn right away
   %text(xI,yi,int2str(n))
end %while

if ~holdit
  hold off
  axis('auto')
end

e = list_to_matrix(e,p);
 
