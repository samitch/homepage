function [e,GG,p] = GGT(p);
%function [e,p] = GGT(p); %greedy_gg_triangulation(p);
%
%	GG is the Gabriel graph, e is its greedy completion to a triangulation

n=size(p,1);

if n>1

e = [];
GG = [];

%build big table of greedy value by edge
v = sparse(n,n); %all zeros
for i=2:n   %upper triangular ones
  v(1:i-1,i) = ones(i-1,1);
end

for i=1:n-1
  for j=i+1:n
    %find points interfering with edge i,j
    center = (p(i,:) + p(j,:)) / 2;    
    radius = max( sqr(p(i,:) - center), sqr(p(j,:)-center) );

    %%I = [1:i-1,i+1:j-1,j+1:n];
    distances = sqr( [p(:,1) - center(1), p(:,2) - center(2)] );
    J = find(distances <= radius);
    if (size(J,1) == 2)   %part of GG, must be i,j
      GG = [GG; i j];
      v(i,j) = 0;  %already in e
    else
      %could vectorize
      for k=1:size(J,1);
	if (J(k) ~= i) & (J(k) ~= j)
          a = [p(J(k),1) - p(i,1), p(J(k),2) - p(i,2)];
          b = [p(J(k),1) - p(j,1), p(J(k),2) - p(j,2)];
          s = 1 - abs(a * b') / (norm(a) * norm(b));
          if s < v(i,j)
	    v(i,j) = s;
          end
        end
      end %fork
    end
  end %forj
end %fori

%add non-crossing edges greedily until can't add any more
e = GG;
V=1;
while (V>0)
 [V,I] = max(v);  %maximum for each colum
 [V,j] = max(V);  %maximum among columns

 if V>0
  i = I(j);
  %candidate edge is i,j
  v(i,j) = 0;  %to indicate its been tried.
  crossing = 0; 
  for k=1:size(e,1)
    %%check crossing
    if (i ~= e(k,1)) & (i ~= e(k,2)) & (j ~= e(k,1)) & (j ~= e(k,2)) 
      if xor( cw( p(e(k,1),:), p(e(k,2),:), p(i,:) ), cw( p(e(k,1),:), p(e(k,2),:), p(j,:) ) ) 
        if xor( cw( p(i,:), p(j,:), p(e(k,1),:) ), cw( p(i,:), p(j,:), p(e(k,2),:) ) )
          crossing = 1;
          break;
        end 
      end
    end
  end %for

  if crossing == 0
    e = [e; i j];
  end
 end %if V>0
end %while

end %if n>1
