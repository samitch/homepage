function [M] = removecolumns(M, q);
%  function [M] = removecolumns(M, q);
%  remove columns q from M, works around sparse matrix format bug
%


if isempty(q)
  return;
end

k = 1:size(M,2);
k(q)=zeros(max(size(q)),1);
k=find(k);
if isempty(k)
  M = [];
else
  M = M(:,k);
end

