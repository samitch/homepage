function pdef = replacelabel( pin, shift );
%  function pdef = replacelabel( pin, shift );
%     replace incidences of I in pin with shift(I)
%     

negs = find(pin<0);
if ~isempty(negs)
  pin(negs)=-pin(negs);
end

%expensive negation of rows with elements being changed to zero.
negadd = sparse( size(pin,1), 1 );
z = find(~shift);
if ~isempty(z)
  for k=z'
    [I,J] = find( pin == k );
    %indicate a point *on* the circle by negative
    negadd(I) = ones( size(I,1),1 );
  end
end

shiftpluss = [0 shift];
pdef = sparse([shiftpluss(pin(:,1) + 1); shiftpluss(pin(:,2) + 1)]');

if ~isempty(negs)
  pdef(negs)=-pdef(negs);
end

if find(negadd)
   pdef( find(negadd),: ) = - abs(pdef( find(negadd),: ));
end
