function   [p,e,pdef] = removelabel(p, e, pdef, label);
%  function   [p,e,pdef] = removelabel(p, e, pdef, label);
%    remove label, and make sure identically pdef'ed points are identical
%
     
%forget all but rows with label
[keep, J] = find( pdef == label );
psmall = pdef(keep,:);

psmall = sort(psmall')';  %make sure smaller id is first in each row
key = psmall*[0;max( max(psmall) ) + 1];
[Y, I] = sort(key);  %key(I)=Y
Y=[Y;Y(1)];
orphans = [];
map = 1:size(pdef,1);
for j=1:size(key,1)
  if Y(j) == Y(j+1)
    %p( keep(I(j+1)), : ) = p( keep(I(j)), :);
    %replace references by e to the earlier point, and remove that point
    e( find( e == keep(I(j+1)) ) ) = keep(I(j)));
    orphans = [orphans; keep(I(j+1))];
  end
end;

pdef=replacelabel( pdef, [1:label-1, 0, label+1:max(max(pdef))] );

orphans = [orphans;0]; es=[];
nxt=1;
for k = 1:size(pdef,1);
  if k == orphans(j);
    es = [es;0];
  else
    keepers = [keepers;k];
    es = [es;nxt]; nxt=nxt+1;
  end
end %for
p = p(keepers);
pdef = pdef(keepers);
e = sparse([es(e(:,1)), es(e(:,2))]);
