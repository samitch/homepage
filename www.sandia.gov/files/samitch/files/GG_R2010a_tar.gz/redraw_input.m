function [] = redraw_input(c,r,l,bdycmps)


Pcolor = 'g';
Pcolordot = 'go';

clf
hold off
axis([0 1000 0 1000])
axis('square')
hold on

for k=1:size(r,1)
    plotfast( [r(k);c(k)], Pcolor); 
end
drawnow