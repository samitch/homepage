function [G] = list_to_matrix(G,p);
%    function [G] = list_to_matrix(G,p);
%	convert a list of edges to adjacency matrix
%
nn=size(p,1);
mm=size(G,1);
if mm>0
  G = sparse(G(:,1),G(:,2),1,nn,nn,mm);
  G = G | G' | speye(nn);
elseif nn>0
  G = speye(nn);
else
  G = [];
end
