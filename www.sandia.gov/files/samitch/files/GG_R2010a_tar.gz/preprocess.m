function [cs,ri,is_line,cells] = preprocess2(cs,ri,is_line,components);
%  function [cs,ri,is_line,components] = preprocess2(cs,ri,is_line,components);
%      Preprocess a polygon by adding circles at vertices
%      Also connects up holes (holes = different columns of components)
%

preprocesscolor = 'm';

title('+ Preprocessing Input Vertices +');

if nargin < 4
  components = [1:size(cs,1)]';
end

%find diameter of input for "infinite rays"
cind = find(~is_line); lind = find(is_line);
xdiff = max( [real(cs(cind)) + ri(cind); real(cs(lind)); real(ri(lind))] ) - min( [real(cs(cind)) - ri(cind); real(cs(lind)); real(ri(lind))] ) ; 
ydiff = max( [imag(cs(cind)) + ri(cind); imag(cs(lind)); imag(ri(lind))] ) - min( [imag(cs(cind)) - ri(cind); imag(cs(lind)); imag(ri(lind))] ) ; 
diameter = ydiff + xdiff;

cells=components;


%%%%%%%%%%%%%%%%%%%% CONNECT HOLES %%%%%%%%%%%%%%%%%%%%

%build maximal circles in +x direction from each boundary component,
%  until another cell is hit
for q=2:size(components,2) %assume first component is outer boundary
  [jnk, jnk, cmp] = find(components(:,q)); %just bdy edge component, not cell
  
  %+x direction
  [xmax, kcmp]= max(real(cs(cmp)));
  [cs, ri, is_line, cells] = connect(cs, ri, is_line, cells, cmp, kcmp, diameter, preprocesscolor);
  
end

%%%%%%%%%%%%%%%
%cells
%disp('cells after connecting all holes');
%shortzoom;
%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%% END CONNECT HOLES %%%%%%%%%%%%%%%%%%%%


for j=1:size(components,2)  %for all connected componentes of the boundary
  [jnk,jnk,z] = find(components(:,j)); z=[z;z(1)];
  for m=1:size(z,1)-1;
    k=z(m);
    l = z(m+1);
    if is_line(k) & is_line(l)  %both lines, add circle at their vertex
      disp('corner');


      %%%  find component containing: vertex <==> k,l consecutively %%
      [cmp, q, kind, lind] = findcell(cells,k,l);
      %%%% determine if we need to preprocess ("fix") this vertex 
        need_fix = (size(cmp,1)~=3);  %nothing to do if already right size
	if ~need_fix  %so will handle triangular input/holes correctly
	  need_fix = size(find( is_line(cmp) ),1) == 3;
	end
	if need_fix 
	  is_reflex  = cwi(ri(k),cs(k),cs(l)) >= 0;
	  if is_reflex
	    need_fix = (size(cmp,1) ~= 4) | (size(find(is_line(cmp)),1) ~= 2);
	  end
	end
      %%%%%%

	
     if need_fix

      cells = removecolumn(cells,q); %remove old component

      %% avoid checking against current vertex in fix_contains_vertex
	send = find(is_line(cmp));
	I = find(cmp(send) ~= k);
	vcheck = cs(cmp(send(I)));
      %%

      %REFLEX
      %if reflex(cs([k l]), ri([k l]) )
      if is_reflex  %set up to only send one cell
        [cs, ri, is_line, cells, newcells] = preprocess_reflex(cs, ri, is_line, cells, k, l, cmp, diameter, preprocesscolor, vcheck, 1);
      %NON-REFLEX
      else
	disp('non-reflex');

        [c,r,third]=findtang_component(cmp, cs,ri,[kind;lind],is_line);
	third = cmp(third);
        newcircle = size(cs,1)+1;

        %add bounding line so don't hit other vertices of the edge k,l
	if isempty(c)  %hit far vertices
	  disp('bounding');
          df = cs([k l]) - ri([k l]);
  	  dfsize = [norm(df(1)); norm(df(2))];
	  if dfsize(1)<dfsize(2), 
	    pc = ri(k);
	    pr = ri(k)-i*diameter*df(1)/dfsize(1);
          else
	    pc = cs(l)-i*diameter*df(2)/dfsize(2);
	    pr = cs(l);
	  end
	  [c,r]=threecircles( [cs([k l]);pc], [ri([k l]);pr], [1:3]',[1 1 1]');
	  third=[];
	end

	[c,r,third]=fix_contains_vertex(c, r, third, cs([k;l]), ri([k;l]), vcheck);

	cs=[cs;c];
	ri=[ri;r];
	is_line=[is_line;0];

%%%%%%%%%%%%%%%
	disp('Found a preprocessing circle');
	plotcircle(c,r,preprocesscolor); 
	drawnow;
%	shortzoom;
%%%%%%%%%%%%%%%

	%new components
        newcells = divide_cell(cs,ri,is_line, [],[k;l;third], size(cs,1), cmp, k);

      end %non-reflex

      %integrate new components with old cells
%%%%%%%%%%%%%%%%%
%cells
%newcells
%shortzoom;
%%%%%%%%%%%%%%%%%

      cells = mergecells(cells, newcells);

     end %if need_fix
    end  %if corner between straight edges 
  end %for m
end %for j

drawnow
