function x = dot(v1,v2)
%  function x = dot(v1,v2)
%     Dot product when complex vectors should be treated as a 2x1 vector
%
%
	x = real(v1.*conj(v2));

