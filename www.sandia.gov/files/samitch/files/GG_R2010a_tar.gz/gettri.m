function [centers,radii] = gettri
%  function [centers,radii] = gettri
%	Input triangular R region with mouse
%

Pcolor = 'g';
Pcolordot = 'go';
dotitle = 1;

if nargin < 1
  holdit = 1;
end

disp('Draw an overlap triangle, draw circles in order!');

clf
hold off
axis([0 1000 0 1000])
axis('equal')
hold on

disp('  Input circle center 1.');
[x,y] = ginput(1); %center point
centers =[x+i*y];
plotfast2(x,y,Pcolordot)


disp('  Input circle 1 radius.');
[x,y] = ginput(1); %radius
radii = norm( centers - (x+i*y) );
plotcircle(centers(1),radii(1));

disp('  Input circle center 2.');
[x,y] = ginput(1); %center point
centers =[centers;x+i*y];
plotfast2(x,y,Pcolordot)

radii = [radii; norm(centers(1)-centers(2)) - radii(1)];
plotcircle(centers(2),radii(2));

disp(' Input circle center 3.');
[x,y] = ginput(1); %center point
centers =[centers;x+i*y];
plotfast2(x,y,Pcolordot)

r1 = norm(centers(1)-centers(3)) - radii(1);
r2 = norm(centers(2)-centers(3)) - radii(2);

if r1>r2
  radii = [radii; r1];
else
  radii = [radii; r2];
end
plotcircle(centers(3),radii(3));



