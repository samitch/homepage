function [t,GG,e,p] = greedytriang
%  function [t,GG,e,p] = greedytriang
%	Compute Gabriel Graph and greedy triangulation completion
%

[e,p] = interactivegg;

[t,GG] = GGT(p);

t = list_to_matrix(t,p);
GG = list_to_matrix(GG,p);

disp('GG');
plotgraph(GG,p,1);
disp('greedy triangulation');
plotgraph(t,p,1);

