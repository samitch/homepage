function [a] = cos_of_angles(t,p);
%  function [a] = cos_of_angles(t,p);
%    compute the cosine of the angles in the combinatorial triangulation t
%    with vertex embedding p
%

t=[t t(:,1:2)];  %wrap

a=[];
for j=1:3
  v1 = p(t(:,j))-p(t(:,j+1));
  v2 = p(t(:,j+2))-p(t(:,j+1));
  for k=1:size(v1,1)
    n1(k) = norm(v1(k));
    n2(k) = norm(v2(k));
  end
  v1=v1 ./ n1'; v2 = v2 ./ n2';
  a = [a dot(v1,v2)];
end

format long e
[m I]=min(a);
[m j]=min(m);
disp(sprintf('Min cos_of_angles = %d.',m));
v = sign(m) * atan(m / sqrt(1 - m^2));
disp(sprintf('Corresponding angle is pi( 1/2 + (%d) == %d ) radians.', v/pi,0.5+v/pi));
disp(sprintf('For angle p([%i %i %i]) = ', t( I(j), j:j+2 ) ) );
disp( p( t( I(j), j:j+2 ),: ) )


%average deviation for nearly 90 degree angles
%J=find(a<1e-5);
%m = sum(abs(a(J))) / size(J,1);
%disp(sprintf('Average closeness to 0 = %d', m));

[M I]=max(a);
[M j]=max(M);
disp(sprintf('Max cos_of_angles = %d.',M));
v = atan(sqrt(1 - M^2)/M);
disp(sprintf('Corresponding angle is pi(%d) radians.',v/pi));
disp(sprintf('For angle p([%i %i %i]) = ', t( I(j), j:j+2 ) ) );
disp( p( t( I(j), j:j+2 ),: ) )




