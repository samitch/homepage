function [s]=cwi(p,q,r);
%   function [s]=cw(p,q,r);
%	Compute whether pqr is "right hand ruled" (+1) or "left hand ruled" (-1)
%	row vector

%rotate 90 degrees
r = i*(p-r);
q = q-p; 
s = sign(real(r)*real(q)+imag(r)*imag(q));
  
