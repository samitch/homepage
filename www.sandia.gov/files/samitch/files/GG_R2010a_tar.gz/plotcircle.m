function [] = plotcircle(c,r,color,l);
%  function [] = plotcircle(c,r,color,l);
%  Plot the circle with center c and radius r
%  with color "color" (defaults to cyan)
%
% l is flags for lines (is_line)
%

%use complex numbers for x=real, y=imag, i = sqrt(-1)
if nargin < 3
  color = 'c';
end
if size(color,2)<2, color = [color '-']; end

if nargin < 4
  l=zeros(size(c));
end

%axis('equal');
%hold on

step = pi/60;
for k=1:size(c)
 if l(k) 
   plotline(c(k),r(k),color(1));
 else
  interps = [r(k) * cos( 0:step:pi/2 ) + (i * r(k)) * sin( 0:step:pi/2 )]';
  plotfast(c(k) + interps, color);
  plotfast(c(k) - interps, color);
  plotfast(c(k) + conj(interps), color);
  plotfast(c(k) - conj(interps), color);
 end
end %fork

