function [outward_normal]=two_point_to_line(c,r,l);
%  function [outward_normal]=two_point_to_line(c,r,l);
%     convert lines from two point to point and normal format
%  

outward_normal=c; %non lines leave intact

j=find(l);
outward_normal(j) = i*(c(j)-r(j));
for k=j'
  outward_normal(k) = outward_normal(k) / norm(outward_normal(k));
end
