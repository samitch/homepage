function [p] = getpoints(holdit)
%  function [p] = getpoints(holdit)
%       The polygon drawing is held in the graphics window unless the optional
%	argument "holdit" is zero.

Pcolor = 'g';
Pcolordot = 'go';
dotitle = 1;

if nargin < 1
  holdit = 1;
end

disp('Draw a point set.')
disp('  Left mouse button = a vertex.')
disp('  Center mouse button = last vertex.')

clf
hold off
axis([0 1000 0 1000])
axis('equal')
hold on
if (dotitle)
	title('+ Input point set +'); end;
%axis(axis)
%plotfast(0)

% Initially, the list of points is empty and its length is 0.
p = [];
n = 0; %total number of points inputed

% Loop, picking up the points.
but = 1;
while (but ~= 2)
   [xi,yi,but] = ginput(1);

   p = [p; xi yi];  %add point coordinates to row 
   plotfast2(xi,yi,Pcolordot)
   drawnow; %flush graphics, so things are drawn right away
   %text(xI,yi,int2str(n))
end %while

if ~holdit
  hold off
  axis('auto')
end

 
