function [b]=edgeintersect (p1,p2,q1,q2)
%  function [b]=edgeintersect (p1,p2,q1,q2)
%	Determine if edges cross or not
%


s1 =  cwi(p1, p2, q1) * cwi(p1, p2, q2);
s2 =  cwi(q1, q2, p1) * cwi(q1, q2, p2);

if (s1==-1) & (s2==-1) 
  b = 1;
elseif (s1==0) | (s2==0)
  b = 0;
else
  b = -1;
end
