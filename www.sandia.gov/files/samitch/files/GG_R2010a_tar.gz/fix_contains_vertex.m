function [c,r,third] = fix_contains_vertex(c, r, third, cs, ri, vertices);
%  function [c,r,third] = fix_contains_vertex(c,r, cs, ri, vertices);
%    if a circle (c,r) contains a vertex, shirk the circle, but maintain
%    tangency with the two lines (cs to ri).
%    Assume the two lines meet at a non-reflex angle, ordered from first
%	to second entry in cs,ri.

if isempty(c) 
  return
end

n = two_point_to_line(cs,ri,[1;1]);  %outward normal
t = c+r*n;  %tangent points
q = lineintersect(ri, i*n );
qr = norm( q - t(1) );  %distance from q to tangent point

v = c-q; v=v/norm(v); %vector in direction of line on which center lies

for j=1:size(vertices,1)
  bad = (norm(vertices(j)-c) < r); %incircle
  if ~bad 
    bad = (norm(vertices(j)-q) < qr) & ( cwi(q,t(1),vertices(j)) == 1) & ( cwi(q,t(2),vertices(j)) == -1); %insector
  end

  if bad

    third =[];
    %pretend there is a circle with epsradius>0 at the contained vertex
    %epsradius = norm(q-vertices(j))/k, where k could be anything in (0,1)
    [c,r]=threecircles( [cs; vertices(j)], [ri; norm(q-vertices(j))/3], [1;2;3], [1;1;0] );

    if size(c,1)>1
	keep = 1 + (norm(c(1)-q) > norm(c(2)-q)); %keep smaller
	c=c(keep); 
	r=r(keep);
    end

  end %if bad

end %for j
