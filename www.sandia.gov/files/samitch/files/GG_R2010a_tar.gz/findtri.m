function [trilist, isbdry] = findtri(G,xy);
% function [trilist, isbdry] = findtri(G,xy);
%
%input
% G is edge-incidence matrix (A in drawmesh), xy is vertex coordinates
%
%output
% trilist is the list of three vertices in each triangle, 
% isbdry is true/false vector of "is node i on the boundary?"
%

%By Steve Vavasis 1993.
%
%bug fix Scott Mitchell march 18, 1993.
%Formerly found triangles with two boundary edges twice,
%when additionally the common vertex has index smaller than the
%other two vertices
% e.g. example polygon bern.in

[n,scrap] = size(xy);

xyc = xy(:,1) + i * xy(:,2);

isbdry = zeros(n,1);
trilist = [];

for j = 1 : n
%
% v is the neighbors of j including j.
%
   v = find(G(:,j));
   [l,scrap] = size(v);
%
% vv is the neighbors of j, not including j
%
   vv = v(find(v-ones(l,1)*j));
   l = l - 1;
%
% Compute the neighbors of the angles, and sort.
%
%   j    = current vertex
%   v'
%   vv'
%   l    = number of neighbors = number of edges to vertex j

   angs = imag(log(xyc(vv) - xyc(j) * ones(l,1)));
   [scrap,so] = sort(angs);
%
% Loop through the nodes in order.  Identify the triangles.
% Add all triangles found to trilist.

   %bug fix by Scott Mitchell March 18,1993
   notri = 0;
   if (l<1) %then error, isolated vertex found
	disp(sprintf('Graph G error, vertex %i has no edges',j));
	notri = 1;
   elseif (l==1)
	disp(sprintf('Graph G error, vertex %i has one edge',j));
	notri = 1;
   elseif (l==2) %then first and last triangles have identicle vertex sets
		 %unlike the l>2 case.
	l=1; %needed for adding triangle to trilist below
	ordv = vv(1);
	ordvshift = vv(2);
	mask1 = (G(ordv(1),ordvshift(1)) ~= 0); %edge between incident vertices?
	if (mask1 == 0) 
	  disp('Graph G error, non triangle found'); disp(v');
	end
	isbdry(j) = 1;
   else  % (l>2)

     %find consecutive(by angle) vertices that have an edge between them in G
     ordv = vv(so);  %indices of vertices, sorted by angle
     ordvshift = [ordv(2:l);ordv(1)];  %wrap around, first vertex adj to last
     mask1 = zeros(l,1);
     for t = 1 : l
       mask1(t) = (G(ordv(t),ordvshift(t)) ~= 0);  
       %set mask(t)=1 if there is an edge from vertex ordv(t) to vertex ordv(t+1)
     end;

     %if edges do not form a loop, then vertex j is on the bdy of G
     if sum(mask1) < l
       isbdry(j) = 1;
     end

   end

   if (notri == 0)
     %add triangles to trilist, 
     %to avoid duplicate triangles on trilist, we only add the triangle if 
     %j is the vertex with smallest index among all vertices of the triangle
     jvec = ones(l,1)*j;
     trilist0 = [jvec, ordv, ordvshift];  %candidate triangles
     % mask1 means there is an edge between the other two vertices
     % mask2 means the first vertex's index, j, is less than the second 
     % mask3 means the first vertex's index, j, is less than the third
     mask2 = (jvec < ordv);
     mask3 = (jvec < ordvshift);
     which_triangles = find( mask1.*mask2.*mask3 );
     % matlab 5.0 complains if which_triangles is all zeros
     if ( size(which_triangles) > 0 )
       trilist = [trilist; trilist0(which_triangles,:)];
     end
   end
end
