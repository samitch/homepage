function   [p,e,pdef] = identifylabel(p, e, pdef);
%  function   [p,e,pdef] = identifylabel(p, e, pdef);
%     make sure identically pdef'ed points are identical
%     However, a negative (or zero) pdef means that its a unique point
%	and not to be identified with anyone else, see Y(j)>0 test below
     

pdef = sort(pdef')'; %make sure smaller id is first in each row
key = pdef*[1;max( max(pdef) ) + 1];
[Y, I] = sort(key);  %key(I)=Y
%[jnk, Iinv] = sort(I); %Y(Iinv) = key, I(Iinv) = 1:22


Y=[Y;Y(1)];
orphans = [];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%disp('before merging');
%size(p)
%size(pdef)
%[[1:size(p,1)]' p/100 full(pdef) ]
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for j=1:size(key,1)
  if (Y(j) == Y(j+1)) & (Y(j)>0)
    %p( keep(I(j+1)), : ) = p( keep(I(j)), :);
    %replace references by e to the earlier point, and remove that point
    replace = find( e == I(j+1) );
    e( replace ) = ones(size(replace,1),1)*I(j);
    orphans = [orphans; I(j+1)];
  end
end;

orphans = [sort(orphans);0]; es=[]; %shift for edge
keepers = [];
nxt=1; j = 1;
for k = 1:size(pdef,1);
  if k == orphans(j);
    j=j+1;
  else
    keepers = [keepers;k];
  end
end %for

%%%%%%%%%%%%%%%%%%%%%%%%
%orphans
%if find(orphans)
%  H=plotfast( p(orphans(1:size(orphans,1)-1)),'w*'); %handle for eraseing
%end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

e = list_to_matrix(e,p);  %takes care of duplicate edges
e = matrix_to_list(  e(keepers,keepers) );
p = p(keepers);
pdef = pdef(keepers,:);

%%%%%%%%%%%%%%%%%%%%%%%
%disp('after merging');
%[[1:size(p,1)]' p/100 full(pdef)]
%shortzoom;
%if find(orphans)
%  drawnow; 
%  delete(H);
%end
%%%%%%%%%%%%%%%%%%%%%%%

