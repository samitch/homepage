function [e,p,pdef] = triangquad(centers,radii, is_line, picircle)
%  function [e,p,pdef] = triangquad(centers,radii,is_line,picircle)
%     Triangulate a quad R region, may be degenerate (line), reflex or tricky circles.
%
%non-reflex, but picircle is index of circle with pi arc, or 0
%
% straight lines are specified by 
% centers(i)=a point on the line, and
% radii(i)=a point on the line, such that the outward normal is to the
% right of radii to center
% and flag is_line(i) = 1 (is_line is a 1x4 boolean array).
%

disp('triangquad R');

%convert to outward normal format
p2 = [centers; centers(1)];
centers = two_point_to_line(centers,radii,is_line);

if nargin<4
  picircle = 0;
end;
if nargin<3
  is_line = zeros(4,1);
end

centers=[centers;centers(1)];
radii=[radii;radii(1)];
is_line = [is_line;is_line(1)];

%do opposites cross?
for k=1:2
  cross=0;
  %if a line is opposite a circle
  if ( is_line(k) | is_line(k+2) ) 
    if xor( is_line(k),is_line(k+2) )
      if is_line(k+2) == 0, l=k; c=k+2; else  l=k+2; c=k; end %which is the line
      if abs(point_to_line_dist(centers(c),centers(l),radii(l))) <= radii(c)
          %test for segment, not just line
	  %segment endpoint inside circle
	  if (norm(radii(l)-centers(c)) <= radii(c)) | (norm(p2(l)-centers(c)) <= radii(c))
	     cross = 1;
 	  %segment cuts circle
	  else  
	    pr = centers(c) + radii(c)*centers(l); 
	    cross = (cwi(centers(c),pr,radii(l))*cwi(centers(c),pr,p2(l)) < 1);
	  end
      end
    end
  %else a circle is opposite a circle
  else
    if norm(centers(k) - centers(k+2)) <= (radii(k) + radii(k+2))
      cross=1;
    end
  end
  %quad divided into two overlap triangular R regions
  if cross
      disp('opposite circles cross');
      v = [k:k+2];

      [e1,p1,pdef1]=tritri(centers(v), radii(v), is_line(v)  );
      pdef1=replacelabel(pdef1,v);

      k3=k+3; if k3>4, k3=k3-4; end; %explicit wrap for labels
      v = [k,k3,k+2];
      [e2,p2,pdef2]=tritri(centers(v), radii(v), is_line(v)  );
      pdef2=replacelabel(pdef2,v);

      [p, e, pdef] = identifylabel([p1;p2], [e1;e2+size(p1,1)], [pdef1;pdef2]);

      return;
  end
end %for k

%%tangent point determination
tangs = [];
for k=1:4
  if (is_line(k) | is_line(k+1))
    if xor(is_line(k),is_line(k+1))
      if is_line(k), l=k; c=k+1; else l=k+1; c=k; end %which is the line
      pt = centers(c) + radii(c)*centers(l);
    else
      pt = radii(k+1); %asume clockwise, 
      vertex = k; %see two straight adj sides below
    end
  else
    df = centers(k+1) - centers(k); df=df/norm(df);
    pt = centers(k) + df*radii(k);
  end
  tangs = [tangs; pt];
end
tangs = [tangs(4); tangs];  %tang(1) is ccw to (*preceeds*) the first edge

%two straight edges?
if size(find(is_line(1:4)),1) == 2
  c = find(~is_line(1:4));  %circles
  %straight sides are adjacent, two tritri regions
  if max ( [is_line;0] & [0;is_line] )      
    k = mod_nz(vertex + [0:3]',4)
    km1 = mod_nz(k-1,4)
     
    %% normal lines
    pdef = [k(3) 0; k(4) 0; k km1];
    %        1             2             3:6
    p = [centers(k(3)); centers(k(4)); tangs(k) ];
    e = [3 4; 4 5; 4 6; [1;1;1] [4:6]'; [2;2;2] [3;4;6]];

    %% radial lines for marshall's picture
    %e = [3 4; 4 5; 4 6; [1;1] [5;6]; [2;2] [3;6]];


  %straight sides are opposite
  else
    if radii(c(1)) < radii(c(2)), c=c([2 1]); end %big first
    k = [1:4 1]; kc =k([c(1) c(1)+1 c(2) c(2)+1]);
    %% normal lines
    pdef = [c [0;0]; [kc([4 1:3]); kc([1:4])]'];
    p = [centers(c); tangs( [c(1), c(1)+1, c(2), c(2)+1] )];
    e = [1 2;1 3;1 4; 2*ones(4,1) [3:6]';3 6;4 5];

    %% radial lines for marshall's picture
    %e = [ 1 3;1 4; 2 5; 2 6; 4 5; 6 3];

  end
  plottri(e,p);
  %shortzoom;
  drawnow;
  return;
end

%find circle center, intersection of dual 
%find two dual lines, point and vector formulation
midchord=[]; %chord midpoints
midchordperps=[];
for k=1:4
  midchord = [midchord; (tangs(k+1) + tangs(k)) /2];
  df = tangs(k+1) - tangs(k); df = i*df/norm(df);
  midchordperps = [midchordperps; df];
end
midchord = [midchord;midchord(1)];
midchordperps = [midchordperps;midchordperps(1)];

%find intersection of lines
c = lineintersect(midchord(1:2), midchordperps(1:2));
%plotfast(c,'gx');  %optional, plot a green x at center of cocircularity

%determine if reflex or tricky
  for k=1:4
    if is_line(k) %is c on far side of line?
      b = -sign(point_to_line_dist(c,centers(k),radii(k)));
    else %is c on far side of chord between tangent points
      b = edgeintersect(c,centers(k), tangs(k), tangs(k+1));
      %plotfast([tangs(k);tangs(k+1)],'g-');
    end
    if (b == 0)
      picircle = k;
    elseif (b==-1)  %reflex
      if picircle ~= k  %slightly reflex by roundoff error
        picircle = -k;
      end
    end
  end

%shortzoom; %for stepping

if picircle>=0

  %form combinatorial triangulation
  %One can prove that there is no obtuse angle in this alternate, smaller
  % construction
  zzyk = ~is_line(1:4) - is_line(1:4);  %negative if on the line

  %% normal lines
  pdef = [0 0; [4 1:3; 1:4]'; [[1:4] .* zzyk'; 0 0 0 0]'; zeros(4,2) ];
  %     1  2:5          6:9         10:13
  p = [c;tangs(1:4);centers(1:4);midchord(1:4)];
  e = [ones(8,1) [2:5 10:13]';[6:9]' [10:13]'; [6:9]' [2:5]'; [6:9]' [3 4 5 2]';
        [10:13]' [2:5]'; [10:13]' [3 4 5 2]'];

  %when do we skip the triangles containing the circle center
  degens = is_line(1:4);
  if (picircle>0)
    disp('pi angle circle'); 
    degens(picircle) = 1;
    p(9+picircle) = p(5+picircle); %leave in for copy back line below
  end;
  if find(degens)
    d = find(degens);
    p(5+d) = p(9+d);  %move midchords 
    e = [e; ones(size(d,1),1)  5+d]; 

    %remove midchords
    savvec = [1:9, 9+find(~degens)'];
    e = list_to_matrix(e,p);
    e = matrix_to_list(e(savvec,savvec));
    p = p(savvec);
    pdef = pdef(savvec,:);
  end

  %% radial lines for marshall's picture
  %circs = find(~is_line(1:4));
  %tmp = [[1:4] .* zzyk'; 0 0 0 0]'; tmp=tmp(circs,:);
  %pdef = [ [4 1:3; 1:4]'; tmp ];
  %p = [tangs(1:4);centers(circs)];
  %tmp = [5:size(p,1)]';
  %e = [ tmp circs; tmp mod_nz(circs+1,4)];;
  %if find(degens)
	%d = find(degens);
	%e=[e;d mod_nz(d+1,4)];
  %end;

  plottri(e,p);
  %shortzoom;
  drawnow;

else %reflex
  disp('reflex circle'); 
  %generate cutcircle
  %indices
  c = -picircle;
  %%c + 2 mod_nz 4;
  copp = c+2;  if copp>4, copp=copp-4; end
  %%c + 1 mod_nz 4;
  left = c+1;  if left>4, left=left-4; end
  %%c - 1 mod_nz 4;
  right = c-1;  if right<1, right=right+4; end

  %cutcircle  = circle that cuts into two quad regions
  if is_line(c) | is_line(copp)
    if is_line(c), tc=copp; tl=c; else tc=c; tl=copp; end
    rad = (abs(point_to_line_dist(centers(tc),centers(tl),radii(tl))) - radii(tc))/2;
    pt = centers(tc)+(rad+radii(tc))*centers(tl);
  else
    %center of cutcircle  
    df = centers(c) - centers(copp); df=df/norm(df);    
    pt = ( centers(copp) + centers(c) + df*(radii(copp) - radii(c)) )/ 2;
    rad = norm(pt-centers(c)) - radii(c);
  end

  plotcircle(pt,rad,'y');
  [e1,p1,pdef1] = triangquad([p2(c); pt; p2(copp); p2(right)], [radii(c); rad; radii(copp); radii(right)], [is_line(c); 0; is_line(copp); is_line(right)], 2 );
  [e2,p2,pdef2] = triangquad([p2(c); pt; p2(copp); p2(left)],  [radii(c); rad; radii(copp); radii(left)], [is_line(c); 0; is_line(copp); is_line(left)], 2 );

  %fix up pdef
  %replace pt with 5, merge, then remove 5 (5 is from a temporary circle)
  pdef1 = replacelabel(pdef1, [c 5 copp right]);
  pdef2 = replacelabel(pdef2, [c 5 copp left]);

  [p, e, pdef] = identifylabel([p1;p2], [e1;e2+size(p1,1)], [pdef1;pdef2]);
  pdef = replacelabel(pdef, [1:4 0]);

  return;

end

