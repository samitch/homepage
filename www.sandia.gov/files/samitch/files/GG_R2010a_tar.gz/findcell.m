function [cmp, which_cell, kind, lind] = findcell( cells, k, l );
%  function [cmp, which_cell] = findcell( cells, k, l );
%     find cell in which k and l are consecutive, q is index into cells


	[x,q] = find(cells == k);  %where is edge k found
	for j=1:size(x,1)
	  [zzyk,zzyk,cmp] = find( cells(:,q(j)) );  %a component containing k
	  cmploc=[cmp;cmp(1)];
	  if cmploc(x(j)+1) == l,  %l follows k
	    which_cell = q(j);
	    kind = x(j);
	    lind = kind+1; if lind>size(cmp,1), lind = 1; end;
	    return
 	  end
	end
	cmp = [];
	which_cell=[];
