function [k]=lineintersect(p, v)
% function [k]=lineintersect(p, v)
%    Find the intersection of two lines, point and vector formats
%
  d = p(2)-p(1);
  t2 = (real(d)*imag(v(1)) - imag(d)*real(v(1))) / imag(conj(v(1))*v(2));
  k = p(2) + t2*v(2);
