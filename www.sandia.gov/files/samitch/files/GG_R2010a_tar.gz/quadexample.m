function [] = quadexample


Pcolor = 'g';
Pcolordot = 'go';
dotitle = 1;

if nargin < 1
  holdit = 1;
end

%disp('Draw an R quad, draw circles in order!');

clf
hold off
axis([0 1000 0 1000])
axis('equal')
hold on

%disp('  Input circle center 1.');
x=200; y=200; %[x,y] = ginput(1); %center point
centers =[x+i*y];
plotfast2(x,y,Pcolordot)


%disp('  Input circle 1 radius.');
x=x+100; y=y; %[x,y] = ginput(1); %radius
radii = norm( centers - (x+i*y) );
plotcircle(centers(1),radii(1));

%disp('  Input circle center 2.');
x=x+100; y=y; %[x,y] = ginput(1); %center point
centers =[centers;x+i*y];
plotfast2(x,y,Pcolordot)

radii = [radii; norm(centers(1)-centers(2)) - radii(1)];
plotcircle(centers(2),radii(2));

%disp(' Input circle center 3.');
%[x,y] = ginput(1); %center point
x=x - cos(pi/20)*100.5; y = y + sin(pi/20)*100.5; 
centers =[centers;x+i*y];
plotfast2(x,y,Pcolordot)

r1 = norm(centers(1)-centers(3)) - radii(1);
r2 = norm(centers(2)-centers(3)) - radii(2);

if r1<r2
  radii = [radii; r1];
else
  radii = [radii; r2];
end
plotcircle(centers(3),radii(3));


%disp('  Input line of tangency to circle 3.');
x = x - 10; y=y; %[x,y] = ginput(1); %center point
v = x+i*y-centers(3); c = centers(3)-centers(1); r = -radii(3)+radii(1);
v = v/norm(v);
t = (c*conj(c) - r*r) / (2*(r - real(c) * real(v) - imag(c)*imag(v)));

centers = [centers;centers(3)+t*v];
radii = [radii; t-radii(3)];
plotfast2(real(centers(4)),imag(centers(4)),Pcolordot);
plotcircle(centers(4),radii(4));



%%tangent lines
duals = [];
centers=[centers;centers(1)];
radii=[radii;radii(1)];
for k=1:4
  df = centers(k+1) - centers(k); df=df/norm(df);    
  pt = centers(k) + df*radii(k);
  plotfast(pt,'rx');
  slope = i*df;
  plotfast([pt+1000*slope pt-1000*slope],'r');
  duals = [duals; pt];
end

%center lines
plotfast( [centers(1) centers(3)],'w');
plotfast( [centers(2) centers(4)],'w');


%dual lines
duals = [duals; duals(1)];
for k=1:4 
  df = duals(k+1) - duals(k); df = df/norm(df);
  pt = (duals(k+1) + duals(k)) /2;
  slope = i*df;
  plotfast(pt,'g*');
  plotfast([pt+1000*slope pt-1000*slope],'g');
end

shortzoom;
