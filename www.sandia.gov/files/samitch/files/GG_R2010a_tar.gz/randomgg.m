function [e,g] = randomgg(n);
%   function [e,g] = randomgg(n);
%	Create a Gabriel graph of n random points.
%

if nargin < 1 
  n = 10;
end
if n < 1 
  n = 1;
end

p = rand(n,2)*1000;
e=list_to_matrix(gg(p),p);
plotgraph(e,p,1);
