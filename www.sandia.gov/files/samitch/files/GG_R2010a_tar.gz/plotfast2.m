function handle = plotfast2(X,Y,lc); 

if nargin < 3, 
    lc = 'r-';
end;

h = plot (X, Y, lc, 'erasemode', 'none');

if nargout >= 1
	handle = h;
end;

