function [e,p,pdef]= triangulate_cells(cs, ri, is_line, cells );
%  function [e,p,pdef]= triangulate_cells(cs, ri, is_line, cells );
%    recursively triangulate cells 

  e=[]; p=[]; pdef=sparse([]);
  for j=1:size(cells,2)
    % if want to send only certain elements, but then need a replacelabel
    % [I,J,cmp] = find( cells(:,j) ); 
    %[e1,p1,pdef1] = triangulate_cell(cs(cmp), ri(cmp), is_line(cmp), I );
    [e1,p1,pdef1] = triangulate_cell(cs, ri, is_line, cells(find(cells(:,j)),j) );
    if isempty(e)
      e=e1; p=p1; pdef=pdef1;
    else
      [p,e,pdef]=identifylabel( [p;p1], [e;e1+size(p,1)], [pdef;pdef1] );
    end
  end
