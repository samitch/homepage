function [] = quad



[centers,radii]=getquad;

disp('Draw an R quad, draw circles in order!');


%%tangent lines
duals = [];
centers=[centers;centers(1)];
radii=[radii;radii(1)];
for k=1:4
  df = centers(k+1) - centers(k); df=df/norm(df);    
  pt = centers(k) + df*radii(k);
  plotfast(pt,'rx');
  slope = i*df;
  plotfast([pt+1000*slope pt-1000*slope],'r');
  duals = [duals; pt];
end

%center lines
plotfast( [centers(1) centers(3)],'w');
plotfast( [centers(2) centers(4)],'w');

%dual lines
duals = [duals; duals(1)];
for k=1:4 
  df = duals(k+1) - duals(k); df = df/norm(df);
  pt = (duals(k+1) + duals(k)) /2;
  slope = i*df;
  plotfast(pt,'g*');
  plotfast([pt+1000*slope pt-1000*slope],'g');
end

shortzoom;
