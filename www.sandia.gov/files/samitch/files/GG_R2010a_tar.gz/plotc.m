function [] = plotc(c,r,color)
%  function [] = plotquad(c,r)
%	Plot quad in current graphics window
%

hold on
axis('equal');

if nargin<3 
  for i=1:size(c,1)
    plotcircle(c(i),r(i));
  end;
else
  for i=1:size(c,1)
    plotcircle(c(i),r(i),color);
  end;
end

plotfast(c,'co');

drawnow
