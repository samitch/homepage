function [c,r,third] = findtang (cs, ri, which, is_line, skip, leftpoint, moreleftpoint);
%  function [c,r,third] = findtang (cs, ri, which, is_line, skip,
%  leftpoint, moreleftpoint);
%    find the circle tangent to the two given circles (which),
%    "which" is 2x1 index into cs and ri
%    third is the list of indices of other circles that are tangent
%       to the new circle (third is mx1, m>=1, usually 1).
%
%  Assume that cs(find(is_line)) and ri(find(is_line)) are the
% limiting points on a line segment. (NOT point and outward normal).
% radii x centers right hand rule is used to reconstruct outward normal.
% 
% leftpoint determines leftlimit.
% Leftlimit: We return the circle with signed center to which circle center edge
%   distance closest to Leftlimit without being less than Leftlimit.
%  That is, if leftlimit==0 and the circles are tangent, we return the
%  smallest circle tangent to both circles (on the right side of the circles)
%

if is_line(which(1))
  wind=which([2 1])';
else
  wind=which(1:2)';
end

%Test line for leftlimit, point and normal
if ~is_line(which(1)) & ~is_line(which(2))
  testlinep=cs(which(1));
  testlinen=cs(which(1))-cs(which(2));
  testlinen=i*testlinen/norm(testlinen);
elseif is_line(which(1)) & ~is_line(which(2))
  testlinep=cs(which(2));
  testlinen=-(cs(which(1))-ri(which(1)));
  testlinen=testlinen/norm(testlinen);
elseif ~is_line(which(1)) & is_line(which(2))
  testlinep=cs(which(1));
  testlinen=(cs(which(2))-ri(which(2)));
  testlinen=testlinen/norm(testlinen);
else %two lines
  v=(cs(which)-ri(which));
  v(1)=v(1)/norm(v(1)); v(2)=v(2)/norm(v(2));
  testlinep=lineintersect( ri(which), v );
  testlinen=-i*(v(1)+v(2));
  testlinen=testlinen/norm(testlinen);
end

if nargin < 6
  leftlimit = 0;
else
  if is_line(which(1)) & is_line(which(2))
    leftlimit = point_to_line_dist(leftpoint,testlinen,testlinep);
    if (point_to_line_dist(moreleftpoint,testlinen,testlinep)>leftlimit)
    %reverse of normal limits
      testlinen=-testlinen;
      leftlimit=-leftlimit;
    end;
  else
    leftlimit = point_to_line_dist(leftpoint,testlinen,testlinep);
  end
end

if nargin < 5
  skip= 0;
end

if which(1)<which(2)
  ind=[1:which(1)-1 which(1)+1:which(2)-1 which(2)+1:size(cs,1)];
else
  ind=[1:which(2)-1 which(2)+1:which(1)-1 which(1)+1:size(cs,1)];
end

ind = ind(find(ind ~= skip));

cmin=[]; rmin=[]; t=[]; vmin=Inf;
for j=ind
  send = [wind j];
  [c1,r1]=threecircles (cs(send), ri(send), [1:3]', is_line(send));
  for k=1:size(c1,1)
    v = point_to_line_dist(c1(k),testlinen,testlinep);
%%
%v
%vmin
%drawnow
%%

    %degeneracy: a fourth circle is tangent
    if (v==vmin) & (v<Inf)
      disp('four circles tangent');
      t=[t;j]; 
    end
    %further left circle is found
    if (v>leftlimit) & (v<vmin)
      cmin=c1(k); rmin=r1(k); vmin=v; t=j;
%	disp('its better');
    end
%%
%ginput(1);
%%

  end %for k
end %for j

c=cmin; r=rmin; third=t; 



