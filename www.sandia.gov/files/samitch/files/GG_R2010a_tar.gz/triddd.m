function [] = triddd


Pcolor = 'g';
Pcolordot = 'go';
dotitle = 1;

if nargin < 1
  holdit = 1;
end

disp('Draw an overlap triangle, draw circles in order!');

clf
hold off
axis([0 1000 0 1000])
axis('equal')
hold on

disp('  Input circle center 1.');
[x,y] = ginput(1); %center point
centers =[x+i*y];
plotfast2(x,y,Pcolordot)


disp('  Input circle 1 radius.');
[x,y] = ginput(1); %radius
radii = norm( centers - (x+i*y) );
plotcircle(centers(1),radii(1));


disp(' Input circle center 2.');
[x,y] = ginput(1); %center point
centers =[centers;x+i*y];
plotfast2(x,y,Pcolordot)


disp('  Input circle 2 radius.');
[x,y] = ginput(1); %radius
radii = [radii; norm( centers(2) - (x+i*y) )];
plotcircle(centers(2),radii(2));

disp(' Input circle center 3.');
[x,y] = ginput(1); %center point
centers =[centers;x+i*y];
plotfast2(x,y,Pcolordot)

disp('  Input circle 3 radius.');
[x,y] = ginput(1); %radius
radii = [radii; norm( centers(3) - (x+i*y) )];
plotcircle(centers(3),radii(3));

%wraparound
centers = [centers; centers(1)];
radii = [radii; radii(1)];

%chord bisectors
for j=1:3
  c = norm(centers(j) - centers(j+1));
  x = (radii(j+1)^2 - radii(j)^2 - c^2 ) / (2*c);
  df = centers(j+1)-centers(j); df = df/norm(df);
  pt = centers(j) - x * df; 
  plotfast(pt,'rx');
  slope = i*df;
  plotfast([pt+1000*slope pt-1000*slope],'r');
end

shortzoom;
