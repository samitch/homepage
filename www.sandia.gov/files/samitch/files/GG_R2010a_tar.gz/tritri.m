function [e,p,pdef] = tritri(centers,radii,is_line)
%  function [e,p,pdef] = tritri(centers,radii,is_line)
%       Triangulate a (possibly overlap) triangular R region
%
% One or two straight edges are allowed.
% straight lines are specified by centers(i)=outward unit normal to line,
% radii(i)=a point on the line
% and flag is_line(i) = 1 (is_line is a 1x3 boolean array).
%

%disp('tritri R');
centers=[centers; centers(1)];
radii=[radii; radii(1)];
is_line=[is_line;is_line(1)];

if size(is_line,1)<4 
  disp('two sided region detected');
  centers
  radii
  is_line
end

%chord bisectors/tangents
tangpts=[];
tangdir=[];
for j=1:3

  if is_line(j) | is_line(j+1)
    if xor(is_line(j), is_line(j+1))  %just one line

      if is_line(j), l=j; c=j+1; else l=j+1; c=j; end %which is the line

      %negative distance from circle center to line
      x = point_to_line_dist( centers(c), centers(l), radii(l)); %or radii(c)
      df = centers(l);  %direction
      tangpts=[tangpts; centers(c) - x * df ];
      tangdir=[tangdir;i*df];
    else %two lines
      %tangpts=[tangpts;lineintersect(radii(j:j+1),i*centers(j:j+1))];
      %disp('if this is near zero always, change tritri.m')
      %disp(norm(tangpts(size(tangpts,1)) - radii(j+1)));
      %disp(norm(tangpts(size(tangpts,1)) - radii(j)));
      tangpts=[tangpts;radii(j+1)];
      %tangdir is unimportant now
      %n = centers(j) - centers(j+1); n = n/norm(n);  %normal to angle bisector
      %tangdir=[tangdir;i*n];
      tangdir=[tangdir;i];  %just a placeholder
    end
  else
    df = centers(j+1)-centers(j); 
    cd = norm(df);
    df = df/cd; %direction
    x = (radii(j+1)^2 - radii(j)^2 - cd^2 )/(2*cd); %distance
    tangpts=[tangpts; centers(j) - x * df ];
    tangdir=[tangdir;i*df];
  end
end


%move "center" to line in case of a line circle
l=find(is_line(1:3));  %number of straight edges

if size(l,1) == 1

  %disp('one straight side');

  for k=1:3
    if ~is_line(k) & ~is_line(k+1)
      perps = [tangpts(k)-centers(k);centers(l)]; 
      vec=i*perps; vec(1)=vec(1)/norm(vec(1));
      c = lineintersect( [tangpts(k),radii(l)], vec );
      break;
    end
  end

  %% normal edges  
  pdef = [-l 1:3;0 2 3 1]';
  p = [c; tangpts(1:3)];
  e = [ones(5,1) [2:6]'];
  for k=find(~is_line(1:3))'  %execute 0 or 1 time
    pdef=[pdef;k 0];
    p=[p;centers(k)];
    e=[e; [size(p,1) size(p,1)]' [k+[0 1]]'];
    if k==1
      e(size(e,1)-1,2) = e(size(e,1)-1,2) + 3;
    end
  end

  %% just radii edges, for marshall's picture
  %circs = find(~is_line(1:3))'; tmp=find(is_line(1:3))';
  %pdef = [ [1:3; 2 3 1]'; [circs; 0 0]'];
  %p = [ tangpts(1:3); centers(circs)];
  %e = [ 4 5 4 5 tmp; circs  mod_nz(circs-1,3) mod_nz(tmp-1,3) ]';

elseif size(l,1) == 2

  %disp('two straight sides');

  c = find(~is_line(1:3));  %the one circle
  c1 = c+1; if c1>3, c1 = c1-3; end
  c2 = c+2; if c2>3, c2=c2-3; end

  %% normal edges
  pdef = [c 0; c c1; c1 c2; c2 c]; 
  p = [centers(c); tangpts([c c1 c2])];
  e = [ones(3,1) [2:4]'; 2 3; 3 4];

  %% just radii edges, for marshall's picture
  %pdef = [c 0; c c1; c1 c2; c2 c]; 
  %p = [centers(c); tangpts([c c1 c2])];
  %e = [ones(2,1) [2 4]'; 2 3; 3 4];


elseif size(l,1) == 0

  %disp('zero straight sides (three curved sides)');

  %center point
  c = lineintersect(tangpts(1:2), tangdir(1:2));

  %% normal edges
  pdef = [ [0 0]; [1:3; 2 3 1]'; [1:3; 0 0 0]'];
  p = [c; tangpts(1:3); centers(1:3)];
  e = [ones(6,1) [2:7]'; [2:4]' [5:7]'; [2:4]' [6 7 5]'];

  %% just radii edges, for marshall's picture
  %pdef = [ [1:3; 2 3 1]'; [1:3; 0 0 0]'];
  %p = [ tangpts(1:3); centers(1:3)];
  %e = [ [1:3]' [4:6]'; [1:3]' [5 6 4]'];

end

%optionally display results
plottri(e,p);
%shortzoom;
drawnow
 
