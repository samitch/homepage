function [s]=cw(p,q,r);
%   function [s]=cw(p,q,r);
%	Compute whether pqr is clockwise (+1) or counterclockwise (0)
%	row vector

r = r-p;  
%rotate 90 degrees
rn = zeros(1,2); rn(1) = -r(2); rn(2) = r(1);
q = q-p; 
s = (rn*q')>0;
  
