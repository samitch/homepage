function [e,p] = gg_delete(e,p);
%  function [e] = gg_delete(e,p);
%	Input: e is the Gabriel graph of p. 
%	Output: e is the Gabriel graph of the first size-1 points. 
%
%  	O(n^3) update
%

n = size(p,1);
if n < 2
  p = [];
  e = [];
else 
  p = p(1:n-1,:);
  e = gg(p);
end

