function [e,p] = g();
%   function [] = g();
%	Controlling routine for Gabriel graph

p=getpoints;
e=list_to_matrix(gg(p),p);
plotgraph(e,p,1);

