function [] = plottri(e,p,ecolor,pcolor);
%  [] = function plottri(e,p);
%	plot a graph with edges e and points p
%	e is list format
%
hold on
Tcolordot = 'yx';
Tcolor = 'r-';
if nargin >2
  Tcolor = [ecolor '-'];
end
if nargin >3
  Tcolordot = [pcolor '*'];
%  plotfast(p,Tcolordot);
end

gplotg(list_to_matrix(e,p),[real(p) imag(p)],Tcolor);

