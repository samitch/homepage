function mc = mergecells(cells1, cells2);
%  function mc = mergecells(cells1, cells2);
%	integrate two matrixes of cells
%

    if isempty(cells1)
      mc = cells2;
    elseif isempty(cells2)
      mc = cells1;
    else
      sizediff =  size(cells1,1) - size(cells2,1);
      if sizediff < 0
         cells1 = [cells1; zeros(-sizediff,size(cells1,2))];
      elseif sizediff >0
         cells2 = [cells2; zeros( sizediff,size(cells2,2))];
      end
      mc=[cells1 cells2];
    end
