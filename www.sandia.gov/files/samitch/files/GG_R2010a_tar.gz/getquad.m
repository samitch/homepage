function [centers,radii,is_line] = getquad

Pcolor = 'c';
Pcolordot = 'co';
dotitle = 1;

if nargin < 1
  holdit = 1;
end

disp('Draw an R quad, draw circles in order!');
disp('Draw CIRCLE with LEFT button');
disp('Draw LINES with RIGHT button');

clf
hold off
axis([0 1000 0 1000])
axis('equal')
hold on

disp('  Input circle center {line point} #1.');
[x,y,but] = ginput(1); %center point
plotfast2(x,y,Pcolordot)
if but==1
  is_line = 0;
  centers =[x+i*y];
  disp('  Input circle #1 radius.');
  [x,y] = ginput(1); %radius
  radii = norm( centers - (x+i*y) );
  plotcircle(centers(1),radii(1),Pcolor);
else
  is_line = 1;
  radii = [x+i*y];
  disp('  Input outward normal to line #1.');
  [x,y] = ginput(1); %radius
  centers = (x+i*y) - radii(1); centers = centers/norm(centers);
  plotline(centers(1),radii(1),Pcolor);
end

for k=2:3
 l=k-1;
 if is_line(l)
  disp(sprintf('  Input circle center %i.',k));
 else
  disp(sprintf('  Input circle center {line normal} %i.',k));
 end
 [x,y,but] = ginput(1); %center point
 if (but==1) | is_line(l)
  plotfast2(x,y,Pcolordot)
  is_line = [is_line; 0];
  centers =[centers;x+i*y];
  if is_line(l)
    radii = [radii; -point_to_line_dist( centers(k), centers(l), radii(l) )];
  else
    radii = [radii; norm(centers(l)-centers(k)) - radii(l)];
  end
  plotcircle(centers(k),radii(k),Pcolor);
 else
  is_line = [is_line; 1];
  n = x+i*y - centers(l); n=n/norm(n);
  centers = [centers;n];
  radii =[radii; centers(l) + radii(l)*n];
  plotline(centers(k),radii(k),Pcolor);
 end
end

if is_line(3) | is_line(1)
  disp('  Input circle 4 direction of tangency to circle 3.');
else
  disp('  Input circle {line} 4 direction of tangency to circle 3.');
end
[x,y,but] = ginput(1); %center point
if (but==1) | is_line(3) | is_line(1)

  is_line = [is_line;0];

  if is_line(3)
    v = -centers(3); %tangency direction
    p = x+i*y;
    p = p + v*point_to_line_dist(p,centers(3),radii(3)); %tang pt on #3
  else
    v = x+i*y-centers(3); v = v/norm(v);  %tangency direction
    p = centers(3) + radii(3)*v;  %tangency point
  end

  if is_line(1) %t=how far from p do we go
    t = dot(p-radii(1),centers(1)) / (-dot(v,centers(1))-1);
  else
    c = p - centers(1);
    r = radii(1);
    t = (c*conj(c) - r*r) / (2*(r - real(c) * real(v) - imag(c)*imag(v)));
  end
  centers = [centers; p + t*v];
  radii = [radii; t];

  plotfast2(real(centers(4)),imag(centers(4)),Pcolordot);
  plotcircle(centers(4),radii(4),Pcolor);

else
  is_line = [is_line;1];  

  inp = x+i*y;

  %to get right normal, find which circle is bigger?
  if radii(1) < radii(3), litk = 1; bigk = 3; else litk = 3; bigk = 1; end;
  
  xlate = centers(litk);
  newc = centers(bigk) - xlate;
  n = norm(newc);
  rot = [newc;-i*newc]/n;  %rotate so bigk on positive x axis
  rot = [real(rot),imag(rot)];


  vsav = (radii(litk)-radii(bigk))/n;  %outer normal
  vsav = [vsav,sqrt(1-vsav^2)];  

  v = vsav*rot; %perpendicular vector
  v = v(1)+i*v(2);
  p = radii(litk)*v+xlate;  %tangent point
  
  %compare with inp to get correct outer tangent
  if cwi(centers(1),centers(3),p) ~= cwi(centers(1),centers(3),inp)
    vsav(2)=-vsav(2);
    v = vsav*rot; %perpendicular vector
    v = v(1)+i*v(2);
    p = radii(litk)*v+xlate;  %tangent point
  end


  radii = [radii;p];
  centers = [centers;v];
  
  plotline(centers(4),radii(4));  
  drawnow;
end

