function [cs, ri, is_line, cells, newcells, hitother] = preprocess_reflex(cs, ri, is_line, cells, k, l, cell, diameter, preprocesscolor, vcheck, bdycmp, checkcellonly);

if nargin < 12
  checkcellonly = 0;
end
if checkcellonly
  vcheck = cell( find(is_line(cell)) );
end
if nargin < 11
  bdycmp = [];
end


% hitother is true if new circles hit something not in bdycmp

	disp('reflex vertex');
	%add dividing line
        lastreal = size(cs,1);
        divider = lastreal+1;

        %construct vector in direction of angle bisector
	vk = i*(cs(k)-ri(k)); vk=vk/norm(vk);
	vl = i*(cs(l)-ri(l)); vl=vl/norm(vl);
	v = - vk - vl; v=v/norm(v);

        %biggest circle on k side

	%add angle bisector and line to protect other vertex
	midpoint = (2*ri(k)+cs(k))/3;
  	ri = [ri;cs(k);midpoint-vk*diameter]; 
	cs=[cs;cs(k)+v*diameter;midpoint];
	is_line=[is_line; 1; 1];


	if checkcellonly
	  do_send = [cell;divider;divider+1];
  	  [ck,rk,thirdk] = findtang_component(do_send, cs,ri,[k;divider], is_line, l);
	else
  	  [ck,rk,thirdk] = findtang(cs,ri,[k divider]', is_line, l);
	end
	%shrink so not "tangent" to a vertex of an edge
	[ck,rk,thirdk] = fix_contains_vertex(ck,rk, thirdk, cs([k;divider]), ri([k;divider]),  vcheck);

	%change protecting line and outward normal of angle bisector
	midpoint = (2*cs(l)+cs(k))/3;
	ri(divider:divider+1) = [cs(divider); midpoint];
	cs(divider:divider+1) = [ri(l); midpoint - vl*diameter];

	if checkcellonly
          [cl,rl,thirdl] = findtang_component(do_send,cs,ri,[l;divider], is_line, k);
	else
          [cl,rl,thirdl] = findtang(cs,ri,[l divider]', is_line, k);
   	end
	%shrink so not "tangent" to a vertex of an edge
  	[cl,rl,thirdl] = fix_contains_vertex(cl, rl, thirdl, cs([divider;l]), ri([divider;l]),  vcheck); 


	%keep the smaller of the two circles
	%same size, nothing to do
	if rk<rl %shrink l
	  thirdl = [];
	  rl=rk;
	  cl= ck+i*2*rl*v;
	elseif rl<rk
	  thirdk = [];
	  rk=rl;
	  ck= cl-i*2*rk*v;
	end

	%remove artificial hits
	if ~isempty(thirdk)
	  thirdk = thirdk( find(thirdk<divider) );
	end
	if ~isempty(thirdl)
	  thirdl = thirdl( find(thirdl<divider) );
	end

	%determine if something other than the bdycmp was hit
	hitother=0;
	th=[thirdk;thirdl];
	for j=th'
	  if isempty(find(cell == j))  %j is not in current cell
	    hitother=1;
	  end
	end

	%add data to big arrays
	cs=[cs(1:lastreal);ck;cl];  %preprocess2.m depends on this detail
	ri=[ri(1:lastreal);rk;rl];  %preprocess2.m depends on this detail
	is_line=[is_line(1:lastreal);0;0];
	ckind=divider;
	clind=divider+1;
	

%%%%%%%%%%%%%%%%%
	%plotfast([cs(k); (ck+cl)/2],'w-');  %stop where circles touch
	%disp('two reflex-vertex preprocessing circles added');
%err = [ (rk + point_to_line_dist( ck, two_point_to_line(cs(k),ri(k),1), ri(k)))/rk; (rl + point_to_line_dist( cl, two_point_to_line(cs(l),ri(l),1), ri(l) ))/rl]
	plotcircle([ck],[rk],preprocesscolor); 
	drawnow;
%	shortzoom;
%%%%%%%%%%%%%%%%%%%

	%determine new cells (add two triangular R regions)

        %merge / divide cells as necessary

	[newcellsk, celli, cells] = divide_cell(cs,ri,is_line, [], [k;thirdk], ckind, cell, cells, k);

	%extract the component containing the vertex
	[jnk, jnk, cell]= find(newcellsk(:,celli)); 
        newcellsk = removecolumn(newcellsk, celli);

	plotcircle([cl],[rl],preprocesscolor); 
	drawnow;

 	[newcellsl, split, cells] = divide_cell(cs,ri,is_line, [], [l;ckind;thirdl], clind, cell, cells, ckind);

	newcells = mergecells( newcellsk, newcellsl );

