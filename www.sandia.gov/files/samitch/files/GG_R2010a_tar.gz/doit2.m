%doit, do everything script

echo on

[c,r,l,bdycmps]=get2d;
[c2,r2,l2,cells]=preprocess2(c,r,l,bdycmps);
title('+ Triangulating Cells +');
[e,p,pdef] = triangulate_cells(c2, r2, l2, cells );
disp(sprintf('Output/Input vertex cardinality ratio = %f',size(p)/size(l)));
title('+ Final triangulation +');
%plottri(e,p); drawnow;
E=list_to_matrix(e,p);
P=[real(p) imag(p)];
[t,bdy]=findtri(E,P);
checktri(E, P, t, bdy);
a = cos_of_angles(t,p);
shortzoom;

% clf; plotcircle2(c,r,l,'g'); [c2,r2,l2,cells]=preprocess2(c,r,l,bdycmps);
% plotcircle2(c(bdycmps(1,:)),r(bdycmps(1,:)),l(bdycmps(1,:)),'w'); %debug
% clf; plotcircle2(c2,r2,l2); [e,p,pdef]=triangulate_cells(c2, r2, l2, cells );
% one can replace get2d by getcell to input an already tangent region
% clean up to show just triangulation: clf; plottri(e,p);

