function [c,r,l,bdycmps] = get2d(holdit)
%  function [c,r,l,bdycmps] = get2d(holdit)
%	User draws a polygon with holes in the graphics window using the mouse.

Pcolor = 'g';
Pcolordot = 'go';
dotitle = 1;

if nargin < 1
  holdit = 1;
end

disp('Draw a polygon with holes: draw successive cycles of the boundary.')
disp('The polygon interior is to the right of the directed edges.')
disp('  Left mouse button = first or middle vertex of a cycle.')
disp('  Right mouse button = last vertex of a cycle.')
disp('  Center mouse button = last vertex of the LAST cycle.')
%disp('Point holes may be entered by the right button at the start of a cycle')

clf
hold off
axis([0 1000 0 1000])
axis('square')
hold on
if (dotitle)
	title('+ Drawing input polygon +'); end;
%axis(axis)
%plotfast(0)

% Initially, the list of points is empty and its length is 0.
n = 0; %total number of points inputed
k = 0; %first point of new simply poly (points labeled 1:n)
r = [];
% r are the points of the polygon with holes, in complex notation,
% in the order specified by the user.
c = []; 
% c are the ordered edges of the polygon with holes
% i.e. r(i) to c(i) is the ith edge of the polygon with holes
l = [];
% l is a vector of all 1s. 0s are meant to indicate point holes, but
% this isn't used at present
% 
% bdycmps are the boundary components. Each column contains the
% indices of the edges making up a connected component of the boundary,
% plus perhaps some zeros if the component is shorter than others.

% Loop, picking up the points.
bdycmps = sparse([]); first_k = k+1;
but = 1;
while (but ~= 2)
   [xi,yi,but] = ginput(1);
   newpt = xi+i*yi;

   k = k + 1; %gloabal index
   n = n + 1;

   r=[r;newpt];
   l=[l;1];

   plotfast(r(k),Pcolordot);

   if n>1 
	c=[c;newpt];
	plotfast( [r(k-1);c(k-1)], Pcolor); 
   end;

   if (but ~= 1)   % finish poly
        if n==1  %point hole = circle with radius zero
	  %c=[c;newpt];
	  %r(size(r,1))=0;
	  %l(size(l,1))=0;
          %plotfast(newpt,Pcolordot);
	  disp('sorry, point holes are not supported, ^C and start over');
        else
	  c=[c;r(first_k)];
  	  plotfast( [r(k);c(k)], Pcolor);
        end
	if isempty(bdycmps)
	  bdycmps = [first_k:k]';
	else
          bdycmps = mergecells(bdycmps,[first_k:k]');
 	end
	first_k = k+1;
	n = 0;
   end
   drawnow; %flush graphics, so things are drawn right away
   %text(xI,yi,int2str(n))
end %while


% note, matlab 4.0.beta.3 will only display if there's nothing
% else to do,

%if ~holdit
% hold off
%  axis('equal');
%  axis('auto');
%end

 
