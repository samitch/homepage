function p = sqr(p)
%   function p = sqr(p)
%	returns row by row p*p';
%	input : p is an m by 2 matrix
%	output: p in an m by 1 matrix

p = p .^ 2;
p = p(:,1) + p(:,2);


