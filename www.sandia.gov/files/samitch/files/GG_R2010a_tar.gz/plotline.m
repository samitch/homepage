function [] = plotline(c,r,color);
%  function [] = plotline(c,r,color);
%  Plot the line with point r and normal vector c
%  with color "color" (defaults to cyan)
%

%use complex numbers for x=real, y=imag, i = sqrt(-1)
if nargin < 3 
  color = 'c';
end


plotfast( [r+1000*i*c; r-1000*i*c],color );
plotfast( r, [color 'o'] );
