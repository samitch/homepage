function [a] = mod_nz(a,b)
%  function [a] = mod_nz(a,b)
%    return a mod b in range of 1:b  No Zeros!

big=find(a>b);
a(big)=a(big)-b;

small=find(a<1);
a(small)=a(small)+b;

%
%if a<1
%  a=a+b; 
%elseif a>b
%  a=a-b;
%end

