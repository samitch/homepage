function  [cs, ri, is_line, cells ] = connect(cs, ri, is_line, cells, cmp, kcmp, diameter, preprocesscolor);
%  function  [cs, ri, is_line, cells ] = connect( cs, ri, is_line, cells, kcmp, diameter, preprocesscolor, vcheck );
%  connect cmp to another cell, using a circle at vertex cmp(kcmp)
%
%cmp is bdy component, need to find cell component within connect

pause on

disp('connect');

  %k, l global indices
  lcmp = kcmp+1; if lcmp>size(cmp,1), lcmp=1; end;
  k = cmp(kcmp); l = cmp(lcmp);

  [cell q] = findcell(cells, k, l);
  cells = removecolumn(cells, q);

  alllines = find(is_line);
  vcheck = cs( alllines( find(alllines ~= k) ) );
  [cs, ri, is_line, cells, newcells, hitother] = preprocess_reflex(cs, ri, is_line, cells, k, l, cell, diameter, preprocesscolor, vcheck, cmp );

%%%%%%%%
%newcells
%cells
%disp('final cells for connect.m <key>'); pause;
%%%%%%%%

  if hitother
    cells = mergecells(cells, newcells);
  else

    %disp('NEED to FURTHER CONNECT <key>'); pause;

    %extract component with added circles
    ck = size(cs,1)-1;  %k preceeds l, depends on details of preprocess_reflex
    cl = size(cs,1);
  
    %use twocircles in a findtang like function to determine 
    % a circle that is guaranteed to touch another component
    [cell q] = findcell( newcells, ck, cl);
    
    newcells = removecolumn(newcells,q);
    cells = mergecells(cells, newcells);

    %which circle further left
    if real(cs(ck))>real(cs(cl))
      shooter = ck;
    else
      shooter = cl;
    end

    failed=1;
    while failed
      rmin=Inf; 
      for j= find([1:size(cs,1)] ~= shooter)
        send = [shooter j];
        [c1,r1,wh] = twocircles (cs(send), ri(send), is_line(send), +1);
        if r1<rmin & r1>0
	  rmin = r1;
	  cmin = c1;
	  second = j;
	  whsav = wh;
        elseif r1==rmin & r1<Inf
  	  second = [second;j];
	  whsav = [whsav; wh];
	  disp('tangency to three circles found');
        end;
      end;

      failed =  ~isempty(find(whsav));
      if failed %need to preprocess that vertex first.
        fixvert = find(whsav), wh = whsav(fixvert(1)),
        fixvert=second(fixvert(1));
        [x,y]=find(cells==fixvert); %always just one found
        [jnk, jnk, cell2] = find(cells(:,y));
	cells = removecolumn(cells,y);

        if whsav==2
	  firstedge = x; 
	  secondedge= x+1; if secondedge>size(cell2,1), secondedge=1; end;
        else
	  firstedge = x-1; if firstedge<1, firstedge = size(cell2,1); end;
	  secondedge= x; 
        end
        firstedge = cell2(firstedge);
        secondedge = cell2(secondedge);

        cells = mergecells(cells, cell)
        [cs, ri, is_line, cells, newcells] = preprocess_reflex(cs, ri, is_line, cells, firstedge, secondedge, cell2, diameter, preprocesscolor, cs( alllines( find(alllines~=firstedge) ) ) );
	[cell, q]=findcell(newcells, ck,cl);
	
	if isempty(cell)
	  [cell, q] = findcell(cells, ck, cl);
	  cells=removecolumn(cells,q);
	else
	  failed = 0;
	end;
	cells = mergecells(cells,newcells)

      else 
        cs=[cs;cmin];
        ri=[ri;rmin];
        is_line=[is_line;0];
        %%%%
        plotcircle(cmin,rmin,preprocesscolor); 
        %shortzoom;
        drawnow;
        %%%%

        [newcells, jnk, cells] = divide_cell(cs,ri,is_line, [],[shooter;second], size(cs,1), cell, cells );

        cells = mergecells(cells, newcells);
      end
    end; %while
%%%%%%%%%
%cells
%disp('all done with connecting one component<key>')
%pause
%%%%%%%%%
  end; %~hitother
