function [] = trid


Pcolor = 'g';
Pcolordot = 'go';
dotitle = 1;

if nargin < 1
  holdit = 1;
end

disp('Draw an overlap triangle, draw circles in order!');

clf
hold off
axis([0 1000 0 1000])
axis('equal')
hold on

disp('  Input circle center 1.');
[x,y] = ginput(1); %center point
centers =[x+i*y];
plotfast2(x,y,Pcolordot)


disp('  Input circle 1 radius.');
[x,y] = ginput(1); %radius
radii = norm( centers - (x+i*y) );
plotcircle(centers(1),radii(1));

disp('  Input circle center 2.');
[x,y] = ginput(1); %center point
centers =[centers;x+i*y];
plotfast2(x,y,Pcolordot)

radii = [radii; norm(centers(1)-centers(2)) - radii(1)];
plotcircle(centers(2),radii(2));

disp(' Input circle center 3.');
[x,y] = ginput(1); %center point
centers =[centers;x+i*y];
plotfast2(x,y,Pcolordot)

r1 = norm(centers(1)-centers(3)) - radii(1);
r2 = norm(centers(2)-centers(3)) - radii(2);

if r1>r2
  radii = [radii; r1];
else
  radii = [radii; r2];
end
plotcircle(centers(3),radii(3));



%%tangent lines
for j=2:3
  df = centers(j) - centers(1); df=df/norm(df);    
  pt = centers(1) + df*radii(1);
  plotfast(pt,'rx');
  slope = i*df;
  plotfast([pt+1000*slope pt-1000*slope],'r');
end

%chord bisector
c = norm(centers(2) - centers(3));
x = (radii(3)^2 - radii(2)^2 - c^2 ) / (2*c);
df = centers(3)-centers(2); df = df/norm(df);
pt = centers(2) - x * df;
plotfast(pt,'rx');
slope = i*df;
plotfast([pt+1000*slope pt-1000*slope],'r');


shortzoom;
