function [c,r,third] = findtang_component( component, cs, ri, which, is_line, skip, leftpoint, moreleftpoint);
%function [c,r,third] = findtang_component( component, cs, ri, which, is_line, skip, leftpoint, moreleftpoint);
%   returns a maximal circle tangent to component(which) and component(third)
%

%remove repeated edges
send = remove_repeats(component);
firstsend = find(send == component(which(1)));
secondsend = find(send == component(which(2)));

if nargin > 5
  skipsend = find(send == component(skip));
end

%call with optional arguments
if nargin == 8
  [c,r,thirdsend] = findtang( cs(send), ri(send), [firstsend;secondsend], is_line(send), skipsend, leftpoint, moreleftpoint );
elseif nargin == 6
  [c,r,thirdsend] = findtang( cs(send), ri(send), [firstsend;secondsend], is_line(send), skipsend );
elseif nargin == 5
  [c,r,thirdsend] = findtang( cs(send), ri(send), [firstsend;secondsend], is_line(send));
end


%convert third from send to index into component
third=[];
for j=1:size(thirdsend,1)
  k = find( component == send(thirdsend(j)) ); %indices into component
  if size(k,1)>1  %use true touch to determine where it really hits
    for q=k'
      send = component( [mod_nz(q-1,size(component,1)), mod_nz(q+1,size(component,1)), q] );
      if true_touch( [c;cs(send)],[r;ri(send)],[0;is_line(send)] )
	third=[third;q];
      end
    end
  else %no need for true_touch
    third=[third;k];
  end
end
