function [t_t] = true_touch( centers,  radii, is_line )
% function [t_t] = true_touch( centers,  radii, is_line )
%    does the test circle touch the middle circle of the component in
%    a spot between the first and last circles of the component
%    First parameter is the testcircle, second and third are the 
%    first and last of the component, fourth is the middle circle of 
%    the component.

%determine tangent/touching points:
%chord bisectors/tangents
centers = two_point_to_line(centers,radii,is_line);

tangpts=[];
%tangdir=[];
for j=1:3
  if is_line(j) | is_line(4)
    if xor(is_line(j), is_line(4))  %just one line

      if is_line(j), l=j; c=4; else l=4; c=j; end %which is the line

      %negative distance from circle center to line
      x = point_to_line_dist( centers(c), centers(l), radii(l)); %or radii(c)
      df = centers(l);  %direction
      tangpts=[tangpts; centers(c) - x * df ];
      %tangdir=[tangdir;i*df];
    else %two lines
      tangpts=[tangpts;lineintersect(radii([j 4]),i*centers([j 4]))];
      %tangdir is unimportant now
      %n = centers(j) - centers(4); n = n/norm(n);  %normal to angle bisector
      %tangdir=[tangdir;i*n];
      %tangdir=[tangdir;i];  %just a placeholder
    end
  else
    c = j;
    cd = norm(centers(j) - centers(4));
    x = (radii(4)^2 - radii(j)^2 - cd^2 ) / (2*cd); %distance
    df = centers(4)-centers(j); df = df/norm(df); %direction
    tangpts=[tangpts; centers(c) - x * df ];
    %tangdir=[tangdir;i*df];
  end
end


if is_line(4)
  tp = tangpts(1) + centers(4);
  t_t = (cwi(tangpts(1),tp, tangpts(2)) == 1) &  (cwi(tangpts(1),tp, tangpts(3)) == -1);
else
  t_t = angle_apx(tangpts(2), centers(4), tangpts(3)) < angle_apx(tangpts(2), centers(4), tangpts(1));
end

%t_t
