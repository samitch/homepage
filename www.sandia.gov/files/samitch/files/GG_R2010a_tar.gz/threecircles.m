function [c,r] = threecircles (cs,ri,which,is_line);
% function [c,r] = threecircles (cs,ri,which,is_line);
%    find the circle tangent to the three given circles,
%    which is 3x1 index into cs and ri
%
%  Assume that cs(find(is_line)) and ri(find(is_line)) are the
% limiting points on a line segment. (NOT point and outward normal)
%

% disp('threecircles'); %happens too often to display

centers = cs(which); radii = ri(which); is_line=is_line(which);
%outer normals
normals=(centers-radii)*i;  %r to c right hand rule, garbage for not is_line
for j=1:3, normals(j)=normals(j)/norm(normals(j)); end
p2=centers;
centers(find(is_line)) = normals(find(is_line));

%clf
%hold on
%plotcircle(centers(find(~is_line)),radii(find(~is_line)));
%for j=find(is_line)'
% plot([radii(j),p2(j)],'c-');
%  plot([radii(j),radii(j)+10*centers(j)],'m-');
%end

% chord bisectors for first circle  and second, also first and third.
%  tangpts is where the common chord of the two circles intersects
%  the line between the circle centers.  Format is t*tangpts(1)+tangpts(2),
%  where t is a parameter, the amount we have grown the circles' radii.
%  tangdir is the perpendicular to the edge between centers.
% format is x,y (real,imag), and [t,const]
%
%  Assume cs(1) is not a line
%


if isempty(find(~is_line))
  %there are four tangent circles, this finds the one tangent to the inner sides
  % of the lines
  q = [lineintersect(radii(1:2),i*centers(1:2)); lineintersect(radii([1 3]), i*centers([1 3]))];
  v = centers(1)+centers(2:3);
  c = lineintersect(q,v);
  t = -point_to_line_dist(c,centers(1),radii(1));
  r = abs(t);

else  %swap so first is not a line
  j = find(~is_line); j=j(1);
  if j>1
    ind = [j 1:j-1 j+1:size(is_line,1)];
    centers = centers(ind); radii = radii(ind);
    p2=p2(ind);
    is_line=is_line(ind);
    cs=cs(ind); ri=ri(ind); which=which(ind);
  end


tangpts=[];
tangdir=[];
for j=1:2
    other=j+1; first=1;
    if is_line(other) %one cirlce and one line, parabola projection
      df = -centers(other); %inward normal
      % x is distance from centers(first) to tangpts
      x(j,:)=[-1, -point_to_line_dist(centers(first),centers(other),radii(other))];
      if (x(j,2)<0) 
 	df=-df;
	x(j,2)=-x(j,2);
      end
    else %two circles, hyperbola projection
      df = centers(other)-centers(first); %direction vector between centers
      cd = norm(df);  %center distance
      df = df/cd; %normalize direction
      % x is distance from centers(first) to tangpts
      x(j,2) = (radii(other)^2 - radii(first)^2) / (2*cd) - cd/2; %const term
      x(j,1) = (radii(other)-radii(first))/cd;   %t parameter term
    end
    tangpts=[tangpts; [0,centers(first)] - x(j,:) * df ];  
    tangdir=[tangdir;i*df];
end


%check for circle centers being colinear, recall tangdir already normalized
% in this case there are two tangent circles (or zero), symettric
if min( norm(tangdir(1)-tangdir(2)), norm(tangdir(1)+tangdir(2)) ) < 1e-5
  %1e-5 seems to give best results, with errors at most 1e-6 * radii

  %solve tangpts(1,:) = tangpts(2,:) for t
  d = tangpts(1,:) - tangpts(2,:);
  t = -real(d(2)/d(1));  %may not be fully real by roundoff, and threshhold
  if (t>0) & (t<sum(radii)*1e+10)
    dx=t*x(1,1)+x(1,2);  %scalar
    dy=sqrt((t+radii(1))^2-dx^2)*tangdir(1);  %vector
    c=[t*tangpts(1,1)+tangpts(1,2)];
    c=[c(1)+dy;c(1)-dy];
    r=[t;t];
  else
    c=[];    r=[];    return;
  end
else  %circle centers not colinear, so k calculation is ok
  

  %find intersection point k of the lines through the common chords
    d = tangpts(2,:)-tangpts(1,:);  
    t2 = (real(d)*imag(tangdir(1)) - imag(d)*real(tangdir(1))) / imag(conj(tangdir(1))*tangdir(2));
    k = tangpts(2,:) + t2*tangdir(2);

  %solve for (k-centers(1))^2 = (radii(1)+t)^2,meaning k is on the expanded circle
  % and the three grown circles have a single point in common,
  % thus a circle at k of radius t is tangent to all three circles.
  %quadratic formula, watch for roundoff errors  
  z=k-[0,centers(1)];
  a = z(1)*conj(z(1)) - 1;
  b = 2 * (real(z(1))*real(z(2))+imag(z(1))*imag(z(2)) - radii(1));
  c = z(2)*conj(z(2)) - radii(1)^2;

  q=sqrt((b/(2*a))^2 - c/a);
  s=-b / (2*a);
  t = [s-q; s+q];
  t=t(find(t>0 & imag(t)==0));
  % negative value here means that the tangent circle contains the 
  %   three circles
  % zero means a line circle, which may be discarded for our application
  % complex means that one of the edges is a line and passes between 
  %   the other two circles (complete characterization?)

  %center and radii of circle tangent to all three circles
  c = t*k(1)+k(2);
  r = t;

end

end %case that at least one is a circle

%check that tangent point is between endpoints of lines
ls=find(is_line)';
if ~isempty(ls) & ~isempty(c)
 nogood=zeros(size(c));
 for j=ls
  for k=1:size(c,1)
    if dot(c(k)-p2(j),radii(j)-p2(j))<0 | dot(c(k)-radii(j),p2(j)-radii(j))<0
      nogood(k)=1;
    end
  end
 end
 keep = find(~nogood);
 c=c(keep);
 r=r(keep);
end

% show results
return
if size(c,1)>0
plotcircle(c(1),r(1),'r');
c(1), r(1)
rt=radii;
rt(find(is_line)) = rt(find(is_line)) - t(1)*centers(find(is_line));
rt(find(~is_line)) = rt(find(~is_line)) + t(1);
plotcircle(centers,rt,'r:',is_line);  %should have one point in common
format long e
for j=find(~is_line)', err(j)=norm(c(1)-cs(j)) - r(1) - radii(j); end
for j=find(is_line)', 
  err(j)= abs(point_to_line_dist(c(1),centers(j),radii(j))) - r(1); end
err
end

if size(c,1)>1
plotcircle(c(2),r(2),'b');
c(2), r(2)
if size(t,1)>1, 
  rt=radii;
  rt(find(is_line)) = rt(find(is_line)) - t(2)*centers(find(is_line));
  rt(find(~is_line)) = rt(find(~is_line)) + t(2);
  plotcircle(centers,rt,'g:',is_line);  %should have one point in common
end
for j=find(~is_line)', err(j)=norm(c(1)-cs(j)) - r(1) - radii(j); end
for j=find(is_line)', 
  err(j)= abs(point_to_line_dist(c(1),centers(j),radii(j))) - r(1); end
err
end

shortzoom;

