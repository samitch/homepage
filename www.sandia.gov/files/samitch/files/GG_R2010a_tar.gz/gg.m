function e = gg(p);
%  function e = gg(p);
%	Compute the Gabriel graph of a point set
%	easy n^3 iterative insertion implementation from definition
%	returns list of edges


e = [];  %no edges in graph
if size(p,1) > 1

for i=1:size(p,1)
  e = gg_insert(e, p(1:i,:));
end


%former n^3 algorithm, a bit faster
%for i=1:size(p,1)-1
%  for j=i+1:size(p,1)
    %candidate_edge = [p(i),p(j)];
%    center = (p(i,:) + p(j,:)) / 2;  %Gabriel circle center
%    radius = sqr((p(i,:) - p(j,:)) / 2); %Gabriel circle radius^2
%    contains_point = 0;
%
%    %test if point in circle
%    for k = [1:i-1,i+1:j-1,j+1:size(p,1)]  
%	if sqr(p(k,:) - center) <= radius
%	  contains_point = 1;
%	  break;
%	end
%   end

%    if contains_point == 0 
%	e = [e; i j];
%    end
%  end
%end

end; %size > 1
