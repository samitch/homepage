function [e,p,pdef]= triangulate_cell(cs,ri,is_line, component);
% function [e,p,pdef]=triangulate_cell(cs,ri,is_line,component);
%   assume preprocessing has reduced the genus to 0
%   component is an ordered list of adjacent circles/line segments, not wrapped
%   a line segment appears only once, but a circle may appear more than once
%
%

% TO DO
% look at ways to pass less information (just the circles of this component)

%minimal size, go ahead and triangulate the R region
m = size(component,1);
disp(sprintf('Cell size %i.',m));

if m < 5, 
  send = component;
  if m==4 
    [e,p,pdef]=triangquad( cs(send) ,ri(send), is_line(send));
  else
    [e,p,pdef]=tritri(two_point_to_line(cs(send),ri(send),is_line(send)) ,ri(send), is_line(send));
  end
  pdef = replacelabel(pdef, full(send'));
  return; 
end;  

%start by looking for maximal circle  with adjacent circles
first=1; second=2;
no_good = 1; %flag to keep searching

while no_good 
%find a third circle tangent to the first two on correct side

  [c,r,third] = findtang_component( component, cs, ri, [first;second], is_line );

  disp('a maximal circle is tangent to:');
  disp(full(component([first second third']))');

  %c
  %r
  %shortzoom;

  %Consecutive? if so, grow third circle from outer two adjacent circles

  prev= mod_nz(first-1,m);
  next = mod_nz(second+1,m);

  %if consecutive
  if size(third,1)==1 & ( third == prev | third == next )
    disp('****  CONSECUTIVE  ****'); %%%

    if third == prev
      skip=first;
      newfirst=prev;
      newsecond=second;
    else
      skip=second;
      newsecond=next;
      newfirst=first;
    end

    %below doesn't work for two parallel lines, detect this here
    pss=component([newfirst,newsecond]);
    if is_parallel(cs(pss),ri(pss),is_line(pss))
	first=first+1; %will never wrap around
	second=mod_nz(first+1,m);
	%by not changing no_good, we will repeat the computation
    else
	%only one call needed
	%recall proof that we only have tri and quad R regions
	no_good = 0; 

	first=newfirst;
	second=newsecond;

    	[c,r,third] = findtang_component( component, cs, ri, [first;second], is_line,  skip, c, cs(component(skip)));

    	disp('a maximal non-consecutive circle is tangent to:');
    	disp(full(component([first second third']))')
    	%c
    	%r
    	%shortzoom;
    end
  else
    disp('****   NON-CONSECUTIVE   ****');
    no_good = 0; %success
  end

end %while no_good

%add circle
cs=[cs;c];
ri=[ri;r];
is_line=[is_line;0];

%%%%
  plotcircle(c,r); 
  %shortzoom;
  drawnow;
%%%%

%divide cell into size(third)+1 component
newcircleindex = size(cs,1);
cells = divide_cell(cs,ri,is_line,[first;second;third], [], size(cs,1), component,first);


%recursively triangulate cell components
[e,p,pdef] = triangulate_cells(cs, ri, is_line, cells );
pdef = replacelabel( pdef, [1:newcircleindex-1 0] );

end %function
