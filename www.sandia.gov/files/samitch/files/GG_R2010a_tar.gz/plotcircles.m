function [] = plotcircles(e,p);
%  function [] = plotcircles(e,p);
%  Plot the circles with diameters the edges of e
%

%use complex numbers for x=real, y=imag, i = sqrt(-1)

if size(e,1) > 0 

%make sure no space between real and complex parts: interpreted as two element
centers =  [p(e(:,1),1) + p(e(:,2),1)+i*(p(e(:,1),2) + p(e(:,2),2))]/2;
radii= sqr([p(e(:,1),1) - p(e(:,2),1),   p(e(:,1),2) - p(e(:,2),2) ]/2) .^ 0.5;

step = pi/20;
for k=1:size(e,1)
  interps = [radii(k) * cos( 0:step:pi/2 ) + (i * radii(k)) * sin( 0:step:pi/2 )]';
  plotfast(centers(k) + interps, 'c-');
  plotfast(centers(k) - interps, 'c-');
  plotfast(centers(k) + conj(interps), 'c-');
  plotfast(centers(k) - conj(interps), 'c-');
end %fork

end %if size(e,1)>0
