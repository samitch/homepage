p=[];
for j=0:0.2:2*pi
  p2 = cos(j)+i*sin(j);
  p=[p;p2 angle(1,0,p2)];
end
  
