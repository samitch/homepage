function [c,r,wh] = twocircles(centers,radii,is_line, direction);
%  function [c,r,wh] = twocircles(centers,radii,is_line);
%   
%  find the circle tangent to the given two circles, with 
%  center with the same y coordinate as the center of the first circle
%  direction = +1, -1,  go in +x or -x direction
%
%  wh is flag, if wh==1 then c touches vertex radii(2) of line 2
% 	       if wh==2 then c touches vertex centers(2) of line 2
%	       if wh==0 then c is tangent to circle or line 2
%

wh = 0;
if is_line(2) %always first argument is a line

  n = two_point_to_line(centers(2),radii(2),is_line(2));
  r = dot(n,centers(2)-centers(1)-direction*radii(1))/(1 + real(n));
  c = centers(1)+direction*(r+radii(1));

  %check if we are between endpoints
  c2 = c+r*n;
  if cwi(c,c2,centers(2)) * cwi(c,c2,radii(2)) == 1  %points to right and left
%    if norm(c,centers(2))<norm(c,radii(2)), wh = 2; tv=centers(2); 
    if norm(c - centers(2))<norm(c - radii(2)), wh = 2; tv=centers(2); 
    else, wh = 1; tv=radii(2); end;
 
    k2 = real(centers(1)) - real(tv) + direction*radii(1);
    r = (  (imag(centers(1)) - imag(tv))^2 + k2^2 ) / ( - 2*direction*k2 );
    c = centers(1)+direction*(r+radii(1));
  end

else %both circles
  k2 = real(centers(1)) - real(centers(2)) + direction*radii(1);
  r = (  radii(2)^2 - (imag(centers(1)) - imag(centers(2)))^2 -k2^2 ) / ( 2*(direction*k2 - radii(2))  );
  c = centers(1)+direction*(r+radii(1));
end

