function [e] = gg_insert(e,p);
%  function [e] = gg_insert(e,p);
%	Input: e is the Gabriel graph of the first size-1 points
%	    of p.
%	Output: e is the Gabriel graph of p.
%
%  	O(n^2) update
%

n=size(p,1);
m=size(e,1);

if n<2 
  e = [];
else

%Delete edges interfered with by p(n,:)
if m>0
  circleradii = sqr( p(e(:,1),:) - p(e(:,2),:) ); %actually diameter^2
  centers = ( p(e(:,1),:) + p(e(:,2),:) )/2;
  nradii = 4*sqr([centers(:,1) - p(n,1), centers(:,2) - p(n,2)]); %diameter^2

  I = find(circleradii<nradii);
  e = e(I,:);
end

%Old Delete edges interfered with by p(n,:)
%enew = [];
%for i=1:m
%  center = (p(e(i,1),:) + p(e(i,2),:)) / 2;  %Gabriel circle center
%  radius = sqr((p(e(i,1),:) - p(e(i,2),:))/2); %Gabriel circle radius^2
%
%  if sqr(p(n,:) - center) > radius
%    enew = [enew; e(i,:)];
%  end
%end

% Think about adding edges
centers =  [p(1:n-1,1) + p(n,1), p(1:n-1,2) + p(n,2)] / 2;
radii =  sqr([p(1:n-1,1) - p(n,1), p(1:n-1,2) - p(n,2)])/4;
%actually radii squared

%don't completely vectorize, as on average can short cut work
% by finding a violating center early on
for i=1:n-1
  contains_point = 0;
  for k=[1:i-1,i+1:n-1]
	if sqr(p(k,:) - centers(i,:)) <= radii(i);
	  contains_point = 1;
	  break;
	end
  end

  if contains_point == 0
    e = [e; i n];
  end
end

%% old
%for i=1:n-1
%  center = (p(i,:) + p(n,:)) / 2;  %Gabriel circle center
%  radius = sqr((p(i,:) - p(n,:))/2); %Gabriel circle radius^2%
%


end  %if n>1
