function [] = plotcircle2(c,r,l,color);
%  function [] = plotcircle2(c,r,l,color);
%  Plot the circle with center c and radius r
%  with color "color" (defaults to cyan)
%
% l is flags for lines (is_line)
%
% this takes lines in two point format
%

if nargin < 3
  l=zeros(size(c));
end

if nargin < 4
  color = 'c';
end

cind=find(~l);
plotcircle(c(cind),r(cind),color,l(cind));

lind=find(l);
for k=lind'
  plotfast([c(k);r(k)],[color '-']);
end



