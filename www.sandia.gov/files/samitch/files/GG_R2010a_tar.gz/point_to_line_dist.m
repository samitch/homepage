function x = point_to_line_dist( p, lc, lr );
%  function x = point_to_line_dist( p, lc, lr );
%    Compute signed distance from a point p to a line ( lc=normal, lr=point )
%
    x= dot(p-lr,lc);

