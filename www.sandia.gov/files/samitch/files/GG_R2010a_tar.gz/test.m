function test

echo on

Pcolor = 'c';
Pcolordot = 'co';
dotitle = 1;

if nargin < 1
  holdit = 1;
end

disp('Draw a quad cell, draw circles in clockwise order!');
disp('Draw CIRCLE with LEFT button');
disp('Draw LINES with RIGHT button');

clf
hold off
axis([0 1000 0 1000])
axis('equal')
hold on

centers=zeros(4,1); radii=centers; is_line=centers;

for j=[1 3]
disp(sprintf('  Input circle center {line point} # %i.',j));
 [x,y,but] = ginput(1); %center point
 plotfast2(x,y,Pcolordot)
 if but==1
  is_line(j) = 0;
  centers(j) =[x+i*y];
  disp(sprintf('  Input circle %i radius.',j));
  [x,y] = ginput(1); %radius
  radii(j) = norm( centers(j) - (x+i*y) );
  plotcircle(centers(j),radii(j),Pcolor);
 else
  is_line(j) = 1;
  radii(j) = [x+i*y];
  disp('  Input outward normal to line #1.');
  [x,y] = ginput(1); %radius
  centers(j) = (x+i*y) - radii(j); centers(j) = centers(j)/norm(centers(j));
  plotline(centers(j),radii(j),Pcolor);
 end
end

done=0;
while ~done
for k=[2 4]
 prv=k-1;
 nxt=mod_nz(k+1,4);

   if is_line(prv) | is_line(nxt)
     disp(sprintf('  Input circle center %i.',k));
   else
     disp(sprintf('  Input circle center {line normal} %i.',k));
   end

 [x,y,but]=ginput(1);

 if but==2, done=1;return; end;

 if (but==1) | is_line(prv) | is_line(nxt)
  if is_line(prv)
    v = -centers(prv); %tangency direction
    p = x+i*y;
    p = p + v*point_to_line_dist(p,centers(prv),radii(prv)); %tang pt on #3
  else
    v = x+i*y-centers(prv); v = v/norm(v);  %tangency direction
    p = centers(prv) + radii(prv)*v;  %tangency point
  end

  if is_line(nxt) %t=how far from p do we go
    t = dot(p-radii(nxt),centers(nxt)) / (-dot(v,centers(nxt))-1);
  else
    c = p - centers(nxt);
    r = radii(nxt);
    t = (c*conj(c) - r*r) / (2*(r - real(c) * real(v) - imag(c)*imag(v)));
  end
  centers(k) = [p + t*v];
  radii(k) = [t];

  plotfast2(real(centers(k)),imag(centers(k)),Pcolordot);
  plotcircle(centers(k),radii(k),Pcolor);

else %add a last line
  is_line(k) = 1; 

  inp = x+i*y;

  %to get right normal, find which circle is bigger?
  if radii(nxt) < radii(prv), litk = nxt; bigk = prv; 
  else litk = prv; bigk = nxt; end;
  
  xlate = centers(litk);
  newc = centers(bigk) - xlate;
  n = norm(newc);
  rot = [newc;-i*newc]/n;  %rotate so bigk on positive x axis
  rot = [real(rot),imag(rot)];


  vsav = (radii(litk)-radii(bigk))/n;  %outer normal
  vsav = [vsav,sqrt(1-vsav^2)];  

  v = vsav*rot; %perpendicular vector
  v = v(1)+i*v(2);
  p = radii(litk)*v+xlate;  %tangent point
  
  %compare with inp to get correct outer tangent
  if cwi(centers(nxt),centers(prv),p) ~= cwi(centers(nxt),centers(prv),inp)
    vsav(2)=-vsav(2);
    v = vsav*rot; %perpendicular vector
    v = v(1)+i*v(2);
    p = radii(litk)*v+xlate;  %tangent point
  end


  radii(k) = [p];
  centers(k) = [v];
  
  plotline(centers(k),radii(k));  
  drawnow;
end

end %for k

r=radii;
c=centers;
%convert to two point format
for j=find(is_line)'
  nxt = j+1; if nxt>k, nxt=1; end
  prv = j-1; if prv<1, prv=k; end
  n = centers(j); %outer normal
  
  r(j)=centers(prv)+radii(prv)*n;
  c(j)=centers(nxt)+radii(nxt)*n;
end


[e,p]=triangulate_cell(c,r,is_line,[1:4]');
shortzoom;
clf;

plotcircle(centers([1 3]),radii([1 3]), 'c',is_line([1 3]));
axis([-200 1200 -200 1200]);
axis('equal');
plotfast(centers([1 3]),'co');



end %while not done

