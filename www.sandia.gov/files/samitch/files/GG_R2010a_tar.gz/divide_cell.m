function [cells, distinguished_cell, allcells] = divide_cell(cs,ri,is_line, comphits, globalhits, newcircleindex, component, allcells, distinguished_side);
%  function [cells, distinguished_cell, allcells] = divide_cell(cs,ri,l,comphits, globalhits, newcircleindex, component, allcells, distinguished_side);
%     divide component (global index) up into a number of cells (global index),
%     based on a circle touching globals hit circles (global index)
%     and component circles (component relative index)
%
%  distinguished_cell returns the index into cells of the cell containing
%    the distinguished side as the first side


%disp('divide cell');

if nargin < 9
  distinguished_side = 0;  %distinguished_cell will be [];
end

if nargin < 8
  allcells = [];  %used when we know we only have one component
end
  
  cuts=[]; %which elements of component are hit
  loops=[]; %which components to append
  touches=[]; 
  globalhits = remove_repeats(globalhits);
  for j=1:size(globalhits,1)
    k = find(component == globalhits(j));
    if isempty(k)
	touches=[touches, globalhits(j)];
    else
      if size(k,1)>1 
  	%disp('NEED TO DETERMINE WHICH ARC OF THE CIRCLE IT HITS!');
        cmpwrap = [component(size(component,1)); component; component(1);];
        for j = k'+1
  	  send = [newcircleindex cmpwrap([j-1 j+1 j])'];
 	  if true_touch( cs(send), ri(send), is_line(send) );
	    k = j-1;
	    break;
	  end
        end
      end
      cuts = [cuts;k];
    end
  end
  cuts = sort([cuts; comphits]);

  %wrap
  cuts = [cuts; cuts(1)+size(component,1)];
  componentwrap =[component;component];

  rowlen=size(component,1)+1; %max possible size
  cells=sparse(rowlen,3);  %about usual size
  for j=1:size(cuts,1)-1
    newcomponent = [componentwrap(cuts(j):cuts(j+1)); newcircleindex];
    cells(1:size(newcomponent,1),j) = newcomponent;
  end;

  %remove columns of all zeros
  [I J] = find(cells);
  rlim = max(I); clim=max(J);
  cells = cells(1:rlim,1:clim);

  %return the cell containing distinguished side as the first side
  distinguished_cell = find(cells(1,:) == distinguished_side);


  allcellkills = []; cellkills = [];
  for z = touches'  %z(1) is global index of touched circle not in component

    for q=1:size(allcells,2)
      touch = find( allcells(:,q) == z);
      if ~isempty(touch)

      [jnk jnk testcmp] = find(allcells(:,q));
      for zz=touch'
        send = [newcircleindex testcmp([mod_nz(zz-1,size(testcmp,1))  mod_nz(zz+1,size(testcmp,1)) zz])'];
        if (send(2) == send(3)) | true_touch(cs(send),  ri(send), is_line(send))

          %find which new component with newcircleindex is correct
          for qq=1:size(cells,2)
            [jnk jnk newcmp] = find(cells(:,qq));
	    w=find(newcmp == newcircleindex);
	    for ww=w'
 	      send = [testcmp(zz) newcmp([mod_nz(ww-1,size(newcmp,1)) mod_nz(ww+1,size(newcmp,1)) ww])'];
	      if (send(2)==send(3)) | true_touch( cs(send),  ri(send), is_line(send) )

	        %compute new component indicies, newcmp is a loop
	        loop = [newcmp(1:ww); testcmp([zz:size(testcmp,1) 1:zz]); newcmp(ww:size(newcmp,1))];

	        %store q,qq, to remove newcmp from cells 
		% and testcmp from allcells
	        cellkills = [cellkills; qq];
	        allcellkills = [allcellkills; q];

	        %add loop to allcells
	        cells = mergecells( cells, loop );

	      end %if touched allcell circle touches a new cell
  	    end %for ww
          end %for qq
        end %if newcircle true_touches allcell
      end %for zz
      end %if ~isempty(touch)
    end %for q
  end %for z


  %remove merged components 
  if ~isempty(allcellkills)
    allcells=removecolumn(allcells, allcellkills);
    cells=removecolumn(cells, cellkills);
  end;

