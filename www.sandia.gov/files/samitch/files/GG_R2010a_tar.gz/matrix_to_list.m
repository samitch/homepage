function [e] = matrix_to_list(e);
%  function [e] = matrix_to_list(e);
%  	convert from sparse matrix to list format

[i,j]=find(e);
s = find(i<j);
e=[i(s) j(s)];


