function [] = interact;
%  function [] = interact;
%    provide an easy way to change the interactiveness of display of
%    the non-obtuse triangulation algorithm.
%    Comment out the below lines, or leave one uncommented.

drawnow;
shortzoom;


