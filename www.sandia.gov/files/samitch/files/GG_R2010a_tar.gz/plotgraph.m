function []= plotgraph(e,p,docircles,allowzoom);
%   function [] = plotgraph(e,p,docircles,allowzoom);
%

%control variables
doP = 1;
dotitle = 1;
t = '+ Graph +';
doaxis = 1;
res=1e-6;  %how small can we zoom in

if nargin < 3
  docircles = 0;
end
if nargin < 4
  allowzoom = 1;
end

%colors
Pcolor = 'g'; %Polygon input color
Pcolordot = 'go'; Pnocolor = 'g.';

%figure out axis limits, draw axis
if (p ~= [])
  xmax = max(p(:,1));  xmin = min(p(:,1));  
  ymax = max(p(:,2));  ymin = min(p(:,2));
elseif (xy ~= [])
  xmax = max(xy(:,1));  xmin = min(xy(:,1));
  ymax = max(xy(:,2));  ymin = min(xy(:,2));
else
  xmax = 1000; xmin = 0;
  ymax = 1000; ymin = 0;
end

if (ymax-ymin) > (xmax -xmin)
	diff = ymax-ymin;
else
	diff = xmax -xmin;
end
if diff == 0 
  diff = 1;
end

buff = diff/4;
xmax = xmin + diff + buff; 
ymax = ymin + diff + buff; 
xmin = xmin - buff;
ymin = ymin - buff;

clf
hold off
%erase previously drawn axis
if (doaxis==0) axis('off'); end; 
axis('equal') 
axis([xmin xmax ymin ymax])
if (dotitle)  title(t); end
hold on

gplotg(e,p);
hold on
if (docircles) plotcircles(matrix_to_list(e),p); end;
if (dotitle)  title(t); end
if (doP)	
    plotfast2( p(:,1),p(:,2),Pcolordot );
end;
drawnow;

if (allowzoom)
  shortzoom;
end
