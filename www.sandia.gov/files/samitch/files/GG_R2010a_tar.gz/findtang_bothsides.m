function [c,r,third] = findtang (cs,ri,which,is_line,leftlimit);
% function [c,r,third] = findtang (cs,ri,which,is_line);
%    find the circle tangent to the two given circles (which),
%    "which" is 2x1 index into cs and ri
%    third is the list of indices of other circles that are tangent
%       to the new circle (third is mx1, m>=1, usually 1).
%
%  Assume that cs(find(is_line)) and ri(find(is_line)) are the
% limiting points on a line segment. (NOT point and outward normal).
% radii x centers right hand rule is used to reconstruct outward normal.
%
% Leftlimit: We return the circle with signed center to which circle center edge
%   distance closest to Leftlimit without being less than Leftlimit.
%  That is, if leftlimit==0 and the circles are tangent, we return the
%  smallest circle tangent to both circles (on the right side of the circles)
%
if nargin < 5 
  leftlimit = 0
end

if is_line(which(1))
  switched=-1; %for leftlimit comparison
  wind=which(2:1);
else
  switched=1;  %for leftlimit comparison
  wind=which(1:2);
end

if which(1)<which(2)
  ind=[1:which(1)-1 which(1)+1:which(2)-1 which(2)+1:size(cs,1)]
else
  ind=[1:which(2)-1 which(2)+1:which(1)-1 which(1)+1:size(cs,1)]
end

%assume which are tangent for now
cmin=[Inf; Inf]; rmin=[Inf; Inf]; 
for j=ind
  send = [wind j];
  [c1,r1]=threecircles (cs(send), ri(send), send, is_line(send));
  for k=1:size(c1,1)
    if is_line(which(1))
	side = 1
    else
      if is_line(which(2))
	p2 = cs(which(1))+i*(cs(wind(2))-ri(wind(2)));
      else
        p2 = cs(which(2));
      end
      side = (cwi(centers(which(1)),p2,c1(k))+3) /2
    end
    if r1(k)<rmin(side)
      rmin(side)=r1(k); cmin(side)=c1(k);  t = j;
    elseif r1(k)=rmin(side)
      t(k,:)=[t(k,:),j];  %cotangent
    end
    
  end %for k
end %for j

if sideonly 
  if rmin(1)<Inf 
     keep = 1
  else 
    keep=[];
  end    
else
  keep = find(rmin<Inf);
end

c=cmin(keep); r=rmin(keep); third=t(keep,:);


