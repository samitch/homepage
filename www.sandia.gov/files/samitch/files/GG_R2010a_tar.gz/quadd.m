function [] = quadd


Pcolor = 'g';
Pcolordot = 'go';
dotitle = 1;

if nargin < 1
  holdit = 1;
end

disp('Draw an overlap R quad, draw circles in order!');

clf
hold off
axis([0 1000 0 1000])
axis('equal')
hold on

disp('  Input circle center 1.');
[x,y] = ginput(1); %center point
centers =[x+i*y];
plotfast2(x,y,Pcolordot)


disp('  Input circle 1 radius.');
[x,y] = ginput(1); %radius
radii = norm( centers - (x+i*y) );
plotcircle(centers(1),radii(1));

disp('  Input circle center 2.');
[x,y] = ginput(1); %center point
centers =[centers;x+i*y];
plotfast2(x,y,Pcolordot)

radii = [radii; norm(centers(1)-centers(2)) - radii(1)];
plotcircle(centers(2),radii(2));

disp(' Input circle center 3.');
[x,y] = ginput(1); %center point
centers =[centers;x+i*y];
plotfast2(x,y,Pcolordot)

r1 = norm(centers(1)-centers(3)) - radii(1);
r2 = norm(centers(2)-centers(3)) - radii(2);

if r1<r2
  radii = [radii; r1];
else
  radii = [radii; r2];
end
plotcircle(centers(3),radii(3));


disp(' Input circle center 4.');
[x,y] = ginput(1); %center point
centers =[centers;x+i*y];
plotfast2(x,y,Pcolordot)


disp(' Input circle 4 radius.');
[x,y] = ginput(1); %radius
radii = [radii; norm( centers(4) - (x+i*y) )];
plotcircle(centers(4),radii(4));

%chord bisectors/tangent lines
duals = [];
centers=[centers;centers(1)];
radii=[radii;radii(1)];
for j=1:4
  c = norm(centers(j) - centers(j+1));
  x = (radii(j+1)^2 - radii(j)^2 - c^2 ) / (2*c);
  df = centers(j+1)-centers(j); df = df/norm(df);
  pt = centers(j) - x * df; 
  plotfast(pt,'rx');
  slope = i*df;
%  plotfast([pt+1000*slope pt-1000*slope],'r');
  duals = [duals; pt];
end

%center lines
%plotfast( [centers(1) centers(3)],'w');
%plotfast( [centers(2) centers(4)],'w');

%dual lines
duals = [duals; duals(1)];
for k=1:4 
  df = duals(k+1) - duals(k); df = df/norm(df);
  pt = (duals(k+1) + duals(k)) /2;
  slope = i*df;
  plotfast(pt,'g*');
  plotfast([pt+1000*slope pt-1000*slope],'g');
end

shortzoom;
