function handle = plotfast(X,lc); 

if nargin < 2, 
    lc = 'r-';
end;

h = plot (X, lc, 'erasemode', 'none');

if nargout >= 1
	handle = h;
end;

