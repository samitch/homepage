function [a]=angle(p,q,r);
%  function [a]=angle(p,q,r);
%    compute an approximation to angle pqr in range [-3,1]

c=p-q; c=c/norm(c);
d=r-q; d=d/norm(d);
a=dot(c,d);  %signed cosine of angle

if cwi(p,q,r)==1
  a = -2-a;
end
