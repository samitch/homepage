%doit.m: user-interface to draw a polygon, triangulate it, 
%        and analyze the triangles.

echo off

[c,r,l,bdycmps]=get2d(1);
[c2,r2,l2,cells]=preprocess(c,r,l,bdycmps);
title('+ Triangulating Cells +');
[e,p,pdef] = triangulate_cells(c2, r2, l2, cells );
disp(sprintf('Output/Input vertex cardinality ratio = %f',size(p)/size(l)));
%shortzoom;
title('+ Final triangulation +'); 


%plottri(e,p);  %%
%drawnow;
E=list_to_matrix(e,p);
P=[real(p) imag(p)];
[t,bdy]=findtri(E,P);
%% checktri(E, P, t, bdy);  %wast of time for demo
a = cos_of_angles(t,p);
shortzoom;

% clf; axis([0 1000 0 1000]); axis('equal'); hold('on'); plotcircle2(c,r,l,'g');% [c2,r2,l2,cells]=preprocess(c,r,l,bdycmps);
% plotcircle2(c(bdycmps(1,:)),r(bdycmps(1,:)),l(bdycmps(1,:)),'w'); %debug
% clf;plotcircle2(c2,r2,l2,'g'); [e,p,pdef]=triangulate_cells(c2,r2,l2,cells);
% one can replace get2d by getcell to input an already tangent region
% clean up to show just triangulation: clf; plottri(e,p); shortzoom;

