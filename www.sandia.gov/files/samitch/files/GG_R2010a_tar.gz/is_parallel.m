function [p]= is_parallel(c,r,l);
%  function [p]= is_parallel(c,r,l);
%    determine if two segments are parallel, returns p = 0 or 1
%    segments are given in two point format
%

if l %both are lines and not circles, so compare tangent unit vectors
  v = c-r; 
  if xor( (real(v(1)) < 0 ), (real(v(2)) < 0 ) ), v(2)=-v(2); end; %sgn
  v(1) = v(1) / norm(v(1));
  v(2) = v(2) / norm(v(2));
  p = max(v(1)-v(2)) < 1e-8;  %roundoff
else
  p = 0;
end

