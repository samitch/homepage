function [cs,ri,is_line,cells] = preprocess2(cs,ri,is_line,components);
%  function [cs,ri,is_line,components] = preprocess2(cs,ri,is_line,components);
%      Preprocess a polygon by adding circles at vertices
%      Also connects up holes (holes = different columns of components)
%

preprocesscolor = 'm';

title('+ Preprocessing Input Vertices +');

if nargin < 4
  components = [1:size(cs,1)]';
end

%find diameter of input for "infinite rays"
cind = find(~is_line); lind = find(is_line);
xdiff = max( [real(cs(cind)) + ri(cind); real(cs(lind)); real(ri(lind))] ) - min( [real(cs(cind)) - ri(cind); real(cs(lind)); real(ri(lind))] ) ; 
ydiff = max( [imag(cs(cind)) + ri(cind); imag(cs(lind)); imag(ri(lind))] ) - min( [imag(cs(cind)) - ri(cind); imag(cs(lind)); imag(ri(lind))] ) ; 
diameter = ydiff + xdiff;

cells=components;


%%%%%%%%%%%%%%%%%%%% CONNECT HOLES %%%%%%%%%%%%%%%%%%%%

%build a maximal circle in +x and -x direction from each boundary component,
%  until another cell is hit
%cmp is bdy component, need to find cell component within connect
for q=2:size(components,2) %assume first component is outer boundary
  [jnk, jnk, cmp] = find(components(:,q)); %just edge component
  
  %+x direction
  [xmax, kcmp]= max(real(cs(cmp)));

  vcheck=[];
  send = find(is_line);
  I = find(send ~= cmp(kcmp) );
  vcheck = cs(send(I));

  [cs, ri, is_line, cells ] = connect( cs, ri, is_line, cells, cmp, kcmp, diameter, preprocesscolor, vcheck );
  
  %-x direction
  [xmin, kcmp] = min(real(cs(cmp)));
  [cs, ri, is_line, cells ] = connect( cs, ri, is_line, cells, cmp, kcmp, diameter, preprocesscolor, vcheck );
end

%%%%%%%%%%%%%%%%%%%% END CONNECT HOLES %%%%%%%%%%%%%%%%%%%%


for j=1:size(components,2)  %for all connected componentes of the boundary
  [jnk,jnk,z] = find(components(:,j)); z=[z;z(1)];
  for m=1:size(z,1)-1;
    k=z(m);
    l = z(m+1);
    if is_line(k) & is_line(l)  %both lines, add circle at their vertex
      disp('corner');


      %%%  find component containing: vertex <==> k,l consecutively %%
      [cmp, q] = findcell(cells,k,l);
      %%%% determine if we need to preprocess ("fix") this vertex 
        need_fix = (size(cmp,1)~=3);  %nothing to do if already right size
	if ~need_fix  %so will handle triangular input/holes correctly
	  need_fix = size(find( is_line(cmp) ),1) == 3;
	end
	if need_fix 
	  is_reflex  = cwi(ri(k),cs(k),cs(l)) >= 0;
	  if is_reflex
	    need_fix = (size(cmp,1) ~= 4) | (size(find(is_line(cmp)),1) ~= 2)
	  end
	end
      %%%%%%

	
     if need_fix
cells
[q k l]
disp('about to fix <key>');
      cells = removecolumn(cells,q); %remove old component

      %% avoid checking against current vertex in fix_contains_vertex
      vcheck=[];
	send = find(is_line);
	I = find(send ~= k);
	vcheck = cs(send(I));
      %%

      %REFLEX
      %if reflex(cs([k l]), ri([k l]) )
      if is_reflex
        [cs, ri, is_line, cells, newcells] = preprocess_reflex(cs, ri, is_line, cells, k, l, cmp, diameter, preprocesscolor, vcheck);
      %NON-REFLEX
      else
	disp('non reflex');

        [c,r,third]=findtang(cs,ri,[k;l],is_line);
        newcircle = size(cs,1)+1;

        %add bounding line so don't hit other vertices of the edge k,l
	if isempty(c)  %hit far vertices
	  disp('bounding');
          df = cs([k l]) - ri([k l]);
  	  dfsize = [norm(df(1)); norm(df(2))];
	  if dfsize(1)<dfsize(2), 
	    pc = ri(k);
	    pr = ri(k)-i*diameter*df(1)/dfsize(1);
          else
	    pc = cs(l)-i*diameter*df(2)/dfsize(2);
	    pr = cs(l);
	  end
	  [c,r]=threecircles( [cs([k l]);pc], [ri([k l]);pr], [1:3]',[1 1 1]');
	  third=[];
	end

	[c,r,third]=fix_contains_vertex(c, r, third, cs([k;l]), ri([k;l]), vcheck);

	cs=[cs;c];
	ri=[ri;r];
	is_line=[is_line;0];

%%%%%%%%%%%%%%%
	disp('Found a preprocessing circle');
	plotcircle(c,r,preprocesscolor); 
	drawnow;
%	shortzoom;
%%%%%%%%%%%%%%%

	%new components
        [newcells, jnk, cells] = divide_cell2(cs,ri,is_line, [],[k;l;third], size(cs,1), cmp, cells );

      end %non-reflex

      %integrate new components with old cells
      cells = mergecells(cells, newcells);

%%%%%%%%%%%%%%%
%	cells
%	disp('<any key>')
%	pause
%%%%%%%%%%%%%%%%

     end %if need_fix
    end  %if corner between straight edges 
  end %for m
end %for j

drawnow
