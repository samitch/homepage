function []=shortzoom
%  function []=shortzoom
%   graphics display zoom in/out

hold on
disp('');
but = 1; 
res = 10e-6;
a=axis;
x1=a(1); y1=a(3); x2=a(2); y2=a(4);
while ( (but==1) | (but==3) )
   disp('Press the left button to frame a zoom area, right to zoom out, center to quit.');
   [x,y,but]=ginput(1);
   %zoom into box
   if (but == 1)
        x1=x; y1=y;
	disp('Press the left button again to frame the zoom area.');
        [x2,y2]=ginput(1); % get other bdy of square
	disp('wait');
        %make sure display is square
        bsize = max( [abs(x2-x1) abs(y2-y1) res ]);
        x1 = min( [x1 x2] ); y1 = min( [y1 y2] );
        x2=x1+bsize; y2=y1+bsize;
        axis( [x1 x2 y1 y2]);
	drawnow;
    %zoom out
   elseif (but == 3)
	disp('wait');
        diffx = x2-x1; diffy = y2-y1;
        x1=x1-2*diffx; x2=x2+2*diffx;
        y1=y1-2*diffy; y2=y2+2*diffy;
        axis( [x1 x2 y1 y2] );
	drawnow;
   end
end
disp('done')
%axis('square')

