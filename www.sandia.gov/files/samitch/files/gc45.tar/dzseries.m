function [td, tdz, js, jsz, h2, h2z] = dzseries(x,y)
%verify z-series 

d = abs(x-y);
p = x+y;
q = d/p;
u = max(x,y);
v = min(x,y);
z = v/u;
if (u == 0)
    z = 0;
    q = 1;
end

t = 1000;
r = 1-z;

td = d * d / (2*p);
tdz = 0;
for (n=2:t)
    tdz = tdz + r^n / 2^n;
end
tdz = u * tdz;


js = u * log2( 2*u / p ) / 2 + v * log2( 2*v / p ) / 2;
if (v == 0)
    js = u / 2;
end
    
jsz = 0;
for (n=2:t)
    jsz = jsz + r^n * (1 - 1 / 2^(n-1)) / (n*(n-1));
end
jsz = u * jsz / (2 * log(2));

h2 = 0.5 * (sqrt(x) - sqrt(y) )^2 ;
h2z = 0;
for (n=2:t)   
    f = 1;
    for m=1:n
        f = f * (( m- 1.5) / m);
    end;    
    h2z = h2z - f * r^n;
end
h2z = h2z * u;
    
    
