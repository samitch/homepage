function [E]=euclideanDistance(M, p)
% function [E]=euclideanDistance(M)
% compute the euclidean = 2-norm distance between rows of M
% INPUT: 
%   M: m x n matrix
%   p: norm to use, defaults to 2
% Output:
%   E: m x m matrix of Euclidean (if p==2) distances
%
if exist('p') == 0
    p = 2;
end;

[m n] = size(M);
E = zeros(m,m);

% could speed this up by a factor of 2 by exploiting symettry...

for i = 1:m
    DD = (M - repmat( M(i,:), m, 1 ));
    for j = 1:m
        E(j, i) = norm( DD(j,:), p );
    end
end
