function [diff] = compareOrder(D,H)
% function [diff] = compareOrder(D,H)
%   compare the order of points by nearness for two distance functions D
%   and H
% INPUT:
%   D: m x m matrix of distances
%   H: m x m matrix of distances
% OUTPUT:
%   diff : m x m vector of differences in rank order
% For each row, sort the colums by nearness, giving a rank order
% permutation of the columns. 
% Return the difference between the two permutation matrices.

[m n] = size(D);
if m ~= n
    disp('D must be square');
    return;
end
[i j] = size(H);
if i ~= m || j ~= n
    disp('H must be the same size as D');
    return
end

[DY, DI] = sort(D,2,'ascend')
[HY, HI] = sort(H,2,'ascend')

to do - look up rank order, not index

diff = DI - HI;