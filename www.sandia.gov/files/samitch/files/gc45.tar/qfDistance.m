function [DD] =  qfDistance(M)
% compute the quadratic form distance between rows of M
% INPUT: 
%   M: m x n matrix, rows of point coordinates, typically whose row sum is 1, n large
% Output:
%   D: m x m matrix of quadratic form distances
%   For clarity, we normalize each so that the maximum possible distance 
%   is 1.
%   The normalization constant is independent of dimension.
%

[m, n] = size(M);
DD = zeros(m,m);

C = zeros(m,n); %coordinate differences
Cd = zeros(m,n); %coordinate difference distances^(p/2)
DDD = zeros(1,m);    
    
p = 2;% could make this a parameter
pp = p; 

% for all rows 
for i = 1:m
    
    C = (M - repmat( M(i,:), m, 1 ));
    Cd = C .^ (pp / 2);  
    
    dmax = max(max(Cd));
    zzyk this is not right, don't use this
    D = 1 - Cd ./ dmax; % this line is not right. it should be the "ground" distance, not the intra-coordinate distance
    
    for j = 1:m
        DDD(j) = (Cd(j,:) * D * Cd(j,:)').^(1/pp);
    end
    DD(i,:) = DDD / (2^(1/pp));
    
end
