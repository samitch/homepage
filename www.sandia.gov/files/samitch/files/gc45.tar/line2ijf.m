function []=line2ijf(i,j,steps,g,s,varargin)
% i, j row vector of indices
X = (i-1)/(steps-1);
Y = (j-1)/(steps-1);
G = zeros(size(X));
for k=1:size(X,2)
    G(k) = g(i(k),j(k));
end
% project down the line x=y
% line(X - Y, G, 'Color', s, varargin{:});
% to show only one half
p = find(X > Y);
line( X(p) - Y(p), G(p), 'Color', s, varargin{:});