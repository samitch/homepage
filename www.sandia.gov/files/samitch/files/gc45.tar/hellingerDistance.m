function [H G]=hellingerDistance(M)
% function [H G]=hellingerDistance(M)
% compute the hellinger distance between rows of M
% INPUT: 
%   M: m x n matrix, typically whose row sum is 1, n large
% Output:
%   H: m x m matrix of Helling distances
%      Hellinger projects points onto a spherical section, then 
%      a. takes straight Euclidean distances
%   G: m x m matrix of geodesic distances
%      b. takes geodesic distance on sphere, rather than a.
%
%      Note that G is simply a monotonic scaling of H, albeit non-linear.
%
%   For clarity, we normalize each so that the maximum possible distance 
%   is 1.
%   The normalization constant is independent of dimension.
%
M = sqrt(M); % row sum of squares is now 1

[m n] = size(M);
H = zeros(m,m);

% could speed this up by a factor of 2 by exploiting symettry...

for i = 1:m
    H(:, i) = sqrt( sum( (M - repmat( M(i,:), m, 1 )).^2, 2 ) ); 
end

G = (4 / pi) * asin(H/2);
%= 2 * asin(H/2) unnormalized

H = H / sqrt(2);