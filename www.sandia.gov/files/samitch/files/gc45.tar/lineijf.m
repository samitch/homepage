function []=lineijf(i,j,steps,g,s,varargin)
% i, j row vector of indices
X = (i-1)/(steps-1);
Y = (j-1)/(steps-1);
G = zeros(size(X));
for k=1:size(X,2)
    G(k) = g(i(k),j(k));
end
%line(X, Y, G, 'Color', s);
%line(X, Y, G, 'Color', s, 'LineWidth',3);
line(X, Y, G, 'Color', s, varargin{:});
