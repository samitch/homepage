function [X]=meanSquaredDistance(M, use_expected)
% function [X]=meanSquaredDistance(M)
% compute the means-squared distance between rows of M
% = sum (d/p)^2, where d = u-v, p = u+v, and sum is over all vector
% components
% INPUT: 
%   M: m x n matrix, typically whose row sum is 1, n large
% Output:
%   X: m x m matrix of meanSquared distances
%
[m n] = size(M);
X = zeros(m,m);

if nargin<2
    use_expected = 0;
end

% could speed this up by a factor of 2 by exploiting symettry...

if (use_expected)
    for i = 1:m
        
        P2 = (M + repmat( M(i,:), m, 1 ));
        P2z = find(P2 == 0);
        D2 = (M - repmat( M(i,:), m, 1 ));
        R2 = (D2 ./ P2).^2;
        R2(P2z) = 0;
        
        % modify the following line to take into account the number of
        % non-zeros in a row.
        % it helps smooth things out a little bit, but not a lot
        % X(:, i) = sum( R2, 2 ) /n;    
        for j=1:m            
            n = nnz(P2(j,:));            
            if (n>0)                
                X(j,i) = sum( R2(j,:) ) / n;
            else
                X(j,i) = 0;
            end
        end 
    end
else
    for i = 1:m       
        D2 = (M - repmat( M(i,:), m, 1 )).^2; 
        X(:, i) = sum( D2, 2 ) /n;
    end
end