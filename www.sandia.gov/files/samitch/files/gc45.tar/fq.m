% fq.m
% plot pure functions of q

rr = 1000;
qh = zeros(rr,1); % hellinger
qj = zeros(rr,1); % js
qc = zeros(rr,1); % chi^2

for i=1:rr
    q = (i-1) / (rr-1);
    qh(i) = 1 - sqrt((1- q^2));
    qj(i) = ( (1+q) * log2( 1 + q ) + (1-q) * log2(1-q) ) / 2;
    qc(i) = q^2;
end
q = [(1:rr) - 1]' / (rr-1);
qj(1) = 0; % q=0
qj(rr) = 1; % q=1


% difference
dqcj = (qc-qj);
dqch = (qc-qh);
dqjh = (qj-qh);

% ratio
qqcj = (qj./qc);
qqch = (qh./qc);
qqjh = (qh./qj);

% relative difference
rqcj = (qc-qj) ./ (qc+qj);
rqch = (qc-qh) ./ (qc+qh);
rqjh = (qj-qh) ./ (qj+qh);

% plot f
close
hold on
plot(q,qc,'g');
plot(q,qj,'r');
plot(q,qh,'b');
axis('square');

% plot diff
plot(q,dqcj ,'r');
plot(q,dqch,'b');
plot(q,dqjh,'k');

% plot ratio
hold on
plot(q,qqcj ,'r');
plot(q,qqch,'b');
plot(q,qqjh,'k');

% plot rel diff
plot(q,rqcj ,'r');
plot(q,rqch,'b');
plot(q,rqjh,'k');

% 1-q

close
hold on
axis('square');

% plot f
plot(1-q,qc,'g');
plot(1-q,qj,'r');
plot(1-q,qh,'b');


% plot diff
plot(1-q,dqcj ,'r');
plot(1-q,dqch,'b');
plot(1-q,dqjh,'k');

% plot ratio
hold on
plot(1-q,qqcj ,'r');
plot(1-q,qqch,'b');
plot(1-q,qqjh,'k');

% plot rel diff
plot(1-q,rqcj ,'r');
plot(1-q,rqch,'b');
plot(1-q,rqjh,'k');

