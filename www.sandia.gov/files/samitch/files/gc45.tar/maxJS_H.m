% maxJS_H.m 
% determine the maximum of JS - H_s^2 
r = 100;
d = zeros(r,r);
dr = zeros(r,r);
for i=1:r
    x = (i-1)/(r-1);    
    for j=1:r        
        y = (j-1)/(r-1);
        if (x==y)
            d(i,j) = 0;
            dr(i,j) = 0;
        else
            % absolute difference
            js = 2 * ( x * log2( (2 * x) / (x+y) ) + y * log2( (2*y) / (x+y)) );
            h = 2 * (sqrt(x) - sqrt(y))^2;
            d(i,j) = js - h;
            % relative difference
            dr(i,j) = d(i,j) / (js+h); % (js + h);
        end
    end
end
d(1,:) = 0;
d(:,1) = 0;
dr(1,:) = 0;
dr(:,1) = 0;
% surf(d);
% surf(dr);

% search near y = 0.055, x = 1

rr = 1000000;
dd = zeros(rr,1);
yy = zeros(rr,1);
x = 1;
for i=1:rr
    y = 0.05 + 0.01 * (i-1) / (rr -1);            
    yy(i) = y;
    dd(i) = 2 * ( x * log2( (2 * x) / (x+y) ) + y * log2( (2*y) / (x+y)) - (sqrt(x) - sqrt(y))^2 );
end
[max_dd i] = max(dd)
yy(i)


