function [z]=jsiLog(x,y)
% function [z]=jsi(x,y)
% return the Jansen-Shanon value for scalars x and y
% that is, compute js for one component of the vector
% Using logs
z = 0;
if (x > 0)
    z = z + x * log2( (2 * x) / (x + y) );
end
if (y > 0)
    z = z + y * log2( (2 * y) / (x + y) );
end

