function [Mu] = normed(M)
% function [Mu] = normed(M)
% normalize the rows of M
% INPUT:
%   M: m x n matrix, m points with n coordinates each. 
%      E.g. mixture model with row sum = 1
% OUTPUT:
%   Mu: m x n matrix, for each row sum of squares is 1

Mu = zeros(size(M));
[m,n]= size(M);
for i=1:m
    Mu(i,:) = M(i,:) / norm(M(i,:));
end