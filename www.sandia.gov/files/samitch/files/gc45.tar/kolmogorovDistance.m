function [D]=kolomogorovDistance(M)
% function [D]=kolomogorovDistance(M)
% compute the kolomogorov measure between rows of M
% INPUT: 
%   M: m x n matrix, typically whose row sum is 1, n large
% Output:
%   D: m x m matrix of kolomogorov distances

[m n] = size(M);
D = zeros(m,m);

%M
for i = 1:m
    %i
    Mi = repmat( M(i,:), m, 1);
    
    D(i,:) = max( abs( M - Mi ), [], 2 );
    
end
