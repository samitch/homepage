%compareDistances.m

% compute distance from u to all other points in the triangle 3-simplex

% u = point we're taking distances from
% u=[0.89, 0.1 0.01];
% u=[0.2 0.3 0.5]
% u =[1 1 1] / 3
% u =[0.5 0.5 0];
u=[1 0 0]
% u = u / sum(u),
% v = point we're taking distances to, varying over entire 
% "the triangle" = convex combinations of (1,0,0) (0,1,0) (0,0,1)
% for best results, use steps2 = 2^n + 1, else picture may have a "bite" taken out
% of it
%steps2 = 17; 
steps2 = 33; 
%steps2 = 65; 

% distance types to compute
%all distances are scaled linearly to vary between 0 and 1
% we consider vectors normalized by taking square-roots and by linearly
% scaling them by dividing by norm.
%note Er2 == H2
num_distances = 9;
Cr2 = zeros(steps2,steps2); %cosine similarity between unit (sqrt) vectors
Er2 = zeros(steps2,steps2); %Euclidean distance between unit (sqrt) vectors
Cu2 = zeros(steps2,steps2); %cosine similarity between unit (norm) vectors
Eu2 = zeros(steps2,steps2); %Euclidean distance between unit (norm) vectors
C2 = zeros(steps2,steps2); %cosine similarity between mixture models - makes no sense
E2 = zeros(steps2,steps2); %Euclidean distance between mixture models
H2 = zeros(steps2,steps2); %Hellinger distance between mixture models
G2 = zeros(steps2,steps2); %Geodesic Hellinger distance between mixture models
J2 = zeros(steps2,steps2); %Jensen-Shannon distance between mixture models
Chi2 = zeros(steps2,steps2); %ChiSquared distance between mixture models
M2 = zeros(steps2,steps2); %MeanSquared distance between mixture models
T = zeros(steps2,steps2); %Tanimoto distance between mixture models
K = zeros(steps2,steps2); %Kolmogorov between mixture models
N1 = zeros(steps2,steps2); %1-norm 
% K = N1 in 3-d mixture models. Need 4-d or higher before they are
% different.

%plotting widgets
X2 = zeros(steps2,steps2); % x coordinates for projected 3-simplex
Y2 = zeros(steps2,steps2); % y coordinates for projected 3-simplex
num_points = round( steps2*steps2/2 );
xyz = zeros(num_points, 3+num_distances); % rows = x,y,z coordinates and distance values 
% X and Y are the same as X2 and Y2, just as a vectors

%compute coordinates and distances over the triangle
r=0; % counter, number of sample points generated, running total in loop
for i = 1:steps2
    x = (i-1)/(steps2-1);
    for j = 1:steps2        
        y = (j-1)/(steps2-1);
        z = 1 - x - y;        
        if z < 0          
            if (j>1)                                
                Cr2(i,j) = Cr2(i,j-1);                
                Er2(i,j) = Er2(i,j-1);
                Cu2(i,j) = Cu2(i,j-1);                
                Eu2(i,j) = Eu2(i,j-1);
                C2(i,j)  = C2(i,j-1);                
                E2(i,j)  = E2(i,j-1);
                H2(i,j)  = H2(i,j-1);
                G2(i,j)  = G2(i,j-1);
                J2(i,j)  = J2(i,j-1);
                Chi2(i,j)= Chi2(i,j-1);
                M2(i,j)  = M2(i,j-1);
                T(i,j)   = T(i,j-1);
                K(i,j)   = K(i,j-1);
                N1(i,j)  = N1(i,j-1);
                
                X2(i,j) = X2(i,j-1);
                Y2(i,j) = Y2(i,j-1);                
            else
                Cr2(i,j) = Cr2(i-1,j);
                Er2(i,j) = Er2(i-1,j);                
                Cu2(i,j) = Cu2(i-1,j);
                Eu2(i,j) = Eu2(i-1,j);                
                C2(i,j)  = C2(i-1,j);
                E2(i,j)  = E2(i-1,j);                
                G2(i,j)  = G2(i-1,j);
                H2(i,j)  = H2(i-1,j);
                J2(i,j)  = J2(i-1,j);
                Chi2(i,j)= Chi2(i-1,j);
                M2(i,j)  = M2(i-1,j);
                T(i,j)   = T(i-1,j);
                K(i,j)   = K(i-1,j);
                N1(i,j)  = N1(i-1,j);
                
                X2(i,j) = X2(i-1,j);
                Y2(i,j) = Y2(i-1,j);

            end    
            continue
        end
        r = r+1;
        v=[x, y, z];
        u_norm = u/norm(u);
        v_norm = v/norm(v);
        u_sqrt = sqrt(u);
        v_sqrt = sqrt(v);
        
        % unit
        Er2(i,j)=norm(u_sqrt-v_sqrt) / sqrt(2); 
        Cr2(i,j)=1 - u_sqrt*v_sqrt';
%         if (Cr2(i,j) < 0)
%             disp(['Cr2 ', num2str(Cr2(i,j))]);
%             x, y, z, u_sqrt, v_sqrt,             
%         end
        
        Eu2(i,j)=norm(u_norm-v_norm) / sqrt(2); 
        Cu2(i,j)=1 - u_norm*v_norm';
        
        % mixture
        E2(i,j)=norm(u-v) / sqrt(2); 
        C2(i,j)= 1 - u*v';
        
        [H G]=hellingerDistance([u;v]);
        H2(i,j)=H(1,2);
        G2(i,j)=G(1,2);
        
        J = jsDistance( [u;v] );        
        J2(i,j)=J(1,2);
                
        chi = chiSquaredDistance( [u;v] );
        Chi2(i,j) = chi(1,2);
        
               
        ms = meanSquaredDistance( [u;v], 1 );
        M2(i,j) = ms(1,2);
        
        t = tanimotoDistance( [u;v] );
        T(i,j) = t(1,2);
                
        K(i,j) = max( abs(u - v) );
        N1(i,j) = sum( abs(u - v) ) / 2;
        
        X2(i,j) = y + z *0.5;
        Y2(i,j) = z * (sqrt(3) / 2);
        xyz(r,:) = [x y z Cr2(i,j) Er2(i,j) Cu2(i,j) Eu2(i,j) E2(i,j) C2(i,j) H2(i,j) J2(i,j) Chi2(i,j)];
    end
end

% project to flat simplex in plane
X = xyz(1:r,2) + xyz(1:r,3) * 0.5;
Y = xyz(1:r,3) * (sqrt(3) / 2);
ux = u(2) + u(3) * 0.5;
uy = u(3) * (sqrt(3) / 2);

% plot
% E2, C2, H2, J2
%title('JS distance to u=[%d %d %d]');
%plot3(X, Y, xyz(:,7), 'b.');
%surfc(X2, Y2, J2);
%hold on
%euclidiean mono-chrome red
%surf(X2, Y2, E2, ones(size(E2)));
plot3(ux, uy, 0,'rx');


%note Er2 == H2
%
% hold on

clr = ones(size(E2));
deep_blue = 0.1*clr;
light_blue = 0.25*clr;
cyan = 0.35*clr;
teal = 0.4*clr;
green = 0.5*clr;
yellow = 0.6*clr;
orange = 0.7*clr;
red = 0.9*clr;

%return
% option 1
% ------------ uncomment the distance functoins you want ot plot
close
hold on
surfc( [0 0; 0 0], [0 0; 0 0], [0 1; 0 1] );
plot3(ux, uy, 0,'rx');
axis('square');
% ensure consistent color schemes
surfc(X2, Y2, Cr2, red);
%surfc(X2, Y2, Er2, light_blue); % redundant with H2
%surfc(X2, Y2, Cu2, yellow);
%  surfc(X2, Y2, Eu2);          %blank = rainbow
% surfc(X2, Y2, C2, red);
% surfc(X2, Y2, E2);          %blank = rainbow
% surfc(X2, Y2, G2, green);
%surfc(X2, Y2, T, green);
% surfc(X2, Y2, H2, light_blue);
surfc(X2, Y2, J2, deep_blue);
surfc(X2, Y2, Chi2, orange );
%  surfc(X2, Y2, M2, yellow );

%axis('square');

%title(sprintf('Distance to u=[%1.2f %1.2f %1.2f]. cos_r=red, euclid_r=hellinger=light-blue, cos_u=yellow, euclid_u=rainbow, JS=deep-blue, Chi^2=orange',u));
title(sprintf('Distance to u=[%1.2f %1.2f %1.2f]. cos_r=red, JS=deep-blue, Chi^2=orange',u));

surfc(X2, Y2, K, cyan);
surfc(X2, Y2, N1, green);

return


% option 2
% ------------ plot the difference between two distance functions

do_diff = 1;
if do_diff
    close
    hold on  
    plot3(ux, uy, 0,'rx');
    surfc(X2, Y2, Eu2 ./ H2);
    title('Euclidean distance on linearly normalized vectors / Hellinger')
    %surfc(X2, Y2, Eu2-H2);    
    %title('Euclidean distance on linearly normalized vectors - Hellinger')
end

return

do_diff = 1;
if do_diff
    close
    hold on  
    plot3(ux, uy, 0,'rx');
    surfc(X2, Y2, Cu2 - J2);
    surfc(X2, Y2, Cr2 - J2);
    surfc(X2, Y2, Chi2 - J2);
    
    surfc(X2, Y2, Cr2 + Chi2 - 2*J2);
    %axis('square');
    title('Cosine similarity on normalized, on sqrt u, and Chi^2 vs. JS')
end


%figure for pic
% u = [0.2000    0.3000    0.5000]
close
hold on
surfc( [0 0; 0 0], [0 0; 0 0], [0 1; 0 1] );
plot3(ux, uy, 0,'rx');
% ensure consistent color schemes
surfc(X2, Y2, Cr2, red);
%surfc(X2, Y2, Er2, light_blue); % redundant with H2
%surfc(X2, Y2, Cu2, yellow);
surfc(X2, Y2, Eu2);          %blank = rainbow
% surfc(X2, Y2, C2, green);
% surfc(X2, Y2, E2);          %blank = rainbow
surfc(X2, Y2, Chi2, orange );
surfc(X2, Y2, M2, yellow );

% very similar contours for H and JS
close
hold on
surfc( [0 0; 0 0], [0 0; 0 0], [0 1; 0 1] );
plot3(ux, uy, 0,'rx');

surf(X2, Y2, H2, cyan);
contour(X2, Y2, H2, 'c');
surf(X2, Y2, J2, red);
contour(X2, Y2, J2, 'r');
surf(X2, Y2, Eu2, yellow);    
contour(X2, Y2, Eu2, 'k');    % black
axis('square');
