function D = tanimotoDistance(M)
% Tanimoto distance
% like cosine-similarity but takes non-normalization into account
% from http://en.wikipedia.org/wiki/Cosine_similarity
% 
% Compute Tanimoto Distance between rows of M
% INPUT: 
%   M: m x n matrix, typically whose row sum is 1, n large
% Output:
%   H: m x m matrix of pair-wise distances

[m n] = size(M);
D = zeros(m,m);

sz = zeros(1,m);
for i = 1:m   
  sz(i) = M(i,:) * M(i,:)';
end

for i = 1:m
    dt = M(i,:) * M';  % 1 x m
    D(i,:) = ones(1,m) - dt ./ ( sz + sz(i) - dt);    
    both_zero = find( sz + sz(i) < 8*eps );   
    D(i,both_zero) = 0; %distance from 0 to 0 is defined to be 0
end
