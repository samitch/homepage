function plotcontours(F, steps, line_gap, border_color, border_width, iso_color, iso_width);
%  highlight some contours 

S1 = [1:steps];
Z = ones(1,steps);
N = Z*steps;

hold off
% border
lineijf(Z,S1,steps,F,border_color,'LineWidth',border_width);
hold on
lineijf(S1,Z,steps,F,border_color,'LineWidth',border_width);
lineijf(N,S1,steps,F,border_color,'LineWidth',border_width);
lineijf(S1,N,steps,F,border_color,'LineWidth',border_width);

% x=y line, F = 0 typically
line( [0 1], [0 1], [0.01 0.01], 'Color',iso_color,'LineWidth',iso_width);    

% isolines
for S=1:line_gap:steps
    Si = S:-1:1;
    Sj = 1:S;
    lineijf(Si,Sj,steps,F,iso_color,'LineWidth',iso_width);    
end
for S=0:line_gap:(steps-3)
    mx = steps - S;    
    Si = steps:-1:mx;
    Sj = mx:steps;
    lineijf(Si,Sj,steps,F,iso_color,'LineWidth',iso_width);    
end
Si = steps:-1:1;
Sj = 1:steps;
lineijf(Si,Sj,steps,F,iso_color,'LineWidth',iso_width);


