% plots on unit square, with isolines, and 2d plot view.

steps = 51; %101 for surfc; %201 for 2dplot
% H = Hellinger
H = zeros(steps,steps);
HH = zeros(steps*steps,3);
% H = Hellinger^2 = cosine similarity
H2 = zeros(steps,steps);
HH2 = zeros(steps*steps,3);
% geodesic hellinger, r for root
Gr = zeros(steps,steps);
GGr = zeros(steps*steps,3);
% C = chi-squared
C = zeros(steps,steps);
CC = zeros(steps*steps,3);
% JS from log
J = zeros(steps,steps);
JJ = zeros(steps*steps,3);
% E = euclidean
E = zeros(steps,steps);
EE = zeros(steps*steps,3);
%E2 = euclidean squared = cosine similarity
E2 = zeros(steps,steps);
EE2 = zeros(steps*steps,3);
% T = Tanimoto, like cosine similarity but un-normalized
T = zeros(steps,steps);
TT = zeros(steps*steps,3);
% geodesic euclidean
Gu = zeros(steps,steps);
GGu = zeros(steps*steps,3);
% K = Kolmogorov
K = zeros(steps,steps);
KK = zeros(steps*steps,3);

Jx = zeros(steps,steps);
JJx = zeros(steps*steps,3);
Jy = zeros(steps,steps);
JJy = zeros(steps*steps,3);
Hp = zeros(steps,steps);
HHp = zeros(steps*steps,3);


fz = zeros(steps,steps);
ffz = zeros(steps*steps,3);
r = zeros(steps,steps);

X=[];
Y=[];
for i=1:steps
    x = (i-1)/(steps-1);
    X = [X;x];
    for j=1:steps
        y = (j-1)/(steps-1);        
 
        H(i,j) = abs(sqrt(x) - sqrt(y));
        HH((i-1)*steps + j,:) = [x y H(i,j)];
        H2(i,j) = H(i,j).^2; 
        HH2((i-1)*steps + j,:) = [x y H2(i,j)];
        Gr(i,j) = 4 * asin(  H(i,j) / sqrt(2) ) / pi;
        GGr((i-1)*steps + j,:) = [x y Gr(i,j)];
        
        if abs(x+y) > 0
          C(i,j) = (x-y)^2 / (x+y);
        else
          C(i,j) = 0;
        end
        CC((i-1)*steps + j,:) = [x y C(i,j)];
        
        J(i,j) = jsiLog(x,y); %jsiSeries(x,y);
        JJ((i-1)*steps + j,:) = [x y J(i,j)];
        E2(i,j) = (x-y)^2;
        EE2((i-1)*steps + j,:) = [x y E2(i,j)];
        E(i,j) = sqrt(E2(i,j));
        EE((i-1)*steps + j,:) = [x y E(i,j)];
        EE((i-1)*steps + j,:) = [x y E(i,j)];

        Gu(i,j) = 4 * asin( E(i,j) / sqrt(2)) / pi;
        GGu((i-1)*steps + j,:) = [x y Gu(i,j)];

        %kolmogorov       
        K(i,j) = max( abs(x - y) );
        KK((i-1)*steps + j,:) = [x y K(i,j)];
        
        %tanimoto        
        t = tanimotoDistance( [x;y] );
        T(i,j) = t(1,2);     
        TT((i-1)*steps + j,:) = [x y T(i,j)];
        
        % for research figuring out how to prove H^2 < JS
        Jx(i,j) = 0;
        Jy(i,j) = 0;
        if (x>0)
            Jx(i,j) = x * log2( (2 * x) / (x + y) );
        end
        if (y>0)
            Jy(i,j) = y * log2( (2 * y) / (x + y) );
        end
        JJx((i-1)*steps + j,:) = [x y Jx(i,j)];
        JJy((i-1)*steps + j,:) = [x y Jy(i,j)];
                                         
        %unbounded for x=0 or y=0
        Hp(i,j) = (x+y) * (-log1p( -((x-y)/(x+y))^2 ) ) / 2;
                
        %Hp(i,j) = (x+y) * (-log( 1- ((x-y)/(x+y))^2 ) ) / 2;
        HHp((i-1)*steps + j,:) = [x y Hp(i,j)]; 
        
        if (x>y)
            r(i,j) = y/x;
            fz(i,j) = (J(i,j) - H2(i,j)) / x;
        elseif (y>x)
            r(i,j) = x/y;
            fz(i,j) = (J(i,j) - H2(i,j)) / y;
        else
            fz(i,j) = 0;
        end
            
    end
end
%D = [ HH(:,[1 2])  HH(:,3) - FF(:,3) ];
Y = X;

%plot3(FF(:,1),FF(:,2),FF(:,3),'.');
%axis([0 1 0 1 0 1]);

line_gap = 13; 
border_color = 'b';
border_width = 1;
iso_color = 'w';
iso_width = 2.2;

% F = H;
% F = H2;
% F = Gr;
% F = C;
% F = J;
% F = E;
% F = E2;
% F = Gu;
% F = F;

% surfc(X,Y,F);
% plotcontours(F, steps, line_gap, border_color, border_width, iso_color, iso_width);

%define colors
clr = ones(size(H));
deep_blue = 0.1*clr;
light_blue = 0.25*clr;
cyan = 0.35*clr;
teal = 0.4*clr;
green = 0.5*clr;
yellow = 0.6*clr;
orange = 0.7*clr;
red = 0.9*clr;

return
% JS H2 Jx Jy Hp 
close
F = J;
surfc(X,Y,F,red);
plotcontours(F, steps, line_gap, border_color, border_width, iso_color, iso_width);
F = Jx;
surfc(X,Y,F,green);
plotcontours(F, steps, line_gap, border_color, border_width, iso_color, iso_width);
F = Jy;
surfc(X,Y,F,green);
plotcontours(F, steps, line_gap, border_color, border_width, iso_color, iso_width);
F = H2;
surfc(X,Y,F,deep_blue);
plotcontours(F, steps, line_gap, border_color, border_width, iso_color, iso_width);
F = Hp;
surfc(X,Y,F,cyan);
plotcontours(F, steps, line_gap, border_color, border_width, iso_color, iso_width);
title('JS = red, Jx,Jy= green, H^2 = blue, Hp=cyan');
axis('square');


% 2D

iso_line = line_gap;  %25; %50; %60

border_width = 1;
border_color = 'b';
iso_width = 2;
iso_color = 'g';

% % hold off
% F = H;  %Hellinger
% F = H2; %H^2 = cosine on root
% F = Gr; %Geodesic Hellinger
% F = C;  %chi squared
% F = J;  %JS
% F = E;  %Euclidean
% F = E2; %Euclidean squared
% F = Gu; %Geodesic Euclidean
% F = T; %tanimoto

%plot2dConstant(F, steps, iso_line, border_width, border_color, iso_width, iso_color);
% G and H
close
F = Gr;
plot2dConstant(F, steps, iso_line, 1, 'r', 3, 'r');
F = H;
plot2dConstant(F, steps, iso_line, 1, 'b', 3, 'b');
axis('square');
title('H blue, G red');
% not much to see, G is slightly down-shifted

% C JS H2 G2
close
F = C;
plot2dConstant(F, steps, iso_line, 1, 'g', 2, 'g');
F = J;
plot2dConstant(F, steps, iso_line, 1, 'r', 2, 'r');
F = H;
plot2dConstant(F, steps, iso_line, 1, 'b', 2, 'b');
F = E;
plot2dConstant(F, steps, iso_line, 1, 'k', 2, 'k');
title('Chi^2 green >= JS red >= H^2 blue, G^2 black');

% JS H2 Jx Jy Hp 
close
F = J;
plot2dConstant(F, steps, iso_line, 1, 'r', 2, 'r');
F = Jx;
plot2dConstant(F, steps, iso_line, 1, 'g', 2, 'k');
F = Jy;
plot2dConstant(F, steps, iso_line, 1, 'g', 2, 'k');
F = H2;
plot2dConstant(F, steps, iso_line, 1, 'b', 2, 'b');
F = Hp;
plot2dConstant(F, steps, iso_line, 1, 'c', 2, 'c');
title('JS = red, H^2 = blue, Jx,Jy= green, Hp=cyan');



% highlight the right-edge Z curves.
figure
F = J; %or  F = H2;   F = C;
surf(X,Y,F);
hold on
% outline y=1 curve
%see isou.m
line(X, ones(steps,1), F(:,steps)', 'LineWidth', 4, 'Color', 'm')

% iso-ratio lines
num_lines = 8;
for i = 0:num_lines
    j = fix( i * (steps-1) / num_lines) + 1;
    if i == 0
        clr = 'k';
    else
        clr = 'w';
    end
    line( [0 i/num_lines], [0 1], [0 F(j,steps)], 'LineWidth', 2, 'Color', clr)    
end


axis('square');
