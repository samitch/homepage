%compareProjectToSphere.m

% For a mixture model u, sum_i u_i = 1, living on a flat simplex,
% project it to a unit vector, sum_i u_i^2 = 1, living on the sphere

% compare sqrt(u) vs. u / norm(u)

% "the triangle" = convex combinations of (1,0,0) (0,1,0) (0,0,1)

% steps2: for best results, use 2^n + 1, else picture may have a "bite" taken out of it
% steps2 = 9; 
%steps2 = 12; 
steps2 = 17; 
%steps2 = 33; 
%steps2 = 65; 
%steps2 = 129;
%steps2 = 6*4 + 1; % for pi/6 point

%plotting widgets
num_points = round( steps2*steps2/2 );
d=3;
flat_xyz = zeros(num_points, d); % rows = x,y,z coordinates on simplex
norm_xyz = zeros(num_points, d); % rows = x,y,z coordinates on sphere, u / norm(u)
sqrt_xyz = zeros(num_points, d); % rows = x,y,z coordinates on sphere, sqrt(u)
d_flat_xyz = zeros(num_points, d);%v - m_flat;
d_unit_xyz = zeros(num_points, d);%v_unit - m_unit;
d_sqrt_xyz = zeros(num_points, d);%v_sqrt - m_sqrt;
s = zeros(num_points, 1);
k = zeros(num_points, d);

%compute coordinates and distances over the triangle
% for making a picture for paper
m_flat = ones(1,d) / d;
m_sqrt = sqrt(m_flat);
m_unit = m_flat / norm(m_flat); % same as m_sqrt
r=0; % counter, number of sample points generated, running total in loop
for i = 1:steps2
    x = (i-1)/(steps2-1);
    for j = 1:steps2        
        y = (j-1)/(steps2-1);
        z = 1 - x - y;        
        if z < 0          
            continue
        end
        % only every other point on edges
        if (x==0)
            if ( mod(j,2) == 0 )
                continue
            end
        elseif (y==0)
            if (mod(i,2) == 0 )
                continue
            end
        elseif (z==0)
            if (mod(j,2) == 0 )
                continue
            end
        end
        
        
        r = r+1;
        v=[x, y, z];  
        v_sqrt = sqrt(v);
        v_unit = v / norm(v);
                
        flat_xyz(r,:) = v;
        sqrt_xyz(r,:) = v_sqrt;
        norm_xyz(r,:) = v_unit;        
        
        d_flat_xyz(r,:) = v - m_flat;
        d_unit_xyz(r,:) = v_unit - m_unit;
        d_sqrt_xyz(r,:) = v_sqrt - m_sqrt;
        
        s(r) = norm(v - m_flat,1);       
        k(r,:) = abs(d_sqrt_xyz(r,:) - s(r)*d_unit_xyz(r,:));
        c(r,:) = [min(k(r)) max(k(r))];
    end
end
% add center point
x = 1/3; y=1/3; z=1/3;
r = r+1;
v=[x, y, z];
v_sqrt = sqrt(v);
v_unit = v / norm(v);

flat_xyz(r,:) = v;
sqrt_xyz(r,:) = v_sqrt;
norm_xyz(r,:) = v_unit;

d_flat_xyz(r,:) = v - m_flat;
d_unit_xyz(r,:) = v_unit - m_unit;
d_sqrt_xyz(r,:) = v_sqrt - m_sqrt;

s(r) = norm(v - m_flat,1);
k(r,:) = abs(d_sqrt_xyz(r,:) - s(r)*d_unit_xyz(r,:));
c(r,:) = [min(k(r)) max(k(r))];

% original
% m_flat = ones(1,d) / d;
% m_sqrt = sqrt(m_flat);
% m_unit = m_flat / norm(m_flat); % same as m_sqrt
% r=0; % counter, number of sample points generated, running total in loop
% for i = 1:steps2
%     x = (i-1)/(steps2-1);
%     for j = 1:steps2        
%         y = (j-1)/(steps2-1);
%         z = 1 - x - y;        
%         if z < 0          
%             continue
%         end
%         r = r+1;
%         v=[x, y, z];  
%         v_sqrt = sqrt(v);
%         v_unit = v / norm(v);
%                 
%         flat_xyz(r,:) = v;
%         sqrt_xyz(r,:) = v_sqrt;
%         norm_xyz(r,:) = v_unit;        
%         
%         d_flat_xyz(r,:) = v - m_flat;
%         d_unit_xyz(r,:) = v_unit - m_unit;
%         d_sqrt_xyz(r,:) = v_sqrt - m_sqrt;
%         
%         s(r) = norm(v - m_flat,1);       
%         k(r,:) = abs(d_sqrt_xyz(r,:) - s(r)*d_unit_xyz(r,:));
%         c(r,:) = [min(k(r)) max(k(r))];
%     end
% end

% option 1
%-------------- plot lines from sqrt point to norm point plot points
close
hold on
%plot3(flat_xyz(1:r,1), flat_xyz(1:r,2), flat_xyz(1:r,3), 'r.');
f = find( sum( abs(sqrt_xyz(1:r,:) - norm_xyz(1:r,:)),2) > 0.01 );
plot3(sqrt_xyz(f,1), sqrt_xyz(f,2), sqrt_xyz(f,3), 'c.','MarkerSize',20); %cyan
plot3(norm_xyz(1:r,1), norm_xyz(1:r,2), norm_xyz(1:r,3), 'k.', 'MarkerSize',16); %black

%lines from sqrt point to norm point 
for i = 1:r
    plot3( [sqrt_xyz(i,1); norm_xyz(i,1)], [sqrt_xyz(i,2);  norm_xyz(i,2)], [sqrt_xyz(i,3); norm_xyz(i,3)], 'r');
    % quiver vectors are too short, arrows too small
%     quiver3( norm_xyz(i,1), norm_xyz(i,2), norm_xyz(i,3), ...
%     sqrt_xyz(i,1) - norm_xyz(i,1), ...
%     sqrt_xyz(i,2) - norm_xyz(i,2), ...
%     sqrt_xyz(i,3) - norm_xyz(i,3)); 
end
title('flat simplex = red, sqrt=blue, norm=green, sqrt-norm = magenta');

return
close
hold on

%lines perp to flat point, showing size of shrinkage
for i = 1:r
    p = flat_xyz(i,:);
    pmax = p*(1 + c(i,1));
    pmin = p*(1 - c(i,2));
    
    if max(flat_xyz(i,:) < 0.8) && min(flat_xyz(i,:) > 0.2)       
        plot3( [p(1)], [p(2)], [p(3)], 'rx');
        plot3( [p(1); pmax(1)], [p(2); pmax(2)], [p(3); pmax(3)], 'g');
        plot3( [p(1); pmin(1)], [p(2); pmin(2)], [p(3); pmin(3)], 'b');
        fprintf(' flat %f %f %f  :  d_flat %f %f %f : d %f : k %f %f %f \n', flat_xyz(i,:), d_flat_xyz(i,:), s(i), k(i,:) );
    end
end
title('scaling: bigger=green smaller=blue');




return
% option 2, to activate comment out the "return" above
%-------------  plot lines from flat to sqrt and norm points,
%for 2d
close
hold on


j=0;
k=1;
clear dflat dsqrt dnorm ddiff I
I=[];
for i = 1:r
    if flat_xyz(i,3) == 0  % || 1
        %plot3( [flat_xyz(i,1); sqrt_xyz(i,1)], [flat_xyz(i,2);  sqrt_xyz(i,2)], [flat_xyz(i,3); sqrt_xyz(i,3)], 'm');
        % see if lines intersect somewhere?
        %a = flat_xyz(i,:); b = sqrt_xyz(i,:); c = b-a; x = 4;
        %plot3( [a(1); b(1) + x*c(1)], [a(2); b(2) + x*c(2)], [a(3); b(3) + x*c(3)], 'm');
        
        plot3( [flat_xyz(i,1); sqrt_xyz(i,1)], [flat_xyz(i,2);  sqrt_xyz(i,2)], [flat_xyz(i,3); sqrt_xyz(i,3)], 'm');
        % plot3( [flat_xyz(i,1); 1], [flat_xyz(i,2); 1], [flat_xyz(i,3); 1], 'm');
        plot3( [flat_xyz(i,1); norm_xyz(i,1)], [flat_xyz(i,2);  norm_xyz(i,2)], [flat_xyz(i,3); norm_xyz(i,3)], 'g');
        
        %distance between consecutive 2d points
        if (j>0)
            dflat(k) = norm(flat_xyz(i,:) - flat_xyz(j,:));
            dsqrt(k) = norm(sqrt_xyz(i,:) - sqrt_xyz(j,:));
            dnorm(k) = norm(norm_xyz(i,:) - norm_xyz(j,:));
            
            % distance between points from the two projections
            % reaches maximum at around pi/6
            ddiff(k) = norm(norm_xyz(i,:) - sqrt_xyz(i,:));
            plot3( ...
                [flat_xyz(i,1); flat_xyz(i,1) - ddiff(k)], ...
                [flat_xyz(i,2); flat_xyz(i,2) - ddiff(k)], ...
                [flat_xyz(i,3); flat_xyz(i,3) - ddiff(k)], 'b');

            % compare angles
            % sqrt_norm_angle = pi - norm_angle

        
        end
        I =[I;i];
        k = k+1;
        j=i;
    end    
end
axis('square');

title('flat-sqrt=magenta, flat-norm=green, distance between sqrt and normed = blue');



% distance between points from the two projections
%drat = dsqrt ./ dnorm;

