function [D]=meilaDivergenceDistance(M)
% function [D]=meilaDivergenceDistance(M)
%
% Melia is used for getting a similarity number for a set of topics - it is
% not a pairwise metric.

% below is not finished!
%
% compute the Meila Divergence similarity measure between rows of M
% INPUT: 
%   M: m x n matrix, typically whose row sum is 1, n large
%   C1, C2: clusters, sets of indices of the rows of M 
% Output:
%   D: m x m matrix of Meila Divergence distances
%   For clarity, we normalize each so that the maximum possible distance 
%   is 1.
%   The normalization constant is independent of dimension.
%

[m n] = size(M);
D = zeros(m,m);

Mz = find(M == 0);

H = - M .* log2 (M);
H(Mz) = 0;
H = sum(H, 2);

E = sum(M,2) / n; % identically 1/n for mixture models

%determine E2 row by row
E2 = zeros(m,m);
for i=1:m
    E2(:,i) = sum( M .* repmat( M(i,:), m, 1), 2) / n;
end

I2 = zeros(m,m);
for i=1:m
    d = E(
???
return

%Mnz = find(M);




%M
for i = 1:m
    %i
    Mi = repmat( M(i,:), m, 1);
    Q = (M + Mi) / 2;
    
    DD = M .* log2( M ./ Q);
    DD( Mz ) = 0; % convert NaN's to zeros
    DDi = Mi .* log2( Mi ./ Q);
    DDi( find(Mi == 0) ) = 0; % convert NaN's to zeros
        
    D(i,:) = sum( DD + DDi, 2) / 2;
    
    % even slower
    %DDF = sparse(m,n);
    %DDF(Mnz) = DD;
    %DDiF = sparse(m,n);
    %DDiF(Minz) = DDi;
    
    %D(i,:) = sum( DDF + DDiF, 2) / 2;
    %pause
    
    
end
return

% equivalent but slower
D = zeros(m,m);
for i = 1:m
    %i
    Mi = repmat( M(i,:), m, 1);
    Minz = find(Mi);
    Q = (M + Mi) / 2;
    I = find(Q);
    % r =  M(I) ./ Q(I) % avoids dividing by zero, except other zeros
    
    DD = M(Mnz) .* log2( M(Mnz) ./ Q(Mnz));
    
    DDi = Mi(Minz) .* log2( Mi(Minz) ./ Q(Minz));
    
    % works but slow
    DDF = zeros(m,n);
    DDF(Mnz) = DD;
    DDiF = zeros(m,n);
    DDiF(Minz) = DDi;
    
    D2(i,:) = sum( DDF + DDiF, 2) / 2;
    
    % even slower
    %DDF = sparse(m,n);
    %DDF(Mnz) = DD;
    %DDiF = sparse(m,n);
    %DDiF(Minz) = DDi;
    
    %D(i,:) = sum( DDF + DDiF, 2) / 2;
    %pause 
    
end
