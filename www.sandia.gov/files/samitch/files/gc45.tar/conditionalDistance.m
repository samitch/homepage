function [d] = conditionalDistance(u, v, D, p, method)
% function [d] = conditionalDistance(u, v, D, p)
% Compute the conditional distance between vectors u and v, i.e. for matrix
% M = [u;v]
% see conditionalDistanceM.m

% default p = 2
if exist('p') == 0
    p = 2;
end

d = conditionalDistanceM( [u;v], D, p, method );
