% test computation of js = Jansen-Shanon distance for scalars x and y
% Using the log2 and the series formulas, jsiLog and jsiSeries
% also compare to Euclidean distance

steps = 201; %101; %201;
% H = JS from series
H = zeros(steps,steps);
HH = zeros(steps*steps,3);
% F = JS from log
F = zeros(steps,steps);
FF = zeros(steps*steps,3);
% E = euclidean squared
E = zeros(steps,steps);
EE = zeros(steps*steps,3);
%E2 = regular euclidean
E2 = zeros(steps,steps);
EE2 = zeros(steps*steps,3);
% C = chi-squared
C = zeros(steps,steps);
CC = zeros(steps*steps,3);
X=[];
Y=[];
for i=1:steps
    x = (i-1)/(steps-1);
    X = [X;x];
    for j=1:steps
        y = (j-1)/(steps-1);        
        H(i,j) = jsiSeries(x,y);
        HH((i-1)*steps + j,:) = [x y H(i,j)];
        F(i,j) = jsiLog(x,y);
        FF((i-1)*steps + j,:) = [x y F(i,j)];
        E(i,j) = (x-y)^2;
        EE((i-1)*steps + j,:) = [x y E(i,j)];
        E2(i,j) = sqrt(E(i,j));
        EE2((i-1)*steps + j,:) = [x y E2(i,j)];
        if abs(x+y) > 0
          C(i,j) = (x-y)^2 / (x+y);
        else
          C(i,j) = 0;
        end
        EE((i-1)*steps + j,:) = [x y E(i,j)];

    end
end
D = [ HH(:,[1 2])  HH(:,3) - FF(:,3) ];
Y = X;

%plot3(FF(:,1),FF(:,2),FF(:,3),'.');
axis([0 1 0 1 0 1]);
surface(X,Y,F);
% surface(X,Y,C); %chi^2
title('JS using Log in blue');
disp('JS using Log in blue: press any key')
pause
hold on
plot3(HH(:,1),HH(:,2),HH(:,3),'g.');
title('JS using Log in blue, using Series in green.');
disp('JS using Series in green : press any key')
pause
hold off
plot3(D(:,1),D(:,2),D(:,3),'r.');
title('JS Log - JS Series')
disp('JS Log - JS Series in red: press any key')
pause
% we see that if x or y is small, including zero,
% there are numerical issues with the HH calculation - more terms are needed,
% and FF is bigger than HH

% how close is plain old (x-y)^2 ? Not very close for large x+y, OK for
% medium  x+y
title('Euclidean^2 distance - JS using Log')
disp('Euclidean^2 distance error: press any key')
DE = [ EE(:,[1 2])  EE(:,3) - FF(:,3) ];
plot3(D(:,1),D(:,2),D(:,3),'r.');
%plot3(D(:,1),D(:,2),D(:,3),'r.');
pause

% draw JS blue and Euclidean^2 red
close
surface(1:steps,1:steps,F );
hold on
%surface(1:steps,1:steps,E ); % hard to see
plot3(EE(:,1)*steps,EE(:,2)*steps,EE(:,3),'r.');
title('JS and Euclidean^2 red');
disp('JS and Euclidean red : press any key')
pause

%highlight some contours 
% x = y
close
do_euclid = 1;
line_gap = 50; %60

S1 = [1:steps];
Z = ones(1,steps);
N = Z*steps;
hold off
lineijf(Z,S1,steps,F,'b');
if do_euclid, lineijf(Z,S1,steps,E,'g'); end;
hold on
lineijf(S1,Z,steps,F,'b');
if do_euclid, lineijf(S1,Z,steps,E,'g'); end;
lineijf(N,S1,steps,F,'b');
if do_euclid, lineijf(N,S1,steps,E,'g'); end;
lineijf(S1,N,steps,F,'b');
if do_euclid, lineijf(S1,N,steps,E,'g'); end;
for S=1:line_gap:steps
    Si = S:-1:1;
    Sj = 1:S;
    lineijf(Si,Sj,steps,F,'r');
    if do_euclid, lineijf(Si,Sj,steps,E,'g'); end;
end
for S=0:line_gap:(steps-3)
    mx = steps - S;    
    Si = steps:-1:mx;
    Sj = mx:steps;
    lineijf(Si,Sj,steps,F,'r');
    if do_euclid, lineijf(Si,Sj,steps,E,'g'); end;
end
Si = steps:-1:1;
Sj = 1:steps;
lineijf(Si,Sj,steps,F,'r');
if do_euclid, lineijf(Si,Sj,steps,E,'g'); end;
disp('JS vs. x and y: press any key')
pause

% the following is a 2-d view of the above that might look good in a paper
close
hold off
% y = 0 line
line2ijf(Z,S1,steps,F,'b');
hold on
line2ijf(S1,Z,steps,F,'b');
% x=1 line
line2ijf(N,S1,steps,F,'b');
line2ijf(S1,N,steps,F,'b');
% x = 1 line for Chi
line2ijf(N,S1,steps,C,'b');
line2ijf(S1,N,steps,C,'b');

%since steps = 200, 
% isoline = 50 gives x+y = 50/200, 100/200, 150/200, ...
isoline = 50; %25

for S=1:isoline:steps 
    Si = S:-1:1;
    Sj = 1:S;
    line2ijf(Si,Sj,steps,F,'r');
    line2ijf(Si,Sj,steps,C,'g');
end
for S=0:isoline:(steps-3)
    mx = steps - S;    
    Si = steps:-1:mx;
    Sj = mx:steps;
    line2ijf(Si,Sj,steps,F,'r');    
    line2ijf(Si,Sj,steps,C,'g');    
end
%Euclidean for comparison
% skip Euclidean if using JS, since the x+y = 1 line is just Euclidean!
Si = steps:-1:1;
Sj = 1:steps;
%line2ijf(Si,Sj,steps,E,'m');
title('JS vs. x-y in red and blue. Chi^2 in green. Red cuves have constant x+y; steeper curves are for smaller x+y. Blue curves are JS for x or y equal 0 or 1. Magenta middle curve is euclidean distance (x+y)^2');
disp('JS vs. x-y in red and blue; and Euclid(green): press any key')
pause

% try for vector valued JS...
% compute distance from u to all other points in the triangle
close
% u = point we're taking distances from
%u=[0.2 0.3 0.5];
%u=[1 1 1] / 3;
%u=[0.5 0.5 0]
u=[1 0 0];
% v = point we're taking distances to, varying over entire triangle
steps2 = 33; % for best results, use 2^n + 1, else picture may have a "bite" taken out of it
E2 = zeros(steps2,steps2); %Euclidean distance between unit vectors
C2 = zeros(steps2,steps2); %cosine similarity between unit vectors
H2 = zeros(steps2,steps2); %Hellinger distance between mixture models
J2 = zeros(steps2,steps2); %Jensen-Shannon distance between mixture models

X2 = zeros(steps2,steps2); % x coordinates for projected 3-simplex
Y2 = zeros(steps2,steps2); % y coordinates for projected 3-simplex
xyz = zeros( ceil(steps2*steps2/2), 7); % rows = x,y,z coordinates and distance values 
% X and Y are the same as X2 and Y2, just as a vectors
r=0; % row index, number of sample points generated
for i = 1:steps2
    x = (i-1)/(steps2-1);
    for j = 1:steps2        
        y = (j-1)/(steps2-1);
        z = 1 - x - y;        
        if z < 0          
            if (j>1)                
                E2(i,j) = E2(i,j-1);
                C2(i,j) = C2(i,j-1);                
                H2(i,j) = H2(i,j-1);
                J2(i,j) = J2(i,j-1);
                
                X2(i,j) = X2(i,j-1);
                Y2(i,j) = Y2(i,j-1);                
            else
                E2(i,j) = E2(i-1,j);
                C2(i,j) = C2(i-1,j);
                H2(i,j) = H2(i-1,j);
                J2(i,j) = J2(i-1,j);
                
                X2(i,j) = X2(i-1,j);
                Y2(i,j) = Y2(i-1,j);

            end    
            continue
        end
        r = r+1;
        v=[x, y, z];
        u_unit = sqrt(u);
        v_unit = sqrt(v);
        
        E2(i,j)=norm(u_unit-v_unit); % euclidean distance                
        C2(i,j)=1 - u*v';
        
        H=hellingerDistance([u;v]);
        H2(i,j)=H(1,2);
        
        J = jsDistance( [u;v] );        
        J2(i,j)=J(1,2);
                
        X2(i,j) = y + z *0.5;
        Y2(i,j) = z * (sqrt(3) / 2);
        xyz(r,:) = [x y z E2(i,j) C2(i,j) H2(i,j) J2(i,j)];
    end
end
E2 = E2 / sqrt(2); % normalized between 0 and 1
% project to flat simplex in plane
Xf = xyz(1:r,2) + xyz(1:r,3) * 0.5;
Yf = xyz(1:r,3) * (sqrt(3) / 2);
ux = u(2) + u(3) * 0.5;
uy = u(3) * (sqrt(3) / 2);

% plot
% E2, C2, H2, J2
title('JS distance to u=[%d %d %d]');
%plot3(Xf, Yf, xyz(:,7), 'b.');
surfc(X2, Y2, J2);
hold on
%euclidiean mono-chrom
surf(X2, Y2, E2, ones(size(E2)));
plot3(ux, uy, 0,'rx');
%
% surfc(X2, Y2, H2);
% surfc(X2, Y2, H2);
% surfc(X2, Y2, H2);

