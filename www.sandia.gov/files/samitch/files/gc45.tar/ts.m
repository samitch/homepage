% T and S-plus in 3d

steps = 10;

X2 = zeros(steps2,steps2); % x coordinates for T
Y2 = zeros(steps2,steps2); % y coordinates for T
tZ = zeros(steps2,steps2); % z coordinates for T

XS = zeros(steps2,steps2); % x coordinates for S
YS = zeros(steps2,steps2); % y coordinates for S
ZS = zeros(steps2,steps2); % z coordinates for S

num_points = round( steps2*steps2/2 );
xyz = zeros(num_points, 3+num_distances); % rows = x,y,z coordinates and distance values 
% X and Y are the same as X2 and Y2, just as a vectors

%compute coordinates and distances over the triangle
r=0; % counter, number of sample points generated, running total in loop
for i = 1:steps2
    x = (i-1)/(steps2-1);
    for j = 1:steps2        
        y = (j-1)/(steps2-1);
        z = 1 - x - y;        
        if z < 0          
            if (j>1)                                
                tZ(i,j) = tZ(i,j-1);
                X2(i,j) = X2(i,j-1);
                Y2(i,j) = Y2(i,j-1);
                
                XS(i,j) = XS(i,j-1);
                YS(i,j) = YS(i,j-1);
                ZS(i,j) = ZS(i,j-1);
            else
                tZ(i,j) = tZ(i-1,j);
                X2(i,j) = X2(i-1,j);
                Y2(i,j) = Y2(i-1,j);
                
                XS(i,j) = XS(i-1,j);
                YS(i,j) = YS(i-1,j);
                ZS(i,j) = ZS(i-1,j);
            end    
            continue
        end
                
        X2(i,j) = x;
        Y2(i,j) = y;        
        tZ(i,j) = z;
        
        p = [x, y, z];
        XS(i,j) = x / norm(p); 
        YS(i,j) = y / norm(p); 
        ZS(i,j) = z / norm(p);
               
    end
end

clr = ones(size(XS));
deep_blue = 0.1*clr;
light_blue = 0.25*clr;
cyan = 0.35*clr;
teal = 0.4*clr;
green = 0.5*clr;
yellow = 0.6*clr;
orange = 0.7*clr;
red = 0.9*clr;

figure
axis([0 1 0 1 0 1]);
grid;
hold on;

