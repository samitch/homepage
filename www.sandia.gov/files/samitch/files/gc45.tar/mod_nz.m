function [a] = mod_nz(a,b)
%  function [a] = mod_nz(a,b)
%    return a mod b in range of 1:b  No Zeros!

a = mod(a,b);
a(find(a==0)) = b;

%
%if a<1
%  a=a+b; 
%elseif a>b
%  a=a-b;
%end

