function [X]=chiSquaredDistance(M)
% function [X]=chiSquaredDistance(M)
% compute the chi-squared distance between rows of M
% INPUT: 
%   M: m x n matrix, typically whose row sum is 1, n large
% Output:
%   X: m x m matrix of chiSquared distances

[m n] = size(M);
X = zeros(m,m);

% could speed this up by a factor of 2 by exploiting symettry...

for i = 1:m
    D2 = (M - repmat( M(i,:), m, 1 )).^2; 
    D2z = find( D2 == 0 );
    S = (M + repmat( M(i,:), m, 1 ));
    D2S = D2 ./ S;
    D2S(D2z) = 0;
    X(:, i) = sum( D2S, 2 ) / 2;
end
