% iso-ratio z lines
num_lines = 8;
for i = 0:num_lines
    j = fix( i * (steps-1) / num_lines) + 1;
    if i == 0
        clr = 'k';
    else
        clr = 'w';
    end
    line( [0 i/num_lines], [0 1], [0 F(j,steps)], 'LineWidth', 2, 'Color', clr)    
end

