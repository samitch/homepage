% animations for 45-minute seminar


plotAllSilent

% chi-squared
F = C;
% 1 iso-p lines
figure; axis([0 1 0 1 0 1]); 
surfc(X,Y,F);
plotcontours(F, steps, line_gap, border_color, border_width, iso_color, iso_width);
title('1d chi-squared, iso-p');
axis('square');

%iso-z lines
% 2
figure; axis([0 1 0 1 0 1]); 
surfc(X,Y,F);
isoz
title('1d chi-squared, iso-z, iso-q');
axis('square');

%iso-z lines
% 3
figure; axis([0 1 0 1 0 1]); 
surfc(X,Y,F);
iso_u_color = 'm';
isou
title('1d chi-squared, iso-u');
axis('square');

%JS
% 4
F=J;
figure; axis([0 1 0 1 0 1]); 
surfc(X,Y,F,red);
iso_u_color = 'y';
isou
isoz
plotcontours(F, steps, line_gap, 'b', border_width, 'b', iso_width);
title('1d JS');
axis('square');

% H and H^2
% 5
figure; axis([0 1 0 1 0 1]); 
F=H2;
surfc(X,Y,F,deep_blue);
hold on
F=H;
surfc(X,Y,F,yellow);
title('1d H^2 deep blue, H light blue');
axis('square');


% 3d plots
u=[1 0 0];
compareDistancesSilent

% 6
figure
surfc( [0 0; 0 0], [0 0; 0 0], [0 1; 0 1] );
hold on;
plot3(ux, uy, 0,'rx');
axis('square');
surfc(X2, Y2, Cr2, deep_blue);
surfc(X2, Y2, J2, red);
surfc(X2, Y2, Chi2, green );
title(sprintf('Distance to u=[%1.2f %1.2f %1.2f]. H^2=blue, JS=red, Chi^2=green',u));


%7
figure
surfc( [0 0; 0 0], [0 0; 0 0], [0 1; 0 1] );
hold on;
plot3(ux, uy, 0,'rx');
axis('square');
surfc(X2, Y2, Cr2, deep_blue);
surfc(X2, Y2, H2, light_blue);
surfc(X2, Y2, E2, orange );
title(sprintf('Distance to u=[%1.2f %1.2f %1.2f]. H=light-blue, H^2=deep-blue, E=orange',u));

%8
figure
surfc( [0 0; 0 0], [0 0; 0 0], [0 1; 0 1] );
hold on;
plot3(ux, uy, 0,'rx');
axis('square');
surfc(X2, Y2, Cr2, deep_blue);
surfc(X2, Y2, H2, light_blue);
surfc(X2, Y2, Eu2, orange );
surfc(X2, Y2, Cu2, yellow );
%title(sprintf('Distance to u=[%1.2f %1.2f %1.2f]. H=light-blue, H^2=deep-blue, E_u=orange',u));
title(sprintf('Distance to u=[%1.2f %1.2f %1.2f]. H=light-blue, H^2=deep-blue, E_u=orange, E^2_u=yellow',u));

%%%% u = 1/2  1/2  0
u =[0.5 0.5 0];
compareDistancesSilent

% 9
figure
surfc( [0 0; 0 0], [0 0; 0 0], [0 1; 0 1] );
hold on;
plot3(ux, uy, 0,'rx');
axis('square');
surfc(X2, Y2, Cr2, deep_blue);
surfc(X2, Y2, J2, red);
surfc(X2, Y2, Chi2, green );
title(sprintf('Distance to u=[%1.2f %1.2f %1.2f]. H^2=blue, JS=red, Chi^2=green',u));

%10
figure
surfc( [0 0; 0 0], [0 0; 0 0], [0 1; 0 1] );
hold on;
plot3(ux, uy, 0,'rx');
axis('square');
surfc(X2, Y2, Cr2, deep_blue);
surfc(X2, Y2, H2, light_blue);
surfc(X2, Y2, Eu2, orange );
  surfc(X2, Y2, Cu2, yellow );
%title(sprintf('Distance to u=[%1.2f %1.2f %1.2f]. H=light-blue, H^2=deep-blue, E_u=orange',u));
  title(sprintf('Distance to u=[%1.2f %1.2f %1.2f]. H=light-blue, H^2=deep-blue, E_u=orange, E^2_u=yellow',u));

%%%% u = 1/3  1/3  1/3
u =[1 1 1] / 3;
compareDistancesSilent

% 11
figure
surfc( [0 0; 0 0], [0 0; 0 0], [0 1; 0 1] );
hold on;
plot3(ux, uy, 0,'rx');
axis('square');
surfc(X2, Y2, Cr2, deep_blue);
surfc(X2, Y2, J2, red);
surfc(X2, Y2, Chi2, green );
title(sprintf('Distance to u=[%1.2f %1.2f %1.2f]. H^2=blue, JS=red, Chi^2=green',u));

%12
figure
surfc( [0 0; 0 0], [0 0; 0 0], [0 1; 0 1] );
hold on;
plot3(ux, uy, 0,'rx');
axis('square');
surfc(X2, Y2, Cr2, deep_blue);
surfc(X2, Y2, H2, light_blue);
surfc(X2, Y2, Eu2, orange );
  surfc(X2, Y2, Cu2, yellow );
%title(sprintf('Distance to u=[%1.2f %1.2f %1.2f]. H=light-blue, H^2=deep-blue, E_u=orange',u));
  title(sprintf('Distance to u=[%1.2f %1.2f %1.2f]. H=light-blue, H^2=deep-blue, E_u=orange, E^2_u=yellow',u));


%%%% u = 0.2  0.3  0.5
u=[0.2 0.3 0.5];
compareDistancesSilent

% 13
figure
surfc( [0 0; 0 0], [0 0; 0 0], [0 1; 0 1] );
hold on;
plot3(ux, uy, 0,'rx');
axis('square');
surfc(X2, Y2, Cr2, deep_blue);
surfc(X2, Y2, J2, red);
surfc(X2, Y2, Chi2, green );
title(sprintf('Distance to u=[%1.2f %1.2f %1.2f]. H^2=blue, JS=red, Chi^2=green',u));

%14
figure
surfc( [0 0; 0 0], [0 0; 0 0], [0 1; 0 1] );
hold on;
plot3(ux, uy, 0,'rx');
axis('square');
surfc(X2, Y2, Cr2, deep_blue);
surfc(X2, Y2, H2, light_blue);
surfc(X2, Y2, Eu2, orange );
  surfc(X2, Y2, Cu2, yellow );
%title(sprintf('Distance to u=[%1.2f %1.2f %1.2f]. H=light-blue, H^2=deep-blue, E_u=orange',u));
  title(sprintf('Distance to u=[%1.2f %1.2f %1.2f]. H=light-blue, H^2=deep-blue, E_u=orange, E^2_u=yellow',u));


%%%% u = 0.89  0.1   0.01
u=[0.89, 0.1 0.01];
compareDistancesSilent

% 15
figure
surfc( [0 0; 0 0], [0 0; 0 0], [0 1; 0 1] );
hold on;
plot3(ux, uy, 0,'rx');
axis('square');
surfc(X2, Y2, Cr2, deep_blue);
surfc(X2, Y2, J2, red);
surfc(X2, Y2, Chi2, green );
title(sprintf('Distance to u=[%1.2f %1.2f %1.2f]. H^2=blue, JS=red, Chi^2=green',u));

%16
figure
surfc( [0 0; 0 0], [0 0; 0 0], [0 1; 0 1] );
hold on;
plot3(ux, uy, 0,'rx');
axis('square');
surfc(X2, Y2, Cr2, deep_blue);
surfc(X2, Y2, H2, light_blue);
surfc(X2, Y2, Eu2, orange );
  surfc(X2, Y2, Cu2, yellow );
%title(sprintf('Distance to u=[%1.2f %1.2f %1.2f]. H=light-blue, H^2=deep-blue, E_u=orange',u));
  title(sprintf('Distance to u=[%1.2f %1.2f %1.2f]. H=light-blue, H^2=deep-blue, E_u=orange, E^2_u=yellow',u));


