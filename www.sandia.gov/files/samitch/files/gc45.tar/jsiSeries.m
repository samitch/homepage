function [z] = jsiSeries(x,y)
% function [z]=jsi(x,y)
% return the Jansen-Shanon value for scalars x and y
% that is, compute js for one component of the vector.
%
% Using the Taylor series expansion Scott came up with

% p = 'plus' = sum of x and y
% d = 'difference' = difference between x and y
p = x + y;
if p == 0
    z = 0;
    return;
end
d = x - y;
% ratio of d to p squared
r2 = (d / p)^2; 

% series part
z = 0;
terms = 10 + ( 100 / (1.01 - r2) ); % needs more terms as r2->1
for n=1:terms
    z = z + r2^n * (1/((2*n-1)*(2*n)));
end
z = z * p / log(2);
