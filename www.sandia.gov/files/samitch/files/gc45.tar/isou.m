%iso-u
%iso_u_color = 'm'
num_iso_u_lines = 6;
step_size=floor(steps/num_iso_u_lines);
for a = 1:step_size:steps
  line(X(1:steps-a+1), ((steps-a)/(steps-1)) * ones(steps-a+1,1), F(1:steps-a+1,steps-a+1)', 'LineWidth', 4, 'Color', iso_u_color)
end
