function [DD] = conditionalDistanceM(M, D, p, method)
% function [d] = conditionalDistanceM(M, D, p)
% Compute the p-norm distance between all pairs of rows of M.
% If D = ones - eye, then distances are preserved up to a (m-1)/m scaling
% factor.
%
% INPUT:
%   M: m x n matrix, m points with n coordinates each, mixture model (row sum = 1)
%   D: m x m matrix of distances between indices of u or v
%       D is converted to a similarity matrix 1-D, so on input the diagonal
%       of D should always be zero and the off-diagonals should be <= 1.
%   p: 1 x 1 norm for unconditioned distances between coordinates of M.
%      let u and v be two rows of M, then
%      if p=='h', then the Hellinger distance is used, 
%         meaning d_i = sqrt(u_i) - sqrt(v_i)
%      if p=='js', then the Jensen-Shannon divergence measure is used
%         meaning d_i = u_i log(u_i/(u_i+v_i)) + v_i sqrt(v_i/(u_i+v_i))
%      if p==scalar, then d_i = ((u_i - v_i)^p )^1/p = abs(u_i - v_i)
%   method: choice of "conditional" distance. 
%      Let d = the componentwise distance computed from M using the metric
%      defined by 'p'. 
%      method = 'q': quadratic form, DD = (d^(p/2) (1-D) d^(p/2)')^1/p
%      method = 'e': earth mover's distance, minimizing the product of d*M      
%      method = 'd': David Robinson's distance...
%      method = 'm': match distance - only takes an ordering to the
%                    coordinates, rather than an arbitrary M distances.
% OUTPUT:
%   DD: n x n distance between rows of M conditioned on D
%       if p=='h', then DD = [H G], where 
%         H is n x n Hellinger and 
%         G is n x n geodesic Hellinger
%

% default p = 2
if exist('p') == 0
    p = 2;
end;

%linearly scale so max distance is 1?
scale_max = 0;

[m, n] = size(M);
DD = zeros(m,m);

if method == 'q'
    % change D to a similarity matrix, entries in [0,1]
    D = 1 - D;
elseif method == 'e'
    % ensure diagonal is 0
    D = D - diag(diag(D));    
end
% ensure distances or affinity >= 0
mind = min(min(D));
if mind < 0
    D = D - mind;
end
% ensure max distance or affinity == 1 ?
if scale_max
    maxd = max(max(D));
    if maxd > 1
        D = D / maxd;
    end
end

% could speed this up by a factor of 2 by exploiting symettry...
pp = p;
if p == 'h'
    M = sqrt(M); % row sum of squares is now 1
    pp = 2;
    % the rest is standard Euclidean p==2
elseif p == 'js'
    pp = 1;
else
    % normalize M
    %M = normed(M); % normalizing produces weird results
end


C = zeros(m,n); %coordinate raw differences
Cd = zeros(m,n); %coordinate difference distances^(p/2)
DDD = zeros(1,m);

% outline
% for all rows, 
%  find difference from row i to all other rows for every coordinate
%  convert to intra-coordinate distance, height distance
%  condition those distances on the ground distance between coordinate indices

% this likely won't be a metric
% For earth movers distance, it is a metric only under the L1 norm, p=1

if method == 'e'
    % Flows are naturally m x m -> write as a m^2 vector, by rows
    n2 = n*n;
    f = D( [1:n2] );
    lb = zeros( size(f) );
    ub = zeros( size(f) );
    Aeq = [];
    beq = [];
    
    A_rows = 2*n + 1;
    A = zeros(A_rows,n2);
    b = zeros(A_rows,1);
    for k = 1:n
        A(k, (1+(k-1)*n):(k*n) ) = 1;      
        A(k+n, k:n:(n*n) ) = 1;       
    end
    A(A_rows,:) = ones(1,n2);               
    %A
    
    options=optimset('Display', 'off'); % otherwise annoying messages printed while optimizing
    %options = []; % see the annoying messages
    x0 = 0; % unused, but required in order to specify options
end

for i = 1:m
    
    if p == 'js'
        Mi = repmat( M(i,:), m, 1);
        Q = (M + Mi) / 2;
        
        E = M .* log2( M ./ Q);
        E( Mz ) = 0; % convert NaN's to zeros
        F = Mi .* log2( Mi ./ Q);
        F( find(Mi == 0) ) = 0; % convert NaN's to zeros
        
        Cd = (E + F) / 2;
    else
        C = (M - repmat( M(i,:), m, 1 ));
        Cd = C .^ (pp / 2);  % should this be abs(C) for p == 1 ?
    end
    
    if method == 'q'
        for j = 1:m
            DDD(j) = (Cd(j,:) * D * Cd(j,:)').^(1/pp);
        end
        DD(i,:) = DDD / (2^(1/pp));
    elseif method == 'e'
                
        % ensure sign of Cd is correct:
        Cd = sign(C) .* abs(Cd);
        % choice: do we want to normalize Cd here or not?
        % pros: solution to this row might be more well behaved
        % cons: solutions between rows might be inconsistently scaled,
        %       worse behaved...
        
        % set up EMD matrix and solve for each row paired with i
        % min_x f'x st Ax <= b, Aeq * x = beq, lb <= x <= ub
        % x = linprog(f,A,b,Aeq,beq,lb,ub), from optimization toolbox
        
        % compute distance from row i to row j for all j
        for j = 1:m 
            Cdj = Cd(j,:);
            
            r = zeros(1,n); %what EMD paper calls P
            q = zeros(1,n); 
            r(find(Cdj>0)) = Cdj(find(Cdj>0));
            q(find(Cdj<0)) = abs(Cdj(find(Cdj<0)));
            
            for k = 1:n                
                b(k) = r(k);                
                b(k+n) = q(k);                                
            end                        
            b(A_rows) = min( sum(r), sum(q) ); 
            
            for k = 1:n2
                ub(k) = max( r( 1 + floor((k-1) / n) ), q( mod_nz(k,n) ) );
            end
            
            %Cdj
            [soln soln_val exitflag] = linprog(f,A,b,Aeq,beq,lb,ub,x0,options);
            
            % should there be a .^(1/p) here?
            %  partial_match_normalization = sum(soln.^(1/p)); 
            partial_match_normalization = sum(soln); 
            if partial_match_normalization == 0
                partial_match_normalization = 1;
            end
            
            DD(i,j) = soln_val / partial_match_normalization;
            
        end        
    end
end

