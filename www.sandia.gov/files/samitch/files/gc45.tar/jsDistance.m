function [D]=jsDistance(M)
% function [D]=jsDistance(M)
% compute the Jensen-Shannon divergence measure between rows of M
% INPUT: 
%   M: m x n matrix, typically whose row sum is 1, n large
% Output:
%   D: m x m matrix of J-S distances
%   For clarity, we normalize each so that the maximum possible distance 
%   is 1.
%   The normalization constant is independent of dimension.
%

[m n] = size(M);
D = zeros(m,m);

%Mnz = find(M);

Mz = find(M == 0);

%M
for i = 1:m
    %i
    Mi = repmat( M(i,:), m, 1);
    Q = (M + Mi) / 2;
    
    DD = M .* log2( M ./ Q);
    DD( Mz ) = 0; % convert NaN's to zeros
    DDi = Mi .* log2( Mi ./ Q);
    DDi( find(Mi == 0) ) = 0; % convert NaN's to zeros
        
    D(i,:) = sum( DD + DDi, 2) / 2;
    
    % even slower
    %DDF = sparse(m,n);
    %DDF(Mnz) = DD;
    %DDiF = sparse(m,n);
    %DDiF(Minz) = DDi;
    
    %D(i,:) = sum( DDF + DDiF, 2) / 2;
    %pause
    
    
end
return

% equivalent but slower
D = zeros(m,m);
for i = 1:m
    %i
    Mi = repmat( M(i,:), m, 1);
    Minz = find(Mi);
    Q = (M + Mi) / 2;
    I = find(Q);
    % r =  M(I) ./ Q(I) % avoids dividing by zero, except other zeros
    
    DD = M(Mnz) .* log2( M(Mnz) ./ Q(Mnz));
    
    DDi = Mi(Minz) .* log2( Mi(Minz) ./ Q(Minz));
    
    % works but slow
    DDF = zeros(m,n);
    DDF(Mnz) = DD;
    DDiF = zeros(m,n);
    DDiF(Minz) = DDi;
    
    D2(i,:) = sum( DDF + DDiF, 2) / 2;
    
    % even slower
    %DDF = sparse(m,n);
    %DDF(Mnz) = DD;
    %DDiF = sparse(m,n);
    %DDiF(Minz) = DDi;
    
    %D(i,:) = sum( DDF + DDiF, 2) / 2;
    %pause 
    
end
